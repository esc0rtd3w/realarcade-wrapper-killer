sh ./build.sh

adb install -r bin/App-release-signed.apk

adb shell am start -a android.intent.action.MAIN -n com.gamehouse.pluginapp/com.ansca.corona.CoronaActivity
