package com.mopub.mobileads.resource;

public interface TextDrawable {
    public void updateText(final String text);
}
