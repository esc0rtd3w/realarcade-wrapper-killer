//
//  MainActivity.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import android.annotation.SuppressLint;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.Constants;
import com.gamehouse.crosspromotion.implementation.CrossPromotionImpl;
import com.gamehouse.crosspromotion.implementation.SettingsListener;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView.InterstitialResult;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdViewListener;
import com.gamehouse.crosspromotion.implementation.settings.Settings;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.DebugCheat;
import com.gamehouse.crosspromotion.implementation.utils.json.JSON;
import com.gamehouse.crosspromotion.implementation.utils.json.JSONArray;
import com.gamehouse.crosspromotiondebugsample.GoogleAdvertisingID.Info;
import com.gamehouse.crosspromotiondebugsample.GoogleAdvertisingID.ResolveListener;
import com.gamehouse.crosspromotiondebugsample.debug.SharedSettings;
import com.gamehouse.crosspromotiondebugsample.debug.SharedSettingsKeys;
import com.gamehouse.crosspromotiondebugsample.net.JSONLoadingTask;

public class MainActivity extends ActivityBase implements InterstitialAdViewListener, SettingsListener
{
	public static final int REQUEST_CODE_SERVER_PICK = 1;
	public static final int REQUEST_CODE_ENTRY_EDIT = 2;

	private EditText txtAppId;
	private EditText txtServerURL;

	private Button btnPresent;
	private ProgressBar progressBar;

	private ListView listView;

	private ParamEntry[] entries;
	private ParamEntry currentEntry;
	
    private TextView txtGoogleAdvertisementId;

	private enum State
	{
		NotLoaded, Loading, Loaded, Failed
	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initSharedSettings();
		
		Debug.init(this);

		setElements();

		loadEntryParams("http://admock-gamehouse.rhcloud.com/app/params"); // TODO: remote that
		CrossPromotionImpl.setOverridenServerURL(getServerURL());

		String appId = getAppId();
		CrossPromotion.initialize(this, appId);

		initSharedSettingsValues();
		setState(State.NotLoaded);
		
		ResolveGoogleAppId();
	}

    @Override
	protected void onDestroy()
	{
		CrossPromotion.destroy();
		SharedSettings.destroy();
		super.onDestroy();
	}

	////////////////////////////////////////////////////////////////
	// Click listeners

	public void onRequestButtonClick(View view)
	{
		String url = getServerURL();
		String appId = getAppId();

		setState(State.Loading);

		Global.setBaseURL(url);
		Global.setAppId(appId);

		CrossPromotion.instance().startRequestingInterstitials(this);
	}

	public void onPresentButtonClick(View view)
	{
		Map<String, Object> params = createPresentParams();
		InterstitialResult result = CrossPromotion.instance().present(this, params);
		if (result != InterstitialResult.Presented)
		{
			Debug.showToast(this, "Not presented");
		}
	}

	public void onServerPickButton(View view)
	{
		Intent intent = new Intent(this, ServerPickActivity.class);
		startActivityForResult(intent, REQUEST_CODE_SERVER_PICK);
	}

	public void onCancelButtonClick(View view)
	{
		CrossPromotion.instance().stopRequestingInterstitials();
		setState(State.NotLoaded);

		System.gc();
	}

	////////////////////////////////////////////////////////////////
	// CPInterstitialAdViewDelegate

	@Override
	public void onInterstitialAdReceive(InterstitialAdView adView)
	{
		setState(State.Loaded);
		Debug.showToast(this, "Received");
	}

	@Override
	public void onInterstitialAdFail(InterstitialAdView adView, int code, String reason)
	{
		Debug.showToast(this, "Failed");
		setState(State.Failed);
	}

	@Override
	public void onInterstitialAdOpen(InterstitialAdView adView)
	{
	}

	@Override
	public void onInterstitialAdClose(InterstitialAdView adView)
	{
		setState(State.Loading);
	}

	@Override
	public void onInterstitialAdLeaveApplication(InterstitialAdView adView)
	{
	}

	@Override
	public Map<String, Object> createInterstitialAdParams()
	{
		return null;
	}

	////////////////////////////////////////////////////////////////
	// Helpers 

	private void setElements()
	{
		txtAppId = createEditText(R.id.editTextAppId, SharedSettingsKeys.LAST_APP_ID, "0");
		txtServerURL = createEditText(R.id.editTextServerURL, SharedSettingsKeys.LAST_SERVER_URL, Constants.SERVER_DEFAULT_URL);
		btnPresent = (Button) findViewById(R.id.btn_present);
		progressBar = (ProgressBar) findViewById(R.id.progressBar);
		listView = createListView();
		txtGoogleAdvertisementId = (TextView) findViewById(R.id.textGoogleAdvertisementId);
		Button button = (Button) findViewById(R.id.copyToClipboardButton);
		button.setOnClickListener(new OnClickListener()
        {
            @SuppressLint("NewApi")
            @Override
            public void onClick(View v)
            {   
                try
                {
                    String text = txtGoogleAdvertisementId.getText().toString();
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE); 
                    clipboard.setText(text);
                    
                    Debug.showToast(MainActivity.this, "Copied to clipboard");
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
	}

	private void setState(State state)
	{
		int buttonTitleId = R.string.btn_try_present;
		int progressVisiblity = View.INVISIBLE;

		switch (state)
		{
		case NotLoaded:
		case Failed:
			break;

		case Loading:
			progressVisiblity = View.VISIBLE;
			break;

		case Loaded:
			buttonTitleId = R.string.btn_present;
			break;
		}

		btnPresent.setText(getString(buttonTitleId));
		progressBar.setVisibility(progressVisiblity);
		
		try
        {
            PackageManager manager = getPackageManager();
            PackageInfo info = manager.getPackageInfo(getPackageName(), 0);
            setTitle("GPNDebug - " + Constants.SDK_VERSION + " build " + info.versionCode);
        }
        catch (NameNotFoundException e)
        {
            e.printStackTrace();
        }
	}

	private ListView createListView()
	{
		String[] list = new String[0];

		ListView listView = (ListView) findViewById(R.id.listView);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
		listView.setAdapter(adapter);
		listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

		return listView;
	}

	////////////////////////////////////////////////////////////////
	// Activity for result

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		if (requestCode == REQUEST_CODE_SERVER_PICK)
		{
			if (resultCode == RESULT_OK)
			{
				String url = data.getStringExtra(ServerPickActivity.EXTRA_URL);
				txtServerURL.setText(url);
			}
		}
		else if (requestCode == REQUEST_CODE_ENTRY_EDIT)
		{
			if (resultCode == RESULT_OK)
			{
				int index = data.getIntExtra(EntryParamActivity.EXTRA_INDEX, -1);
				if (currentEntry != null)
				{
					currentEntry.currentIndex = index;
					currentEntry = null;

					setEntires(entries);
				}
			}
		}
	}
	
	////////////////////////////////////////////////////////////////
    // Shared settings
	
	private void initSharedSettings()
    {
        SharedSettings.create(this);
        SharedSettings s = SharedSettings.instance();
        
        s.setFirst(getString(R.string.pref_key_timers_heartbeat_timer_enabled), Settings.DEFAULT_HEARTBEAT_ENABLED);
        s.setFirst(getString(R.string.pref_key_timers_heartbeat_timeout), Settings.DEFAULT_HEARTBEAT_TIMEOUT);
        s.setFirst(getString(R.string.pref_key_timers_heartbeat_should_restart), Settings.DEFAULT_HEARTBEAT_SHOULD_RESTART);
        s.setFirst(getString(R.string.pref_key_timers_heartbeat_should_close), Settings.DEFAULT_HEARTBEAT_SHOULD_CLOSE);
        
        s.setFirst(getString(R.string.pref_key_timers_loading_timer_enabled), Settings.DEFAULT_LOADING_TIMER_ENABLED);
        s.setFirst(getString(R.string.pref_key_timers_loading_timeout), Settings.DEFAULT_LOADING_TIMEOUT);
        
        s.setFirst(getString(R.string.pref_key_timers_presenting_timer_enabled), Settings.DEFAULT_PRESENTING_TIMER_ENABLED);
        s.setFirst(getString(R.string.pref_key_timers_presenting_timeout), Settings.DEFAULT_PRESENTING_TIMEOUT);
        
        s.setFirst(getString(R.string.pref_key_timers_ignores_heartbeat), false);
    }
	
	private void initSharedSettingsValues()
	{
	    updateFromSettings(Global.getSettings());
	    CrossPromotionImpl impl = Global.getImpl();
	    if (impl != null)
	    {
	        impl.setSettingsListener(this);
	    }
	}

    private void updateFromSettings(Settings settings)
    {
        settings.setHeartbeatEnabled(SharedSettings.instance().getBoolean(getString(R.string.pref_key_timers_heartbeat_timer_enabled)));
	    settings.setHeartbeatTimeout(SharedSettings.instance().getInt(getString(R.string.pref_key_timers_heartbeat_timeout)));
	    settings.setRestartOnHeartbeatTimeout(SharedSettings.instance().getBoolean(getString(R.string.pref_key_timers_heartbeat_should_restart)));
	    settings.setForceCloseOnHeartbeatTimeout(SharedSettings.instance().getBoolean(getString(R.string.pref_key_timers_heartbeat_should_close)));
	    
	    settings.setLoadingTimerEnabled(SharedSettings.instance().getBoolean(getString(R.string.pref_key_timers_loading_timer_enabled)));
	    settings.setLoadingTimeout(SharedSettings.instance().getInt(getString(R.string.pref_key_timers_loading_timeout)));
	    
	    settings.setPresentingTimerEnabled(SharedSettings.instance().getBoolean(getString(R.string.pref_key_timers_presenting_timer_enabled)));
	    settings.setPresentingTimeout(SharedSettings.instance().getInt(getString(R.string.pref_key_timers_presenting_timeout)));
	    
	    DebugCheat.disableHeartbeatCommand = SharedSettings.instance().getBoolean(getString(R.string.pref_key_timers_ignores_heartbeat));
	    DebugCheat.disableCompleteCommand = SharedSettings.instance().getBoolean(getString(R.string.pref_key_timers_ignores_complete));
	    DebugCheat.disablePresentedCommand = SharedSettings.instance().getBoolean(getString(R.string.pref_key_timers_ignores_presented));
    }
    
    private void updateFromServer(Settings settings)
    {
        SharedSettings.instance().setBoolean(getString(R.string.pref_key_timers_heartbeat_timer_enabled), settings.isHeartbeatEnabled());
        SharedSettings.instance().setFloat(getString(R.string.pref_key_timers_heartbeat_timeout), settings.getHeartbeatTimeout());
        SharedSettings.instance().setBoolean(getString(R.string.pref_key_timers_heartbeat_should_restart), settings.isRestartOnHeartbeatTimeout());
        SharedSettings.instance().setBoolean(getString(R.string.pref_key_timers_heartbeat_should_close), settings.isForceCloseOnHeartbeatTimeout());
        
        SharedSettings.instance().setBoolean(getString(R.string.pref_key_timers_loading_timer_enabled), settings.isLoadingTimerEnabled());
        SharedSettings.instance().setInt(getString(R.string.pref_key_timers_loading_timeout), settings.getLoadingTimeout());
        
        SharedSettings.instance().setBoolean(getString(R.string.pref_key_timers_presenting_timer_enabled), settings.isPresentingTimerEnabled());
        SharedSettings.instance().setInt(getString(R.string.pref_key_timers_presenting_timeout), settings.getPresentingTimeout());
        
        SharedSettings.instance().save();
    }
    
    ////////////////////////////////////////////////////////////////
    // Google advertiser id
    
    private void ResolveGoogleAppId()
    {
        GoogleAdvertisingID.getId(this, new ResolveListener()
        {
            @Override
            public void onGoogleAdvertisingIDResolved(Info info)
            {
                txtGoogleAdvertisementId.setText(info.getId());
            }
            
            @Override
            public void onGoogleAdvertisingIDResolveError(int code, String message)
            {
                txtGoogleAdvertisementId.setText("Unable to resolve Google Advertiser ID");
            }
        });
    }
	
	////////////////////////////////////////////////////////////////
	// Getters/Setters

	private String getAppId()
	{
		return txtAppId.getText().toString();
	}

	private String getServerURL()
	{
		return txtServerURL.getText().toString();
	}

	////////////////////////////////////////////////////////////////
	// Params

	private void loadEntryParams(final String url)
	{
		JSONLoadingTask task = new JSONLoadingTask(url, new JSONLoadingTask.Listener()
		{
			@Override
			public void onJsonReceived(String url, JSONObject jsonObject)
			{
				entries = extractEntries(new JSON(jsonObject));
				if (entries != null)
				{
					setEntires(entries);
				}
			}

			@Override
			public void onJsonFailed(String url, String message)
			{
				Toast.makeText(MainActivity.this, "Can't get params", Toast.LENGTH_LONG).show();
			}

			private ParamEntry[] extractEntries(JSON json)
			{
				JSONArray params = json.arrayForKey("params");
				if (params == null)
				{
					return null;
				}

				ParamEntry[] entries = new ParamEntry[params.length()];
				for (int i = 0; i < params.length(); ++i)
				{
					JSON param = params.getJSON(i);
					if (param == null)
					{
						return null;
					}

					JSON entryJson = param.jsonForKey("entry");
					if (entryJson == null)
					{
						return null;
					}

					String name = entryJson.stringForKey("name", null);
					if (name == null)
					{
						return null;
					}

					String[] values = entryJson.stringArrayForKey("values");
					if (values == null)
					{
						return null;
					}

					int current = entryJson.intForKey("current", -1);
					ParamEntry entry = new ParamEntry(name, values);
					entry.currentIndex = current;

					entries[i] = entry;
				}

				return entries;
			}
		});
		task.execute();
	}

	private void setEntires(final ParamEntry[] entries)
	{
		String[] list = new String[entries.length];
		for (int i = 0; i < entries.length; ++i)
		{
			list[i] = entries[i].toString();
		}

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, list);
		listView.setAdapter(adapter);

		listView.setOnItemClickListener(new OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				currentEntry = entries[position];

				Intent intent = new Intent(MainActivity.this, EntryParamActivity.class);
				intent.putExtra(EntryParamActivity.PARAM_ENTRY, currentEntry);
				startActivityForResult(intent, REQUEST_CODE_ENTRY_EDIT);
			}
		});
	}

	private Map<String, Object> createPresentParams()
	{
		if (entries != null)
		{
			Map<String, Object> map = new HashMap<String, Object>();
			for (ParamEntry e : entries)
			{
				String value = e.currentValue();
				if (value != null)
				{
					map.put(e.getName(), value);
				}
			}
			return map.size() > 0 ? map : null;
		}
		return null;
	}
	
	////////////////////////////////////////////////////////////////
    // Settings listener

    @Override
    public void onSettingsLoaded(Settings settings)
    {
        updateFromServer(settings);
        Debug.showToast(this, "Settings updated");
    }
}
