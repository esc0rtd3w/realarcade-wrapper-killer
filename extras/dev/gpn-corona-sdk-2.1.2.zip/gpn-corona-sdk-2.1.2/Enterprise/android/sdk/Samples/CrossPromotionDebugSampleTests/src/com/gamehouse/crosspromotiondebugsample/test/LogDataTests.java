//
//  LogDataTests.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample.test;

import android.test.AndroidTestCase;

import com.gamehouse.crosspromotiondebugsample.debug.LogData;

public class LogDataTests extends AndroidTestCase
{
	public void testAppendLines()
	{
		String[] testData = { "1", "2", "3" };
		
		LogData data = new LogData(testData.length);
		for (int i = 0; i < testData.length; i++)
		{
			data.append(testData[i]);
		}
		
		assertData(data, testData);
	}
	
	public void testAppendOverflow()
	{
		String[] testData = { "1", "2", "3", "4" };
		
		LogData data = new LogData(3);
		for (int i = 0; i < testData.length; i++)
		{
			data.append(testData[i]);
		}
		
		assertData(data, "2", "3", "4");
	}
	
	public void testAppendOverflow2()
	{
		String[] testData = { "1", "2", "3", "4", "5"};
		
		LogData data = new LogData(3);
		for (int i = 0; i < testData.length; i++)
		{
			data.append(testData[i]);
		}
		
		assertData(data, "3", "4", "5");
	}
	
	public void testAppendOverflow3()
	{
		String[] testData = { "1", "2", "3", "4", "5", "6" };
		
		LogData data = new LogData(3);
		for (int i = 0; i < testData.length; i++)
		{
			data.append(testData[i]);
		}
		
		assertData(data, "4", "5", "6");
	}
	
	public void testAppendOverflow4()
	{
		String[] testData = { "1", "2", "3", "4", "5", "6", "7" };
		
		LogData data = new LogData(3);
		for (int i = 0; i < testData.length; i++)
		{
			data.append(testData[i]);
		}
		
		assertData(data, "5", "6", "7");
	}
	
	public void testAppendOverflow5()
	{
		String[] testData = { "1", "2", "3", "4", "5", "6", "7", "8" };
		
		LogData data = new LogData(3);
		for (int i = 0; i < testData.length; i++)
		{
			data.append(testData[i]);
		}
		
		assertData(data, "6", "7", "8");
	}
	
	private void assertData(LogData data, String... testData)
	{
		assertEquals(testData.length, data.getLength());
		for (int i = 0; i < testData.length; i++)
		{
			assertEquals(testData[i], data.get(i));
		}
	}
}
