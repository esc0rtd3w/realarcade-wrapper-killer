//
//  GPNEventInterstitial.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.admob;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.VERBOSE;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.util.Log;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView.InterstitialResult;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdViewListener;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.customevent.CustomEventInterstitial;
import com.google.ads.mediation.customevent.CustomEventInterstitialListener;

public class GPNEventInterstitial implements CustomEventInterstitial, InterstitialAdViewListener
{
    private static final String PARAM_MEDIATION = "mediation[name]";
    private static final String PARAM_MEDIATION_VERSION = "mediation[version]";

    private static final String MEDIATION_VERSION = "1.1.0";

    private static final String TAG = "GPN";

    private CustomEventInterstitialListener listener; // should store a strong reference
    private WeakReference<Activity> activityRef;

    private Map<String, Object> paramsMap;

    private boolean shouldNotifyMediationDelegate;

    @Override
    public void requestInterstitialAd(CustomEventInterstitialListener listener, Activity activity, String label, String serverParam, MediationAdRequest request, Object extra)
    {
        try
        {
            this.listener = listener;
            activityRef = new WeakReference<Activity>(activity);

            shouldNotifyMediationDelegate = true;

            requestInterstitialAd(activity);
        }
        catch (Exception e)
        {
            logException(e, "Unable to request an interstitial: exception is thrown");
            notifyFailed();
        }
    }

    @Override
    public void showInterstitial()
    {
        try
        {
            presentInterstitial();
        }
        catch (Exception e)
        {
            logException(e, "Unable to show an interstitial: exception is thrown");
            notifyFailed();
        }
    }

    @Override
    public void destroy()
    {
        CrossPromotion.instance().stopRequestingInterstitials();
        shouldNotifyMediationDelegate = false;
    }

    private void requestInterstitialAd(Activity activity)
    {
        if (!CrossPromotion.isInitialized())
        {
            Log.e(TAG, "Can't request interstitial: GPN is not initialized");
            notifyFailed();
            return;
        }

        InterstitialAdView adView = Global.getCurrentAdView();
        if (adView != null && adView.isLoaded())
        {
            logDebug("Promotion is already loaded. Notifying delegate...");
            notifyReceived();
        }
        else
        {
            logDebug("Start requesting interstitials...");
            CrossPromotion.instance().startRequestingInterstitials(this);
        }
    }

    private void presentInterstitial()
    {
        Activity activity = getActivity();
        if (activity == null)
        {
            Log.e(TAG, "Unable to present interstitial: activity reference is missing");
            notifyFailed();
        }
        else if (!CrossPromotion.isInitialized())
        {
            Log.e(TAG, "Unable to present interstitial: GPN is not initialized");
            notifyFailed();
        }
        else
        {
            InterstitialResult result = CrossPromotion.instance().present(activity);
            if (result != InterstitialResult.Presented)
            {
                Log.e(TAG, "Interstitial is not presented");
                notifyFailed();
            }
        }
    }

    ////////////////////////////////////////////////////////////////
    // CustomEventInterstitialListener notifications

    private void notifyReceived()
    {
        CustomEventInterstitialListener listener = getListener();
        if (listener != null)
        {
            listener.onReceivedAd();
        }
    }

    private void notifyFailed()
    {
        CustomEventInterstitialListener listener = getListener();
        if (listener != null)
        {
            listener.onFailedToReceiveAd();
        }
    }

    private void notifyOpened()
    {
        CustomEventInterstitialListener listener = getListener();
        if (listener != null)
        {
            listener.onPresentScreen();
        }
    }

    private void notifyClosed()
    {
        CustomEventInterstitialListener listener = getListener();
        if (listener != null)
        {
            listener.onDismissScreen();
        }
    }

    private void notifyApplicationLeave()
    {
        CustomEventInterstitialListener listener = getListener();
        if (listener != null)
        {
            listener.onLeaveApplication();
        }
    }

    ////////////////////////////////////////////////////////////////
    // InterstitialAdViewListener

    @Override
    public void onInterstitialAdReceive(InterstitialAdView adView)
    {
        if (shouldNotifyMediationDelegate)
        {
            shouldNotifyMediationDelegate = false;
            notifyReceived();
        }
    }

    @Override
    public void onInterstitialAdFail(InterstitialAdView adView, int code, String reason)
    {
        if (shouldNotifyMediationDelegate)
        {
            shouldNotifyMediationDelegate = false;
            notifyFailed();
        }
    }

    @Override
    public void onInterstitialAdOpen(InterstitialAdView adView)
    {
        notifyOpened();
    }

    @Override
    public void onInterstitialAdClose(InterstitialAdView adView)
    {
        notifyClosed();
    }

    @Override
    public void onInterstitialAdLeaveApplication(InterstitialAdView adView)
    {
        notifyApplicationLeave();
    }

    @Override
    public Map<String, Object> createInterstitialAdParams()
    {
        if (paramsMap == null)
        {
            paramsMap = new HashMap<String, Object>();
            paramsMap.put(PARAM_MEDIATION, "admob");
            paramsMap.put(PARAM_MEDIATION_VERSION, MEDIATION_VERSION);
        }
        return paramsMap;
    }

    ////////////////////////////////////////////////////////////////
    // Helpers

    private CustomEventInterstitialListener getListener()
    {
        return listener;
    }

    private Activity getActivity()
    {
        return activityRef != null ? activityRef.get() : null;
    }

    private void logDebug(String format, Object... args)
    {
        com.gamehouse.crosspromotion.implementation.utils.Log.d(VERBOSE, format, args);
    }

    private void logException(Throwable t, String format, Object... args)
    {
        com.gamehouse.crosspromotion.implementation.utils.Log.logException(t, format, args);
    }
}
