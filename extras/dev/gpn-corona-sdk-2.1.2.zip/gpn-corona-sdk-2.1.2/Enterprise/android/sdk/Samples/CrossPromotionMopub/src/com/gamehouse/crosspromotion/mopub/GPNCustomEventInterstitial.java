//
//  GPNCustomEventInterstitial.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.mopub;

import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.util.Log;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdViewListener;
import com.mopub.mobileads.CustomEventInterstitial;
import com.mopub.mobileads.MoPubErrorCode;

public class GPNCustomEventInterstitial extends CustomEventInterstitial implements InterstitialAdViewListener
{
    private static final String TAG = "CrossPromotion";
    private static final String PARAM_MEDIATION = "mediation[name]";
    private static final String PARAM_MEDIATION_VERSION = "mediation[version]";
    
    private static final String MEDIATION_VERSION = "1.0.0";

    private WeakReference<CustomEventInterstitialListener> listenerRef;
    private WeakReference<Context> contextRef;

    private boolean shouldNotifyMediationDelegate;

    private Map<String, Object> paramsMap;

    @Override
    protected void loadInterstitial(Context context, CustomEventInterstitialListener listener, Map<String, Object> localExtras, Map<String, String> serverExtras)
    {
        contextRef = new WeakReference<Context>(context);
        listenerRef = new WeakReference<CustomEventInterstitialListener>(listener);
        shouldNotifyMediationDelegate = true;

        if (!CrossPromotion.isInitialized())
        {
            Log.e(TAG, "Can't start requesting interstitials: CrossPromotion instance is not initialized");
            listener.onInterstitialFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
            return;
        }

        InterstitialAdView adView = Global.getCurrentAdView();
        if (adView != null && adView.isLoaded())
        {
            Log.d(TAG, "Promotion is already loaded. Notifying delegate...");
            listener.onInterstitialLoaded();
        }
        else
        {
            CrossPromotion.instance().startRequestingInterstitials(this);
        }
    }

    @Override
    protected void onInvalidate()
    {
        CrossPromotion.instance().stopRequestingInterstitials();
        shouldNotifyMediationDelegate = false;
    }

    @Override
    protected void showInterstitial()
    {
        Context context = getContext();
        if (context != null)
        {
            if (CrossPromotion.isInitialized())
            {
                CrossPromotion.instance().present(context);
            }
            else
            {
                Log.e(TAG, "Can't start requesting interstitials: CrossPromotion instance is not initialized");

                CustomEventInterstitialListener listener = getListener();
                if (listener != null)
                {
                    listener.onInterstitialFailed(MoPubErrorCode.ADAPTER_CONFIGURATION_ERROR);
                }
            }
        }
        else
        {
            Log.e(TAG, "Can't present interstitial: context is null");
        }
    }

    ////////////////////////////////////////////////////////////////
    // InterstitialAdViewListener

    @Override
    public void onInterstitialAdReceive(InterstitialAdView adView)
    {
        if (shouldNotifyMediationDelegate)
        {
            shouldNotifyMediationDelegate = false;
            CustomEventInterstitialListener listener = getListener();
            if (listener != null)
            {
                listener.onInterstitialLoaded();
            }
            else
            {
                Log.e(TAG, "Can't notify CustomEventInterstitialListener.onInterstitialLoaded(): reference is lost");
            }
        }
    }

    @Override
    public void onInterstitialAdFail(InterstitialAdView adView, int code, String reason)
    {
        if (shouldNotifyMediationDelegate)
        {
            shouldNotifyMediationDelegate = false;
            CustomEventInterstitialListener listener = getListener();
            if (listener != null)
            {
                listener.onInterstitialFailed(MoPubErrorCode.INTERNAL_ERROR);
            }
            else
            {
                Log.e(TAG, "Can't notify CustomEventInterstitialListener.onInterstitialFailed(): reference is lost");
            }
        }
    }

    @Override
    public void onInterstitialAdOpen(InterstitialAdView adView)
    {
        CustomEventInterstitialListener listener = getListener();
        if (listener != null)
        {
            listener.onInterstitialShown();
        }
        else
        {
            Log.e(TAG, "Can't notify CustomEventInterstitialListener.onInterstitialShown(): reference is lost");
        }
    }

    @Override
    public void onInterstitialAdClose(InterstitialAdView adView)
    {
        CustomEventInterstitialListener listener = getListener();
        if (listener != null)
        {
            listener.onInterstitialDismissed();
        }
        else
        {
            Log.e(TAG, "Can't notify CustomEventInterstitialListener.onInterstitialDismissed(): reference is lost");
        }
    }

    @Override
    public void onInterstitialAdLeaveApplication(InterstitialAdView adView)
    {
    }

    @Override
    public Map<String, Object> createInterstitialAdParams()
    {
        if (paramsMap == null)
        {
            paramsMap = new HashMap<String, Object>();
            paramsMap.put(PARAM_MEDIATION, "mopub");
            paramsMap.put(PARAM_MEDIATION_VERSION, MEDIATION_VERSION);
        }
        return paramsMap;
    }

    ////////////////////////////////////////////////////////////////
    // Helpers

    public Context getContext()
    {
        return contextRef != null ? contextRef.get() : null;
    }

    public CustomEventInterstitialListener getListener()
    {
        return listenerRef != null ? listenerRef.get() : null;
    }
}
