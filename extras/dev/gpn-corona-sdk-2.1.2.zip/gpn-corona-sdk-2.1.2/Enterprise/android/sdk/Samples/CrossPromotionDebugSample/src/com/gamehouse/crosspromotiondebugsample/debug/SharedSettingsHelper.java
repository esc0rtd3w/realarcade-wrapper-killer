//
//  SharedSettingsHelper.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample.debug;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Toast;

public class SharedSettingsHelper
{
    public static void init(final EditText editText, final String key, int defValue)
    {
        int value = getSettings().getInt(key, defValue);
        editText.setText(Integer.toString(value));
        
        editText.addTextChangedListener(new TextWatcher()
        {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)
            {
            }
            
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after)
            {
            }
            
            @Override
            public void afterTextChanged(Editable s)
            {
                try
                {
                    int value = Integer.parseInt(s.toString());
                    getSettings().setInt(key, value);
                    getSettings().save();
                }
                catch (NumberFormatException e)
                {
                    Toast.makeText(editText.getContext(), "Wrong value", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    
	public static void init(EditText editText, final String key, String defValue)
	{
		String text = getSettings().getString(key, defValue);
		editText.setText(text);

		editText.addTextChangedListener(new TextWatcher()
		{
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count)
			{
			}

			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after)
			{
			}

			@Override
			public void afterTextChanged(Editable s)
			{
				getSettings().setString(key, s.toString());
				getSettings().save();
			}
		});
	}

	public static void init(CheckBox checkBox, final String key, boolean defValue)
	{
	    init(checkBox, key, defValue, null);
	}
	
	public static void init(CheckBox checkBox, final String key, boolean defValue, final OnCheckedChangeListener listener)
	{
		boolean flag = getSettings().getBoolean(key, defValue);
		checkBox.setChecked(flag);
		
		checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener()
		{
			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked)
			{
				getSettings().setBoolean(key, isChecked);
				getSettings().save();
				
				if (listener != null)
				{
				    listener.onCheckedChanged(buttonView, isChecked);
				}
			}
		});
	}
	
	private static SharedSettings getSettings()
	{
		return SharedSettings.instance();
	}
}
