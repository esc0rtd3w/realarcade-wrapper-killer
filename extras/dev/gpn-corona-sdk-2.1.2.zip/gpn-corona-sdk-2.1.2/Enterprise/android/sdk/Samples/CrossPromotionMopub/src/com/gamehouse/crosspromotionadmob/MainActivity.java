//
//  MainActivity.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotionadmob;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotionmopub.R;
import com.mopub.mobileads.MoPubErrorCode;
import com.mopub.mobileads.MoPubInterstitial;
import com.mopub.mobileads.MoPubInterstitial.InterstitialAdListener;

public class MainActivity extends Activity implements InterstitialAdListener
{
    private static final String TAG = "Sample";

    private static final String APP_ID = "0";
    private static final String AD_UNIT_ID = "1a641301a458487ea24ddf8488ddc9e5"; // set your ad unit here

    private TextView statusText;
    private MoPubInterstitial interstitial;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        CrossPromotion.initialize(this, APP_ID);

        interstitial = new MoPubInterstitial(this, AD_UNIT_ID);
        interstitial.setInterstitialAdListener(this);
        interstitial.load();

        statusText = (TextView) findViewById(R.id.textStatus);
    }
    
    @Override
    protected void onDestroy()
    {
        CrossPromotion.destroy();
        
        interstitial.destroy();
        super.onDestroy();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        CrossPromotion.instance().onPause();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        CrossPromotion.instance().onResume();
    }

    ////////////////////////////////////////////////////////////////
    // Event handlers

    public void onPresentClick(View view)
    {
        if (interstitial.isReady())
        {
            interstitial.show();
        }
        else
        {
            Toast.makeText(this, "Not ready yet", Toast.LENGTH_SHORT).show();
        }
    }

    ////////////////////////////////////////////////////////////////
    // InterstitialAdListener

    @Override
    public void onInterstitialClicked(MoPubInterstitial arg0)
    {
    }

    @Override
    public void onInterstitialDismissed(MoPubInterstitial arg0)
    {
        Log.d(TAG, "Interstitial dismissed");
        statusText.setText(R.string.status_idle);
        
        interstitial.load();
    }

    @Override
    public void onInterstitialFailed(MoPubInterstitial arg0, MoPubErrorCode code)
    {
        String message = "Interstitial failed: " + code;

        Log.e(TAG, message);
        statusText.setText(R.string.status_failed);

        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Error");
        alertDialog.setMessage(message);

        alertDialog.setButton(Dialog.BUTTON_POSITIVE, "OK", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int whichButton)
            {
                dialog.dismiss();
            }
        });
        alertDialog.show();
    }

    @Override
    public void onInterstitialLoaded(MoPubInterstitial arg0)
    {
        Log.d(TAG, "Interstitial loaded");
        statusText.setText(R.string.status_received);
    }

    @Override
    public void onInterstitialShown(MoPubInterstitial arg0)
    {
        Log.d(TAG, "Interstitial presented");
    }
}
