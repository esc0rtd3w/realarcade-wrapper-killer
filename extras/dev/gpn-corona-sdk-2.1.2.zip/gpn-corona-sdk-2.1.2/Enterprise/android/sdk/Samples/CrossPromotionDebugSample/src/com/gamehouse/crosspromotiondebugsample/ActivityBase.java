//
//  ActivityBase.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample;

import android.app.Activity;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.TextView.BufferType;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.settings.Settings;
import com.gamehouse.crosspromotion.implementation.utils.ClassUtils;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.DebugCheat;
import com.gamehouse.crosspromotion.implementation.utils.MemoryUtils;
import com.gamehouse.crosspromotiondebugsample.debug.SharedSettingsHelper;
import com.gamehouse.crosspromotiondebugsample.debug.timers.Timer;

public class ActivityBase extends Activity
{
	private TextView textFreeMemory;
	private TextView textUsedMemory;
	private TextView textHeapMemory;
	private TextView textTotalMemory;
	private TextView textIndicator;
	
	private View overlayView;


	private Timer updateTimer;

	////////////////////////////////////////////////////////////////
	// Activity callbacks

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
	}
	
	@Override
	protected void onStart()
	{
		super.onStart();
		addDebugUI();
	}

	@Override
	protected void onStop()
	{
		super.onStop();
		removeDebugUI();
	}

	@Override
	protected void onResume()
	{
		super.onResume();
		CrossPromotion.instance().onResume();
		startTimer();
	}
	
	@Override
	protected void onPause()
	{
		super.onPause();
		CrossPromotion.instance().onPause();
		stopTimer();
	}

	////////////////////////////////////////////////////////////////
	// Debug UI

	protected void addDebugUI()
	{
		FrameLayout root = ClassUtils.tryCast(findViewById(android.R.id.content), FrameLayout.class);
		if (root != null)
		{
			Debug.assertNull(overlayView, "overlayView");
			
			LayoutInflater inflater = LayoutInflater.from(this);
			overlayView = inflater.inflate(R.layout.layout_debug_overlay, root, false);

			textFreeMemory = initMutableTextView((TextView) overlayView.findViewById(R.id.text_free_memory));
			textUsedMemory = initMutableTextView((TextView) overlayView.findViewById(R.id.text_used_memory));
			textTotalMemory = initMutableTextView((TextView) overlayView.findViewById(R.id.text_total_memory));
			textHeapMemory = initMutableTextView((TextView) overlayView.findViewById(R.id.text_heap_memory));
			textIndicator = initMutableTextView((TextView) overlayView.findViewById(R.id.textIndicator));

			FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT); 
			params.gravity = Gravity.BOTTOM;
			
			updateIndicator();

			root.addView(overlayView, params);
		}
	}

	protected void removeDebugUI()
	{
		if (overlayView != null)
		{
			FrameLayout root = ClassUtils.tryCast(findViewById(android.R.id.content), FrameLayout.class);
			if (root != null)
			{
				root.removeView(overlayView);
				overlayView.setVisibility(View.GONE);
				overlayView = null;
			}
		}
	}

	////////////////////////////////////////////////////////////////
	// Update timer

	private void startTimer()
	{
		if (overlayView == null)
			return;
		
		if (updateTimer == null)
		{
			updateTimer = new Timer(new Runnable()
			{
				@Override
				public void run()
				{
					updateIndicator();
				}				

			}, 500, true);
			updateTimer.start();
		}
	}

	private void stopTimer()
	{
		if (updateTimer != null)
		{
			updateTimer.stop();
			updateTimer = null;
		}
	}
	
	////////////////////////////////////////////////////////////////
	// Info
	
	private void updateIndicator()
	{
		updateMemoryTextView(textFreeMemory, "F:", MemoryUtils.getAvailableMemory());
		updateMemoryTextView(textUsedMemory, "U:", MemoryUtils.getUsedMemory());
		updateMemoryTextView(textHeapMemory, "H:", MemoryUtils.getHeapMemory());
		updateMemoryTextView(textTotalMemory, "T:", MemoryUtils.getTotalMemory());
		updateIndicatorTextView(textIndicator);
	}

	private void updateMemoryTextView(TextView textView, String prefix, long bytes)
	{
		SpannableStringBuilder buffer = (SpannableStringBuilder) textView.getText();
		buffer.clear();
		buffer.append(prefix);
		MemoryUtils.appendMemString(buffer, bytes);
	}
	
	private void updateIndicatorTextView(TextView textView)
	{
		SpannableStringBuilder buffer = (SpannableStringBuilder) textView.getText();
		buffer.clear();

		if (Debug.isConnected())
		{
			buffer.append('R');
		}
		
		if (DebugGlobal.memoryAllocator.isAllocating())
		{
			buffer.append('M');
		}

		if (Debug.flag)
		{
            Settings settings = Global.getSettings();
            if (settings != null)
            {
                if (settings.isHeartbeatEnabled())
                {
                    if (settings.isForceCloseOnHeartbeatTimeout())
                    {
                        buffer.append('c');
                    }
                    if (settings.isRestartOnHeartbeatTimeout())
                    {
                        buffer.append('r');
                    }
                }
                else
                {
                    buffer.append('H');
                }
            }
    		
    		if (DebugCheat.disableHeartbeatCommand)
    		{
    		    buffer.append('J');
    		}
    		
    		if (DebugCheat.disableCompleteCommand)
    		{
    		    buffer.append('C');
    		}
    		
    		if (DebugCheat.disablePresentedCommand)
    		{
    		    buffer.append('P');
    		}
		}
	}

	////////////////////////////////////////////////////////////////
	// Helpers

	protected EditText createEditText(int id, String key, String defValue)
	{
		EditText editText = (EditText) findViewById(id);
		SharedSettingsHelper.init(editText, key, defValue);
		return editText;
	}
	
	protected EditText createEditText(int id, String key, int defValue)
	{
	    EditText editText = (EditText) findViewById(id);
	    SharedSettingsHelper.init(editText, key, defValue);
	    return editText;
	}
	
	protected CheckBox createCheckBox(int id, String key, boolean defValue)
	{
	    return createCheckBox(id, key, defValue, null);
	}
	
	protected CheckBox createCheckBox(int id, String key, boolean defValue, OnCheckedChangeListener listener)
	{
	    CheckBox checkBox = (CheckBox) findViewById(id);
	    SharedSettingsHelper.init(checkBox, key, defValue, listener);
	    return checkBox;
	}
	
	protected TextView initMutableTextView(TextView textView)
	{
		textView.setText(textView.getText(), BufferType.EDITABLE);
		return textView;
	}
}
