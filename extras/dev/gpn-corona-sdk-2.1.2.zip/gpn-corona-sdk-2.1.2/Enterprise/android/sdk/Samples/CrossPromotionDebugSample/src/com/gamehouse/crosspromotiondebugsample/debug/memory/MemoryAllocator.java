//
//  MemoryAllocator.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample.debug.memory;

import java.lang.ref.WeakReference;

import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.MemoryUtils;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class MemoryAllocator
{
	private Thread thread;
	private WeakReference<Listener> listenerRef;
	
	private long totalAllocated;
	
	private Chunk root;
	
	public void startAllocate(final Settings settings)
	{
		stopAllocating();
		
		thread = new Thread(new Runnable()
		{
			@Override
			public void run()
			{
				int allocationSize = (int) MemoryUtils.megabytesToBytes(settings.getSize());
				int freeLimit = (int) MemoryUtils.megabytesToBytes(settings.getFreeMemoryLimit());
				long delay = settings.getDelay();
				
				totalAllocated = 0;
				root = null;
				
				Log.d(VERBOSE, "Start allocating: chunk=%s delay=%s ms", MemoryUtils.toMemString(allocationSize), delay);
				
				try
				{
					boolean shouldBreak = false;
					while (!Thread.interrupted())
					{
						if (freeLimit > 0)
						{
							int available = (int) MemoryUtils.getAvailableMemory();
							if (available - allocationSize < freeLimit)
							{
								allocationSize = available - freeLimit;
								shouldBreak = true;
							}
						}
						
						// TODO: stop on memory warning
						
						Chunk chunk = new Chunk(allocationSize);
						chunk.next = root;
						root = chunk;
						
						totalAllocated += allocationSize;
						notifyAllocation(allocationSize);
						
						if (shouldBreak)
						{
							break;
						}
						
						try { Thread.sleep(delay); } catch (InterruptedException e) { break; }
					}
				}
				catch (Exception e)
				{
					Log.e(VERBOSE, "Allocation interrupted: %s", e.getMessage());
				}
				
				notifyStopAllocation();
				
				Log.d(VERBOSE, "Stoped allocating. Total allocated: %s", MemoryUtils.toMemString(totalAllocated));
				if (settings.isFreeOnFinish())
				{
					freeAllocatedMemory();
				}
				
				thread = null;
			}
		});
		thread.start();
	}
	
	////////////////////////////////////////////////////////////////
	// Listener
	
	private synchronized void notifyAllocation(int size)
	{
		Listener listener = getListener();
		if (listener != null) {
			listener.onChunkAllocate(this, size);
		}
	}
	
	private synchronized void notifyStopAllocation()
	{
		Listener listener = getListener();
		if (listener != null) {
			listener.onStopAllocation(this);
		}
	}
	
	public synchronized void setListener(Listener listener)
	{
		if (listener != null)
		{
			listenerRef = new WeakReference<Listener>(listener);
		}
		else
		{
			listenerRef = null;
		}
	}
	
	public Listener getListener()
	{
		return listenerRef != null ? listenerRef.get() : null;
	}
	
	////////////////////////////////////////////////////////////////
	// Getters/Setters
	
	public void stopAllocating()
	{
		if (thread != null)
		{
			thread.interrupt();
			thread = null;
		}
	}
	
	public void freeAllocatedMemory()
	{
		root = null;
		totalAllocated = 0;
		System.gc();
	}
	
	public boolean isAllocating()
	{
		return thread != null;
	}
	
	public long getTotalAllocated()
	{
		return totalAllocated;
	}
	
	static class Chunk
	{
		public byte[] bytes;
		public Chunk next;
		
		public Chunk(int size)
		{
			bytes = new byte[size];
		}
	}
	
	public static interface Listener
	{
		void onChunkAllocate(MemoryAllocator allocator, int size);
		void onStopAllocation(MemoryAllocator allocator);
	}
	
	public static class Settings
	{
		private int size;
		private long delay;
		private int freeMemoryLimit;
		
		private boolean freeOnFinish;
		private boolean stopOnMemoryWarning;
		
		public Settings(int size, long delay)
		{
			this.size = size;
			this.delay = delay;
		}
		
		public int getSize()
		{
			return size;
		}
		
		public long getDelay()
		{
			return delay;
		}

		public int getFreeMemoryLimit()
		{
			return freeMemoryLimit;
		}

		public void setFreeMemoryLimit(int freeMemoryLimit)
		{
			this.freeMemoryLimit = freeMemoryLimit;
		}

		public boolean isFreeOnFinish()
		{
			return freeOnFinish;
		}

		public void setFreeOnFinish(boolean freeOnFinish)
		{
			this.freeOnFinish = freeOnFinish;
		}

		public boolean isStopOnMemoryWarning()
		{
			return stopOnMemoryWarning;
		}

		public void setStopOnMemoryWarning(boolean stopOnMemoryWarning)
		{
			this.stopOnMemoryWarning = stopOnMemoryWarning;
		}
	}
}
