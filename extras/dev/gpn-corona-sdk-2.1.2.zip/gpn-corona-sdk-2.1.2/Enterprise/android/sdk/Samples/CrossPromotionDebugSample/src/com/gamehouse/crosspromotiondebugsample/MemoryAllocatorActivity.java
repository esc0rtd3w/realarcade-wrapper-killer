//
//  MemoryAllocatorActivity.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.VERBOSE;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.BufferType;
import android.widget.Toast;

import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.MemoryUtils;
import com.gamehouse.crosspromotion.implementation.utils.ThreadUtils;
import com.gamehouse.crosspromotiondebugsample.debug.SharedSettingsKeys;
import com.gamehouse.crosspromotiondebugsample.debug.memory.MemoryAllocator;

public class MemoryAllocatorActivity extends ActivityBase implements MemoryAllocator.Listener
{
	private static int DEFAULT_CHUNK_SIZE = 1;
	private static int DEFAULT_CHUNK_DELAY = 200;
	private static int DEFAULT_STOP_WHEN_FREE = 10;

	private EditText chunkSizeText;
	private EditText chunkDelayText;
	private EditText stopMemoryLeftText;

	private CheckBox checkFreeOnFinish;
	private CheckBox checkStopOnMemoryWarning;

	private TextView textStatus;
	private Button startStopButton;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_memory_allocator);

		chunkSizeText = createEditText(R.id.editChunkSize, SharedSettingsKeys.Memory.LAST_CHUNK_SIZE, DEFAULT_CHUNK_SIZE);
		chunkDelayText = createEditText(R.id.editChunkDelay, SharedSettingsKeys.Memory.LAST_CHUNK_DELAY, DEFAULT_CHUNK_DELAY);
		stopMemoryLeftText = createEditText(R.id.editStopMemoryLeft, SharedSettingsKeys.Memory.LAST_STOP_WHEN_FREE, DEFAULT_STOP_WHEN_FREE);

		checkFreeOnFinish = createCheckBox(R.id.checkFreeOnFinish, SharedSettingsKeys.Memory.LAST_FLAG_FREE_ON_FINISH, true);
		checkStopOnMemoryWarning = createCheckBox(R.id.checkStopOnWarning, SharedSettingsKeys.Memory.LAST_FLAG_STOP_ON_WARNING, true);

		textStatus = initMutableTextView(R.id.textStatus);
		startStopButton = (Button) findViewById(R.id.buttonStart);
	}

	private TextView initMutableTextView(int id)
	{
		TextView textView = (TextView) findViewById(id);
		textView.setText(textView.getText(), BufferType.EDITABLE);
		return textView;
	}

	@Override
	protected void onDestroy()
	{
		super.onDestroy();
		getAllocator().setListener(null);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.memory_allocator, menu);
		return true;
	}

	@Override
	public void onLowMemory()
	{
		super.onLowMemory();
		Log.d(VERBOSE, "Low memory callback: %s", MemoryUtils.toMegabytes(MemoryUtils.getAvailableMemory()));

		getAllocator().stopAllocating();
	}

	@Override
	public void onTrimMemory(int level)
	{
		super.onTrimMemory(level);
		Log.e(VERBOSE, "Trim memory: %d", level);
	}

	public void onStartClick(View v)
	{
		Button button = (Button) v;

		if (isAllocating())
		{
			stopAllocator();
			button.setText("Start");
		}
		else
		{
			// size
			int size = parseText(chunkSizeText, 0);
			if (size <= 0)
			{
				Toast.makeText(this, "Invalid chunk size", Toast.LENGTH_SHORT).show();
				return;
			}

			// delay
			int delay = parseText(chunkDelayText, 0);
			if (size <= 0)
			{
				Toast.makeText(this, "Invalid chunk delay", Toast.LENGTH_LONG).show();
				return;
			}
			
			// free memory on finish
			boolean freeOnFinish = checkFreeOnFinish.isChecked();
			
			// stop on memory warning
			boolean stopOnMemoryWarning = checkStopOnMemoryWarning.isChecked();
			
			// free memory limit
			int freeMemory = 0;
			if (!stopOnMemoryWarning)
			{
				freeMemory = parseText(stopMemoryLeftText, 0);
			}
			
			MemoryAllocator.Settings settings = new MemoryAllocator.Settings(size, delay);
			settings.setFreeOnFinish(freeOnFinish);
			settings.setStopOnMemoryWarning(stopOnMemoryWarning);
			settings.setFreeMemoryLimit(freeMemory);
			
			startAllocating(settings);

			button.setText("Stop");
		}
	}

	public void onFreeMemoryClick(View v)
	{
		getAllocator().freeAllocatedMemory();
		updateAllocatorStatus(getAllocator().getTotalAllocated());
	}

	////////////////////////////////////////////////////////////////
	// Allocator

	private boolean isAllocating()
	{
		return getAllocator().isAllocating();
	}

	private void startAllocating(MemoryAllocator.Settings settings)
	{
		getAllocator().setListener(this);
		getAllocator().startAllocate(settings);
	}

	private void stopAllocator()
	{
		getAllocator().stopAllocating();
		getAllocator().setListener(null);
	}

	private MemoryAllocator getAllocator()
	{
		return DebugGlobal.memoryAllocator;
	}
	
	////////////////////////////////////////////////////////////////
	// MemoryAllocator.Listener
	
	private long statusUpdateTimestamp;
	private AllocatorStatusUpdater statusUpdater = new AllocatorStatusUpdater();
	
	
	@Override
	public void onChunkAllocate(MemoryAllocator allocator, int size)
	{
		long current = System.currentTimeMillis();
		long elasped = current - statusUpdateTimestamp;
		if (elasped >= 500)
		{
			statusUpdater.updateStatus(allocator.getTotalAllocated());
			statusUpdateTimestamp = current;
		}
	}

	@Override
	public void onStopAllocation(final MemoryAllocator allocator)
	{
		ThreadUtils.runOnUiThread(new Runnable()
		{
			@Override
			public void run()
			{
				Debug.showToast(MemoryAllocatorActivity.this, "Allocator stoppepd");
				startStopButton.setText("Start");
				updateAllocatorStatus(allocator.getTotalAllocated());
			}
		});
	}
	
	private void updateAllocatorStatus(long bytesAllocated)
	{
		SpannableStringBuilder buffer = (SpannableStringBuilder) textStatus.getText();
		buffer.clear();
		buffer.append("Total allocated: ");
		MemoryUtils.appendMemString(buffer, bytesAllocated);
	}
	
	////////////////////////////////////////////////////////////////
	// Helpers
	
	private int parseText(EditText editText, int defValue)
	{
		String text = editText.getText().toString();
		try
		{
			return Integer.parseInt(text);
		}
		catch (NumberFormatException e)
		{
		}
		
		return defValue;
	}
	
	class AllocatorStatusUpdater implements Runnable
	{
		private long bytesAllocated;
		
		public void updateStatus(long bytesAllocated)
		{
			this.bytesAllocated = bytesAllocated;
			ThreadUtils.runOnUiThread(this);
		}
		
		@Override
		public void run()
		{
			updateAllocatorStatus(bytesAllocated);
		}
	}
}
