//
//  MainActivity.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotionsample;

import java.util.Map;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView.InterstitialResult;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdViewListener;

public class MainActivity extends Activity implements InterstitialAdViewListener
{
	private static final String TAG = "GPN";

	private ProgressBar progressBar;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		progressBar = (ProgressBar) findViewById(R.id.pbar_busy);

		CrossPromotion.initialize(this, "0"); // TODO: place you app id here
	}

	@Override
	protected void onPause()
	{
		super.onPause();
		CrossPromotion.instance().onPause();
	}

	@Override
	protected void onResume()
	{
		super.onResume();
		CrossPromotion.instance().onResume();
	}

	@Override
	protected void onDestroy()
	{
		CrossPromotion.destroy();
		super.onDestroy();
	}

	////////////////////////////////////////////////////////////////
	// Interstitial listener

	@Override
	public void onInterstitialAdReceive(InterstitialAdView adView)
	{
		Log.d(TAG, "Interstitial ad received");
		Toast.makeText(this, "Interstitial ad received. Hit \"Present\".", Toast.LENGTH_SHORT).show();
		setBusy(false);
	}

	@Override
	public void onInterstitialAdFail(InterstitialAdView adView, int code, String reason)
	{
		Log.e(TAG, "Interstitial ad failed to receive: code=" + code + " reason=" + reason);
		setBusy(false);
	}

	@Override
	public void onInterstitialAdOpen(InterstitialAdView adView)
	{
		Log.d(TAG, "Interstitial ad opened");
	}

	@Override
	public void onInterstitialAdClose(InterstitialAdView adView)
	{
		Log.d(TAG, "Interstitial ad closed");
		setBusy(true);
	}

	@Override
	public void onInterstitialAdLeaveApplication(InterstitialAdView adView)
	{
		Log.d(TAG, "Interstitial ad will leave application");
	}

	@Override
	public Map<String, Object> createInterstitialAdParams()
	{
		return null;
	}

	////////////////////////////////////////////////////////////////
	// Button click handlers

	public void onRequestButtonClick(View view)
	{
		Log.d(TAG, "Requesting interstitial ad...");
		CrossPromotion.instance().startRequestingInterstitials(this);
		setBusy(true);
	}

	public void onPresentButtonClick(View view)
	{
		InterstitialResult result = CrossPromotion.instance().present(this);
		if (result != InterstitialResult.Presented)
		{
			Toast.makeText(this, "Interstitial not presented", Toast.LENGTH_SHORT).show();
		}
	}

	////////////////////////////////////////////////////////////////
	// Helpers

	private void setBusy(boolean flag)
	{
		progressBar.setVisibility(flag ? View.VISIBLE : View.GONE);
	}
}
