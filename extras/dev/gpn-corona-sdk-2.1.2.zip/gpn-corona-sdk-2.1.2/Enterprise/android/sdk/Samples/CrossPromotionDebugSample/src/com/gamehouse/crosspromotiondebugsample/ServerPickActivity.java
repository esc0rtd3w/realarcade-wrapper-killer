//
//  ServerPickActivity.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.gamehouse.crosspromotion.implementation.Constants;

public class ServerPickActivity extends ActivityBase
{
	public static final String EXTRA_URL = "URL";

	private static final String[] SERVER_URLS = // FIXME: get the list from the server
	{ 
	    Constants.SERVER_DEFAULT_URL, 
	    "http://gpn-staging-api.herokuapp.com",
	    "http://gpn-feature-api.herokuapp.com",
	};

	private ListView listView;
	private Button doneButton;

	private String selectedURL;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_server_pick);

		listView = (ListView) findViewById(R.id.listView);

		doneButton = (Button) findViewById(R.id.btnDone);
		doneButton.setEnabled(false);
		
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(ServerPickActivity.this, android.R.layout.simple_list_item_single_choice, SERVER_URLS);
        listView.setAdapter(adapter);
        listView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        listView.setOnItemClickListener(new OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                doneButton.setEnabled(true);
                selectedURL = SERVER_URLS[position];
            }
        });
	}

	////////////////////////////////////////////////////////////////
	// Button listeners

	public void onDoneClick(View view)
	{
		Intent intent = new Intent();
		intent.putExtra(EXTRA_URL, selectedURL);
		setResult(RESULT_OK, intent);

		finish();
	}

	public void onCancelClick(View view)
	{
		Intent intent = new Intent();
		setResult(RESULT_CANCELED, intent);
		finish();
	}
}
