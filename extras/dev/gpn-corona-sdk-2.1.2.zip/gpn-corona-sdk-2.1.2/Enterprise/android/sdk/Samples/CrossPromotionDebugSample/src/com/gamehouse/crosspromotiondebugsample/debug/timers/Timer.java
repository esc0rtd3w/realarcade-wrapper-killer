//
//  Timer.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample.debug.timers;

import android.os.Handler;
import android.os.Looper;

public class Timer
{
    private Handler handler;
    private Runnable runnable;
    private long delayMillis;
    private boolean repeated;
    private boolean running;

    public Timer(Runnable runnable, long delayMillis)
    {
    	this(runnable, delayMillis, false);
    }

    public Timer(Runnable runnable, long delayMillis, boolean repeated)
    {
    	this(new Handler(Looper.getMainLooper()), runnable, delayMillis, repeated);
    }
    
    public Timer(Handler handler, Runnable runnable, long delayMillis)
    {
        this(handler, runnable, delayMillis, false);
    }

    public Timer(Handler handler, Runnable runnable, long delayMillis, boolean repeated)
    {
    	if (delayMillis < 0)
    	{
    		throw new IllegalArgumentException("Delay is negative");
    	}
    	
    	this.handler = handler;
        this.runnable = runnable;
        this.delayMillis = delayMillis;
        this.repeated = repeated;
    }

    public synchronized void start()
    {
        if (running)
            return;

        handler.postDelayed(looperRunnable, delayMillis);
        running = true;
    }

    public synchronized void stop()
    {
    	if (running)
    	{
	        running = false;
	        handler.removeCallbacks(runnable);
	        handler.removeCallbacks(looperRunnable);
    	}
    }
    
    public boolean isRunning()
	{
		return running;
	}

    private Runnable looperRunnable = new Runnable()
    {
        public void run()
        {
        	if (running)
        	{
	            handler.post(runnable);
	            if (repeated)
	            {
	            	handler.postDelayed(looperRunnable, delayMillis);
	            }
	            else
	            {
	            	running = false;
	            }
        	}
        }
    }; 
}
