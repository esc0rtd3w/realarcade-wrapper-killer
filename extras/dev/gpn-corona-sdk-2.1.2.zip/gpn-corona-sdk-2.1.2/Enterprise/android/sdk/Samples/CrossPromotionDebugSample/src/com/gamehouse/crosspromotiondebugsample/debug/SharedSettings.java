//
//  SharedSettings.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample.debug;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;

import com.gamehouse.crosspromotion.implementation.utils.StringUtils;

public class SharedSettings
{
	private static SharedSettings instance;

	private SharedPreferences prefs;
	private SharedPreferences.Editor editor;
	
	private SharedSettings(Context context)
	{
		if (context == null)
		{
			throw new NullPointerException("context is null");
		}
		prefs = PreferenceManager.getDefaultSharedPreferences(context);
	}
	
	public static void create(Context context)
	{
		destroy();
		instance = new SharedSettings(context);
	}
	
	public static void destroy()
	{
		if (instance != null)
		{
			instance.save();
			instance = null;
		}
	}
	
	public void setString(String key, String value)
	{
		getEditor().putString(key, value);
	}
	
	public void setInt(String key, int value)
	{
		setString(key, Integer.toString(value));
	}
	
	public void setFloat(String key, float value)
	{
		setString(key, Float.toString(value));
	}
	
	public void setBoolean(String key, boolean value)
	{
		getEditor().putBoolean(key, value);
	}
	
	public void setFirst(String key, String value)
	{
	    if (!contains(key))
	    {
	        setString(key, value);
	    }
	}
	
	public void setFirst(String key, int value)
    {
        if (!contains(key))
        {
            setInt(key, value);
        }
    }
	
	public void setFirst(String key, float value)
    {
        if (!contains(key))
        {
            setFloat(key, value);
        }
    }
	
	public void setFirst(String key, boolean value)
    {
        if (!contains(key))
        {
            setBoolean(key, value);
        }
    }
	
	public String getString(String key)
	{
		return getString(key, null);
	}
	
	public String getString(String key, String defValue)
	{
		return prefs.getString(key, defValue);
	}
	
	public int getInt(String key)
	{
		return getInt(key, 0);
	}
	
	public int getInt(String key, int defValue)
	{
	    try
        {
            return prefs.getInt(key, defValue);
        }
        catch (Exception e)
        {
            String value = getString(key);
            return (int) StringUtils.tryParseFloat(value, defValue);
        }
	}
	
	public float getFloat(String key)
	{
		return getFloat(key, 0.0f);
	}
	
	public float getFloat(String key, float defValue)
	{
	    try
        {
            return prefs.getFloat(key, defValue);
        }
        catch (Exception e)
        {
    	    String value = getString(key);
            return StringUtils.tryParseFloat(value, defValue);
        }
	}
	
	public boolean getBoolean(String key)
	{
		return getBoolean(key, false);
	}
	
	public boolean getBoolean(String key, boolean defValue)
	{
	    try
        {
            return prefs.getBoolean(key, defValue);
        }
        catch (Exception e)
        {
    	    String value = getString(key);
            return StringUtils.tryParseBool(value, defValue);
        }
	}
	
	public boolean contains(String key)
	{
	    return prefs.contains(key);
	}
	
	public void save()
	{
		if (editor != null)
		{
			editor.commit();
			editor = null;
		}
	}
	
	private Editor getEditor()
	{
		if (editor == null)
		{
			editor = prefs.edit();
		}
		
		return editor;
	}
	
	////////////////////////////////////////////////////////////////
	// Instance
	
	public static SharedSettings instance()
	{
		return instance;
	}
}
