//
//  LogData.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample.debug;

import java.util.Arrays;

public class LogData
{
	private String[] lines;
	private int[] priorities;
	
	private int head;
	private int length;
	
	public LogData(int capacity)
	{
		lines = new String[capacity];
		priorities = new int[capacity];
	}
	
	public void append(String line)
	{
		append(line, android.util.Log.DEBUG);
	}
	
	public void append(String line, int priority)
	{
		int index = getRealIndex(head + length);
		lines[index] = line;
		priorities[index] = priority;
		
		if (length < getCapacity())
		{
			++length;
		}
		else
		{
			++head;
		}
	}
	
	public void clear()
	{
		Arrays.fill(lines, null);
		head = length = 0;
	}

	public String get(int index)
	{
		if (index < 0 || index >= length)
		{
			throw new IndexOutOfBoundsException("Index out of bounds: " + index);
		}
		
		int realIndex = getRealIndex(head + index);
		return lines[realIndex];
	}
	
	public int getLevel(int index)
	{
		if (index < 0 || index >= length)
		{
			throw new IndexOutOfBoundsException("Index out of bounds: " + index);
		}
		
		int realIndex = getRealIndex(head + index);
		return priorities[realIndex];
	}
	
	public int getCapacity()
	{
		return lines.length;
	}

	public int getLength()
	{
		return length;
	}
	
	private int getRealIndex(int index)
	{
		return index % getCapacity();
	}
}
