//
//  MainActivity.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotionadmob;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;

public class MainActivity extends Activity
{
    /** The log tag. */
    private static final String LOG_TAG = "InterstitialSample";

    /** Your ad unit id. Replace with your actual ad unit id. */
    private static final String AD_UNIT_ID = "ca-app-pub-2607491229738932/9522427006";

    /** The interstitial ad. */
    private InterstitialAd interstitialAd;

    /** The button that show the interstitial. */
    private Button showButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize CrossPromotion
        CrossPromotion.initialize(this, "0"); // your app id here

        // Create an ad.
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(AD_UNIT_ID);

        // Set the AdListener.
        interstitialAd.setAdListener(new AdListener()
        {
            @Override
            public void onAdLoaded()
            {
                Log.d(LOG_TAG, "onAdLoaded");
                Toast.makeText(MainActivity.this, "onAdLoaded", Toast.LENGTH_SHORT).show();

                // Change the button text and enable the button.
                showButton.setText("Show Interstitial");
                showButton.setEnabled(true);
            }

            @Override
            public void onAdFailedToLoad(int errorCode)
            {
                String message = String.format("onAdFailedToLoad (%s)", getErrorReason(errorCode));
                Log.d(LOG_TAG, message);
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();

                // Change the button text and disable the button.
                showButton.setText("Ad Failed to Load");
                showButton.setEnabled(false);
            }

            @Override
            public void onAdOpened()
            {
                Log.d(LOG_TAG, "Ad opened");
            }

            @Override
            public void onAdClosed()
            {
                Log.d(LOG_TAG, "Ad closed");

                // Check the logcat output for your hashed device ID to get test ads on a physical device.
                AdRequest adRequest = new AdRequest.Builder().build();

                // Load the interstitial ad.
                interstitialAd.loadAd(adRequest);
            }
        });

        showButton = (Button) findViewById(R.id.showButton);
        showButton.setEnabled(false);
    }

    @Override
    protected void onDestroy()
    {
        CrossPromotion.destroy();
        super.onDestroy();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        CrossPromotion.instance().onPause();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        CrossPromotion.instance().onResume();
    }

    /** Called when the Load Interstitial button is clicked. */
    public void loadInterstitial(View unusedView)
    {
        // Disable the show button until the new ad is loaded.
        showButton.setText("Loading Interstitial...");
        showButton.setEnabled(false);

        // Check the logcat output for your hashed device ID to get test ads on a physical device.
        AdRequest adRequest = new AdRequest.Builder().build();

        // Load the interstitial ad.
        interstitialAd.loadAd(adRequest);
    }

    /** Called when the Show Interstitial button is clicked. */
    public void showInterstitial(View unusedView)
    {
        // Disable the show button until another interstitial is loaded.
        showButton.setText("Interstitial Not Ready");
        showButton.setEnabled(false);

        if (interstitialAd.isLoaded())
        {
            interstitialAd.show();
        }
        else
        {
            Log.d(LOG_TAG, "Interstitial ad was not ready to be shown.");
        }
    }

    /** Gets a string error reason from an error code. */
    private String getErrorReason(int errorCode)
    {
        String errorReason = "";
        switch (errorCode)
        {
        case AdRequest.ERROR_CODE_INTERNAL_ERROR:
            errorReason = "Internal error";
            break;
        case AdRequest.ERROR_CODE_INVALID_REQUEST:
            errorReason = "Invalid request";
            break;
        case AdRequest.ERROR_CODE_NETWORK_ERROR:
            errorReason = "Network Error";
            break;
        case AdRequest.ERROR_CODE_NO_FILL:
            errorReason = "No fill";
            break;
        }
        return errorReason;
    }
}
