//
//  SharedSettingsKeys.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample.debug;

public class SharedSettingsKeys
{
	private static final String SETTINGS_BASE = "com.gamehouse.settings.";
	
	public static final String LAST_APP_ID = SETTINGS_BASE + "lastAppId";
	public static final String LAST_SERVER_URL = SETTINGS_BASE + "lastServerURL";
	
	public static class Memory
	{
		private static final String BASE = SETTINGS_BASE + ".allocator.";
		
		public static final String LAST_CHUNK_SIZE = BASE + "lastChunkSize";
		public static final String LAST_CHUNK_DELAY = BASE + "lastChunkDelay";
		public static final String LAST_STOP_WHEN_FREE = BASE + "lastStopWhenFree";
		
		public static final String LAST_FLAG_FREE_ON_FINISH = BASE + "lastFreeOnFinish";
		public static final String LAST_FLAG_STOP_ON_WARNING = BASE + "lastStopOnWarning";
	}
}
