//
//  Discoverer.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotiondebugsample.net;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;

import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.util.Log;

import com.gamehouse.crosspromotion.implementation.utils.ServiceUtils;

//import android.util.Log;

/*
 * This class tries to send a broadcast UDP packet over your wifi network to discover the boxee service. 
 */

public class Discoverer
{
    private static final String TAG = "Discovery";

    private WeakReference<Context> contextRef;
    private Thread thread;

    public Discoverer(Context context)
    {
        if (context == null)
        {
            throw new NullPointerException("context is null");
        }
        contextRef = new WeakReference<Context>(context);
    }

    public void startBroadcasting(final int port, final int timeout, final Listener listener)
    {
        thread = new Thread(new Runnable()
        {
            public void run()
            {
                try
                {
                    DatagramSocket socket = new DatagramSocket(port);
                    socket.setBroadcast(true);
                    socket.setSoTimeout(timeout);

                    sendDiscoveryRequest(socket, port);
                    listenForResponses(socket, listener);
                }
                catch (IOException e)
                {
                    Log.e(TAG, "Could not send discovery request", e);
                }
            }
        });
        thread.start();
    }
    
    public void stopBroadcasting()
    {
        if (thread != null)
        {
            thread.interrupt();
            thread = null;
        }
    }

    /**
     * Send a broadcast UDP packet containing a request for boxee services to
     * announce themselves.
     * @param port 
     * 
     * @throws IOException
     */
    private void sendDiscoveryRequest(DatagramSocket socket, int port) throws IOException
    {
        String data = "Bobby wants a remote!";
        Context context = getContext();
        InetAddress address = getBroadcastAddress(context);
        
        Log.d(TAG, "Sending data " + address + ": " + data);

        DatagramPacket packet = new DatagramPacket(data.getBytes(), data.length(), address, port);
        socket.send(packet);
    }

    /**
     * Calculate the broadcast IP we need to send the packet along. If we send
     * it to 255.255.255.255, it never gets sent. I guess this has something to
     * do with the mobile network not wanting to do broadcast.
     */
    private InetAddress getBroadcastAddress(Context context) throws IOException
    {
        WifiManager wifiManager = ServiceUtils.getWifiManager(context);
        DhcpInfo dhcp = wifiManager.getDhcpInfo();

        int broadcast = (dhcp.ipAddress & dhcp.netmask) | ~dhcp.netmask;
        byte[] quads = new byte[4];
        for (int k = 0; k < 4; k++)
            quads[k] = (byte) ((broadcast >> k * 8) & 0xFF);
        return InetAddress.getByAddress(quads);
    }

    /**
     * Listen on socket for responses, timing out after TIMEOUT_MS
     * 
     * @param socket
     *            socket on which the announcement request was sent
     * @param listener 
     * @throws IOException
     */
    private void listenForResponses(DatagramSocket socket, Listener listener) throws IOException
    {
        byte[] buf = new byte[1024];
        try
        {
            while (true)
            {
                DatagramPacket packet = new DatagramPacket(buf, buf.length);
                socket.receive(packet);
                
                String data = new String(packet.getData(), 0, packet.getLength());
                listener.onHostDiscovered(packet.getAddress().getHostAddress(), data);
            }
        }
        catch (SocketTimeoutException e)
        {
            Log.d(TAG, "Receive timed out");
            socket.close();
        }
    }
    
    private Context getContext()
    {
        return contextRef.get();
    }
    
    public static interface Listener
    {
        public void onHostDiscovered(String address, String data);
    }
}
