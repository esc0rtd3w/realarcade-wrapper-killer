# GPN SDK for Android Release Notes

## v2.2.3

* Updated to the latest Android L SDK

## v2.2.2

* Added Mopub Custom Interstitial Event and an integration sample app
* Fixed AdMob Custom Interstitial Event
* Fixes and improvements

## v2.2.1

* Updated Terms & Conditions

## v2.2.0

* Added Google Play Advertising ID support
* Bugfixes and improvements

## v2.1.0

* Improved compatibility with paid ads
* Bugfixes and improvements

## v2.0.1

* Better install tracking
* Bugfixes and improvements

## v2.0.0

* Better logging and debugging
* Bugfixes and improvements

## v1.1.0

* Changed InterstitialAdViewListener methods:
  * Old: `public void onInterstitialAdFail(InterstitialAdView adView, Throwable error)`
  * New: `public void onInterstitialAdFail(InterstitialAdView adView, int code, String reason)`
* Started using weak reference for `InterstitialAdViewListener` object
* More stable Ad handling and error reporting
* Bug fixes and improvements

## v1.0.11

* Added activity callbacks
* Improved promotion loading and presentation
* Bugfixes

## v1.0.10

* Added support for AdMob Mediation
* Renamed `requestInterstitialAd` to more accurate `startRequestingInterstitials`
* Started this release notes file!
