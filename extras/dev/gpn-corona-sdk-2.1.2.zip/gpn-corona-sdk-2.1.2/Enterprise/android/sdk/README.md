# GameHouse Promotion Network SDK for Android

The GameHouse Promotion Network lets you drive app installs with intelligence and control. You can participate in GPN by integrating this open source SDK into your Android apps. Also available for iOS.

## Simple Steps

1. Signup for the GameHouse Promotion Network at http://partners.gamehouse.com/gpn/.
2. Register your apps to obtain a GPN App ID for each.
3. Upload a few marketing assets to enable your app to be promoted in other GPN apps.
4. Integrate this SDK into your app to start showing ads for other GPN apps.

## App Store Support

GPN currently supports the Google Play and Amazon Appstore. When you register your app to obtain a GPN App ID, you must select which store you will distribute in to ensure that only apps from the same app store are promoted. If you distribute your app in both stores, you will need to register it as two separate apps and obtain two separate GPN App IDs. We recommend generating separate Google and Amazon builds with the appropriate GPN App ID in each. 

## Google Advertising ID

Beginning August 1, 2014, all Android apps submitted to the Google Play Store must use the new Google Advertising ID, in lieu of any other device identifiers, for any advertising purposes. GameHouse Promotion Network fully supports this and conforms with Google’s policies concerning collection and usage of this ID. Using Google Advertising ID requires using the Google Play services SDK 4.0+, so this is now a dependency for using GPN in your Android app distributed via Google Play. Note that it is NOT required for apps distributed via the Amazon Appstore. If you distribute in both, you need to do separate builds anyway.

## Integration Instructions

### Preface

You can add GameHouse Promotion Network to your project in two ways:

1. Include library project: Import and link the CrossPromotion SDK project.
2. Jar file: CrossPromotion-android-x.x.x.jar. Add jar file as a replacement of the CrossPromotion SDK library project and use it like any other external jar by adding it to the libs folder and linking the project to it.

### Integration

1. Add manifest permissions:

		<manifest .. >
			..
			<uses-permission android:name="android.permission.INTERNET" />
			<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
			<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />			
			..
		</manifest>


2. Add InterstitialActivity into the manifest's activity list. Also set the "android:configChanges" to "keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize" to prevent recreation of the activity when configuration changes:

		<application ...>
			..
			<activity
				android:name="com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialActivity"
				android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize"
				android:theme="@android:style/Theme.Translucent.NoTitleBar.Fullscreen" />		
			..
		</application>

3. Initialize CrossPromotion instance with your app id. **Make sure to use different App IDs for Google Play and Amazon Appstore builds.** A good place is the Activity.onCreate() method:

		@Override
		protected void onCreate(Bundle savedInstanceState)
		{
			...	
			CrossPromotion.initialize(this, <your_app_id_here>);
			...	
		}

4. Set Up Google Play Services SDK (Google Play Store builds only):  
http://developer.android.com/google/play-services/setup.html

5. Add activity lifecycle callbacks to each of your activities. The best way to do that is to create an activity subclass and make all your activities to extend it:

		public class ActivityBase extends Activity
		{
		        ...
		        
		        @Override
		        protected void onResume()
		        {
		                super.onResume();
		                CrossPromotion.instance().onResume();
		                ...
		        }
		        
		        @Override
		        protected void onPause()
		        {
		                super.onPause();
		                CrossPromotion.instance().onPause();
		                ...
		        }
		        
		        ...
		}

6. Implement InterstitialAdViewListener listener:

		/** Interstitial Ad is received: it's safe to present it now. */
		void onInterstitialAdReceive(InterstitialAdView adView);
		
		/** Interstitial Ad is failed to receive. */
		void onInterstitialAdFail(InterstitialAdView adView, Throwable error);
		
		/** Interstitial Ad presented full screen modal view. You can pause your game here. */
		void onInterstitialAdOpen(InterstitialAdView adView);
		
		/** Interstitial Ad hided full screen modal view. You can resume your game here. */
		void onInterstitialAdClose(InterstitialAdView adView);
		
		/** Interstitial Ad will leave the application. */
		void onInterstitialAdLeaveApplication(InterstitialAdView adView);
		
		/** Optional parameters to be passed with ad request. Return 'null' is you don't need any params. */
		Map<String, Object> createInterstitialAdParams();

7. Request interstitial Ad:

		CrossPromotion.instance().startRequestingInterstitials(listener); // listener is an object of the class which implements InterstitialAdViewListener
		
	**Important**: CrossPromotion uses a weak reference to store the listener's object. Make sure you have a strong reference to the listener somewhere in your code (this is extremly important if you use anonymous class for InterstitialAdViewListener).  
	**Note**: you should call startRequestingInterstitials() only once. The interstitial rotation is handled automatically by the SDK. Each time a new interstitial is received the InterstitialAdViewListener’s onInterstitialAdReceive() is called. You only need to call startRequestingInterstitials() if an error occurred and onInterstitialAdFail() was called.
	

8. Present interstitial Ad after onInterstitialAdReceive() is called:

		InterstitialResult result = CrossPromotion.instance().present(this);
		if (result != InterstitialResult.Presented)
		{
			// Ad cannot be presented at the moment
		}

9. When you're done with CrossPromotion, call CrossPromotion.destroy(). The best place is your root activity's onDestroy() method:

		@Override
		protected void onDestroy()
		{
			...
			CrossPromotion.destroy();
			...
			super.onDestroy();
		}

## Screen rotations
If your application runs in both portrait and landscape orientations – make sure you don’t destroy/recreate the CrossPromotion instance while showing interstitial Ad view. Add android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize" to the activity which is responsible for creating/destroying CrossPromotion instance.
Example:

        <activity
            android:name="com.gamehouse.crosspromotionsample.MainActivity"
            android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize"
            android:label="@string/app_name" >
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

## Ad Positions
If you want to define different ad behavior for different points in your game, you can include an optional params dictionary when calling "present" method to pass a "position" param. For example:

		Map<String, Object> params = new HashMap<String, Object>();
		...
		params.put("position", <position>);
		...
		InterstitialResult result = CrossPromotion.instance().present(this, params);
		if (result != InterstitialResult.Presented)
		{
			// Ad cannot be presented at the moment
		}

Currently, we recognize only three position values:

* startup
* interstitial
* trial-end

Contact us if you want to define additional positions.

## Google AdMob Ad Network Mediation Integration

The GPN SDK may be used as a custom event for AdMob Ad Network Mediation.

1. Unpack the SDK package zip archive.

2. Link CrossPromotion library project or CrossPromotion-android-x.x.x.jar library.

3. Set project's “target” to "android-13" or higher, "minSdkVersion" to "8" or higher.

4. Add manifest permissions:

		<manifest .. >
			..
			<uses-permission android:name="android.permission.INTERNET" />
			<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
			<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />			
			..
		</manifest>

5. Add InterstitialActivity into the manifest's activity list. Also set the "android:configChanges" to "keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize" to prevent recreation of the activity when configuration changes:

		<application ...>
			..
			<activity
				android:name="com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialActivity"
				android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize"
				android:theme="@android:style/Theme.Translucent.NoTitleBar.Fullscreen" />		
			..
		</application>
		
6. Initialize CrossPromotion instance with your app id. **Make sure to use different App IDs for Google Play and Amazon Appstore builds.** A good place is the Activity.onCreate() method:

		@Override
		protected void onCreate(Bundle savedInstanceState)
		{
			...	
			CrossPromotion.initialize(this, <your_app_id_here>);
			...	
		}

7. Add activity lifecycle callbacks to each of your activities. The best way to do that is to create an activity subclass and make all your activities to extend it:

		public class ActivityBase extends Activity
		{
		        ...
		        
		        @Override
		        protected void onResume()
		        {
		                super.onResume();
		                CrossPromotion.instance().onResume();
		                ...
		        }
		        
		        @Override
		        protected void onPause()
		        {
		                super.onPause();
		                CrossPromotion.instance().onPause();
		                ...
		        }
		        
		        ...
		}

8. Add GoogleAdMobAdsSdkiOS-x.x.x to you project, and follow AdMob's instructions to display interstitial ads in your app (see: https://developers.google.com/mobile-ads-sdk/docs/admob/android/interstitial) 

9. Add GPNEventInterstitial.java to your project. Can be located at: 

        Samples/CrossPromotionAdMob/src/com/gamehouse/crosspromotion/admob/GPNEventInterstitial.java

10. Use the AdMob site to setup you mediation placement
11. Add a Custom Event:
   * Label: GPN Custom Event
   * Class Name: com.gamehouse.crosspromotion.admob.GPNEventInterstitial
   
12. Use the AdMob site to allocate traffic to GPN and other ad networks.

## Mopub Ad Network Mediation Integration

The GPN SDK may be used as a custom event for Mopub Ad Network Mediation.

1. Unpack the SDK package zip archive.

2. Link CrossPromotion library project or CrossPromotion-android-x.x.x.jar library.

4. Add manifest permissions:

		<manifest .. >
			..
			<uses-permission android:name="android.permission.INTERNET" />
			<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
			<uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />			
			..
		</manifest>

5. Add InterstitialActivity into the manifest's activity list. Also set the "android:configChanges" to "keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize" to prevent recreation of the activity when configuration changes:

		<application ...>
			..
			<activity
				android:name="com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialActivity"
				android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize"
				android:theme="@android:style/Theme.Translucent.NoTitleBar.Fullscreen" />		
			..
		</application>

6. Initialize CrossPromotion instance with your app id. **Make sure to use different App IDs for Google Play and Amazon Appstore builds.** A good place is the Activity.onCreate() method:

		@Override
		protected void onCreate(Bundle savedInstanceState)
		{
			...	
			CrossPromotion.initialize(this, <your_app_id_here>);
			...	
		}

7. Set Up Google Play Services SDK (Google Play Store builds only):  
http://developer.android.com/google/play-services/setup.html

8. Add activity lifecycle callbacks to each of your activities. The best way to do that is to create an activity subclass and make all your activities to extend it:

		public class ActivityBase extends Activity
		{
		        ...
		        
		        @Override
		        protected void onResume()
		        {
		                super.onResume();
		                CrossPromotion.instance().onResume();
		                ...
		        }
		        
		        @Override
		        protected void onPause()
		        {
		                super.onPause();
		                CrossPromotion.instance().onPause();
		                ...
		        }
		        
		        ...
		}

9. Add mopub-sdk to you project, and follow Mopub's instructions to display interstitial ads in your app (see: https://github.com/mopub/mopub-android-sdk/wiki/Interstitial-Integration) 

10. Add CrossPromotionCustomEventInterstitial.java to your project. Can be located at: 

        Samples/CrossPromotionMopub/src/com/gamehouse/crosspromotion/mopub/GPNCustomEventInterstitial.java

11. Use the Mopub site to setup you mediation placement
12. Setup Custom Native Network (see: https://dev.twitter.com/mopub/ad-networks/network-setup-custom-native) with the following params:
   * Custom Event Class:: com.gamehouse.crosspromotion.mopub.GPNCustomEventInterstitial
13. Use the Mopub site to allocate traffic to GPN and other ad networks.
14. When you're done with CrossPromotion, call CrossPromotion.destroy(). The best place is your root activity's onDestroy() method:

		@Override
		protected void onDestroy()
		{
			...
			CrossPromotion.destroy();
			...
			super.onDestroy();
		}

## Optional ads parameters

Each ads request may include a set of optional parameters. In order to add them you should implement InterstitialAdViewListener's method:

		@Override
		public Map<String, Object> createInterstitialAdParams()
		{
			Map<String, Object> params = new HashMap<String, Object>();
			params.put(<key1>, <value1>);
			params.put(<key2>, <value2>);
			params.put(<key3>, <value3>);
			...
			return params;
		}

## Sample App

The SDK includes a samples app at Samples

# Thanks for using the GameHouse Promotion Network! Contact us if you have any questions or feedback.

