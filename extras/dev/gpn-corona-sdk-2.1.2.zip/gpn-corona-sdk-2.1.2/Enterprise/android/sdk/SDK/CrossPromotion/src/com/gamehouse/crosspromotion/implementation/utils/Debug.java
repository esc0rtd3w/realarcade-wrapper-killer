//
//  Debug.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import java.lang.ref.WeakReference;
import java.util.Map;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.widget.Toast;

import com.gamehouse.crosspromotion.debug.DebugMonitor;
import com.gamehouse.crosspromotion.implementation.network.RequestManager;
import com.gamehouse.crosspromotion.implementation.utils.Log.LogLevel;
import com.gamehouse.crosspromotion.implementation.utils.timers.TimerManager;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class Debug
{
	private static final int ASSERTION_DEPTH = 4;

	private static boolean assertionEnabled;
	private static boolean throwsAssertionError;
	
	private static WeakReference<Context> contextRef;
	
	public static boolean flag; // true, if we're in a debug mode
	
	private static DebugMonitor debugMonitor;

	public static void init(Context context)
	{
		if (context == null)
		{
			throw new NullPointerException("context is null");
		}

		contextRef = new WeakReference<Context>(context);
		assertionEnabled = true;
		flag = true;
		
		Log.setLogLevel(LogLevel.Debug);
		Log.setTagMask(Tag.ALL);
	}
	
	public void destroy()
	{
		disconnect();
		contextRef = null;
	}
	
	public static void setThrowsAssertionError(boolean flag)
	{
	    throwsAssertionError = flag;
	    Log.d(VERBOSE, "Throws error on assertion: %s", flag ? "true" : "false");
	}
	
	public static boolean isAssertionEnabled()
	{
		return assertionEnabled;
	}

	public static void assertion(boolean condition)
	{
		if (!condition)
		{
			String message = getStackTrace(ASSERTION_DEPTH, "", "-------\n");
			if (assertionEnabled)
			{
				showAssertionMessage(message);
			}

			String fullMessage = "Assertion failed!\n" + getStackTrace(ASSERTION_DEPTH, "at ", "");
			Log.logAssertion(fullMessage);
			
			if (throwsAssertionError)
			{
			    throw new AssertionError(fullMessage);
			}
		}
	}

	public static void assertion(boolean condition, String format, Object... args)
	{
		if (!condition)
		{
			String assertionFormat = "Assertion failed:\n" + "\"" + format + "\"" + "\n" + getStackTrace(ASSERTION_DEPTH, "", "-------\n");
			if (assertionEnabled)
			{
				showAssertionMessage(assertionFormat, args);
			}
			String fullMessage = "Assertion failed:\n" + "\"" + StringUtils.tryFormatString(format, args) + "\"" + "\n" + getStackTrace(ASSERTION_DEPTH, "at ", "");
			Log.logAssertion(fullMessage);
			
			if (throwsAssertionError)
            {
                throw new AssertionError(fullMessage);
            }
		}
	}

	public static void assertNotNull(Object reference, String varName)
	{
		assertion(reference != null, "'%s' is null", varName);
	}

	public static void assertNull(Object reference, String varName)
	{
		assertion(reference == null, "'%s' is not null", varName);
	}

	public static void assertIndex(int index, int length)
	{
		assertion(index >= 0 && index < length, "%d >= 0 && %d < %d", index, index, length);
	}

	public static void fail(String format, Object... args)
	{
		assertion(false, format, args);
	}

	public static void showAssertionMessage(String format, Object... args)
	{
		Context context = getContext();
		if (context != null)
		{
			showMessage(context, "Assertion failed", format, args);
		}
	}
	
	////////////////////////////////////////////////////////////////
	// Messages

	public static void showMessage(Context context, String title, String format, Object... args)
	{

		String message = StringUtils.tryFormatString(format, args);

		AlertDialog alertDialog = new AlertDialog.Builder(context).create();
		alertDialog.setTitle(title);
		alertDialog.setMessage(message);

		alertDialog.setButton(Dialog.BUTTON_NEGATIVE, "Abort", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int whichButton)
			{
				System.exit(1);
			}
		});

		alertDialog.setButton(Dialog.BUTTON_POSITIVE, "Continue", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int whichButton)
			{
				dialog.dismiss();
			}
		});
		alertDialog.show();
	}
	
	public static void showToast(final Context context, final String format, final Object... args)
	{
		try
		{
			if (ThreadUtils.isRunningOnUiThread())
			{
				CharSequence text = StringUtils.tryFormatString(format, args);
				Toast toast = Toast.makeText(context, text, Toast.LENGTH_SHORT);
				toast.show();
			}
			else
			{
				ThreadUtils.runOnUiThread(new Runnable()
				{
					@Override
					public void run()
					{
						showToast(context, format, args);
					}
				});
			}
		}
		catch (Exception e)
		{
			Log.logException(e, "Unable to show toast");
		}
	}
	
	////////////////////////////////////////////////////////////////
	// Remote monitor
	
	public static void connect(String host, int port)
	{
		if (debugMonitor == null)
		{
			debugMonitor = new DebugMonitor();
			System.out.println("Connecting remote monitor: " + host + ":" + port);
			debugMonitor.start(host, port);
		}
	}
	
	// TODO: replace with notifications
	public static void onTimerManagerCreated(TimerManager manager)
	{
		if (debugMonitor != null)
		{
			debugMonitor.onTimerManagerCreated(manager);
		}
	}
	
	// TODO: replace with notifications
	public static void onTimerManagerDestroyed(TimerManager manager)
	{
		if (debugMonitor != null)
		{
			debugMonitor.onTimerManagerDestroyed(manager);
		}
	}
	
	public static void onRequestManagerCreated(RequestManager manager)
	{
	    if (debugMonitor != null)
	    {
	        debugMonitor.onRequestManagerCreated(manager);
	    }
	}
	
	public static void onRequestManagerDestroyed(RequestManager manager)
	{
	    if (debugMonitor != null)
	    {
	        debugMonitor.onRequestManagerDestroyed(manager);
	    }
	}
	
	static void sendLog(int priority, String thread, String message)
	{
		if (debugMonitor != null)
		{
			debugMonitor.sendLog(priority, thread, message);
		}
	}
	
	public static void logEvent(String name, Map<String, Object> params)
    {
	    if (debugMonitor != null)
	    {
	        debugMonitor.sendEvent(name, params);
	    }
    }
	
	public static void disconnect()
	{
		if (debugMonitor != null)
		{
			debugMonitor.stop();
			debugMonitor = null;
		}
	}
	
	public static boolean isConnected()
	{
		return debugMonitor != null && debugMonitor.isConnected();
	}
	
	////////////////////////////////////////////////////////////////
	// Helpers
	
	private static Context getContext()
	{
		return contextRef != null ? contextRef.get() : null;
	}

	private static String getStackTrace(int startDepth, String prefix, String sufix)
	{
		try
		{
			StackTraceElement[] elements = Thread.currentThread().getStackTrace();
			if (elements != null)
			{
				StringBuilder buffer = new StringBuilder();
				for (int elementIndex = startDepth; elementIndex < elements.length; ++elementIndex)
				{
					buffer.append(prefix);
					buffer.append(elements[elementIndex]);
					if (elementIndex < elements.length - 1)
					{
						buffer.append("\n");
						buffer.append(sufix);
					}
				}
				return buffer.toString();
			}
		}
		catch (Exception e)
		{
		}
		return null;
	}
}
