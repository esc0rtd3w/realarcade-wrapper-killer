//
//  ServerApi.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation;

import static com.gamehouse.crosspromotion.implementation.Constants.*;
import static com.gamehouse.crosspromotion.implementation.utils.MemoryUtils.*;
import static com.gamehouse.crosspromotion.implementation.utils.StringUtils.*;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.graphics.Point;
import android.telephony.TelephonyManager;

import com.gamehouse.crosspromotion.implementation.ads.URLRequest;
import com.gamehouse.crosspromotion.implementation.utils.Connectivity;
import com.gamehouse.crosspromotion.implementation.utils.Connectivity.ConnectionType;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.DisplayUtils;
import com.gamehouse.crosspromotion.implementation.utils.GoogleAdvertisingID;
import com.gamehouse.crosspromotion.implementation.utils.IdentifierUtils;
import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.ServiceUtils;
import com.gamehouse.crosspromotion.implementation.utils.StringUtils;

public class ServerApi
{
	private static final String SERVER_PATH_INIT = "api/init";
	private static final String SERVER_PATH_SETTINGS = "api/sdks/init";

	private String baseURL;
	
    private String packageName;
    private int versionCode;
    private String versionName;
    
    private String wrapperName;
    private String wrapperVersion;
    
    private GoogleAdvertisingID.Info googleAidInfo;

	public ServerApi(Context context, String baseURL)
	{
	    if (context == null)
        {
            throw new NullPointerException("context is null");
        }
	    
	    if (baseURL == null)
        {
            throw new NullPointerException("baseURL is null");
        }
	    
		setBaseURL(baseURL);
		initPackageParams(context);
	}

    private void initPackageParams(Context context)
    {
        packageName = context.getPackageName();
		
        try
        {
            PackageInfo info = context.getPackageManager().getPackageInfo(packageName, 0);
            versionCode = info.versionCode;
            versionName = info.versionName;
        }
        catch (Exception e)
        {
            Log.logException(e, "Error while getting package params");
        }
    }

	////////////////////////////////////////////////////////////////
	// Requests

	public URLRequest createInitRequest(Context context, String appId, Map<String, Object> optionalParams)
	{
		if (context == null)
		{
			throw new NullPointerException("context is null");
		}

		if (appId == null)
		{
			throw new NullPointerException("appId is null");
		}

		Map<String, Object> params = createAppParams(context, appId, optionalParams);
		String url = createURLFromPath(SERVER_PATH_INIT);
		return new URLRequest(url, params);
	}
	
	public URLRequest createSettingsRequest(Context context, String appId)
	{
	    if (context == null)
        {
            throw new NullPointerException("context is null");
        }

        if (appId == null)
        {
            throw new NullPointerException("appId is null");
        }

        Map<String, Object> params = createAppParams(context, appId, null);
        String url = createURLFromPath(SERVER_PATH_SETTINGS);
        return new URLRequest(url, params);
	}
	
	public URLRequest createInstallTrackingRequest(Context context, String trackingURL, String appId)
	{
		if (context == null)
		{
			throw new NullPointerException("context is null");
		}
		
		if (trackingURL == null)
		{
			throw new NullPointerException("'trackingURL' is null");
		}
		
		if (appId == null)
		{
			throw new NullPointerException("appId is null");
		}
		
		Map<String, Object> params = createAppParams(context, appId, null);
		
		params.put("type", "sdk_install");
        params.put("origin", StringUtils.tryFormatString("%s#%d", baseURL, new Random().nextInt()));
		
		return new URLRequest(trackingURL, params);
	}

	////////////////////////////////////////////////////////////////
	// App specific params

	private Map<String, Object> createAppParams(Context context, String appId, Map<String, Object> optionalParams)
	{
		if (context == null)
		{
			throw new NullPointerException("context is null");
		}

		if (appId == null)
		{
			throw new NullPointerException("App id is null");
		}

		Map<String, Object> params = new HashMap<String, Object>();

		// sdk version
		setParam(params, REQUEST_PARAM_SDK_VERSION, SDK_VERSION);

		// app id
		setParam(params, REQUEST_PARAM_APP_ID, appId);

		// package name
		setParam(params, REQUEST_PARAM_PACKAGE_NAME, packageName);
		
		// version code
		setParam(params, REQUEST_PARAM_VERSION_CODE, versionCode);
		
		// version name
		setParam(params, REQUEST_PARAM_VERSION_NAME, versionName);

		// device identifiers
		String androidID = IdentifierUtils.systemAndroidID(context);
		setParam(params, REQUEST_PARAM_ANDROID_ID, androidID);
		
		if (googleAidInfo != null)
		{
		    setParam(params, REQUEST_PARAM_GOOGLE_ID_TRACK, googleAidInfo.isEnabled());
		    setParam(params, REQUEST_PARAM_GOOGLE_ID, googleAidInfo.getId());
		}
		else
		{
		    String macID = IdentifierUtils.deviceMacID(context);
	        setParam(params, REQUEST_PARAM_MAC_ID, macID);
		}

		// connection type
		ConnectionType connectionType = Connectivity.getConnectionType(context);
		setParam(params, REQUEST_PARAM_CONNECTION_TYPE, connectionType.getName());
		if (connectionType == ConnectionType.Carrier)
		{
			setParam(params, REQUEST_PARAM_CONNECTION_SUBTYPE, Connectivity.getConnectionSubTypeName(context));
		}

		// carrier info
		TelephonyManager telephonyManager = ServiceUtils.getTelephonyManager(context);
		if (telephonyManager != null)
		{
			String operatorName = telephonyManager.getNetworkOperatorName();
			setParam(params, REQUEST_PARAM_CARRIER, operatorName);
		}

		// country info
		Locale locale = Locale.getDefault();
		if (locale != null)
		{
			String country = locale.getCountry();
			setParam(params, REQUEST_PARAM_COUNTRY, country);
		}

		// Screen size
		Point ds = DisplayUtils.getDisplaySize(context);
		if (ds != null)
		{
			setParam(params, REQUEST_PARAM_SCREEN_WIDTH, ds.x);
			setParam(params, REQUEST_PARAM_SCREEN_HEIGHT, ds.y);
		}

		// memory info
		setParam(params, REQUEST_PARAM_FREE_MEMORY, tryFormatString("%.1f", toMegabytes(getAvailableMemory())));
		setParam(params, REQUEST_PARAM_FREE_HEAP_MEMORY, tryFormatString("%.1f", toMegabytes(getFreeHeapMemory())));
		setParam(params, REQUEST_PARAM_HEAP_MEMORY, tryFormatString("%.1f", toMegabytes(getHeapMemory())));
		setParam(params, REQUEST_PARAM_MAX_MEMORY, tryFormatString("%.1f",  toMegabytes(getTotalMemory())));
		
		// wrapper
		if (wrapperName != null && wrapperVersion != null)
		{
		    setParam(params, REQUEST_PARAM_WRAPPER_NAME, wrapperName);
		    setParam(params, REQUEST_PARAM_WRAPPER_VERSION, wrapperVersion);
		}

		// debug
		if (Debug.flag)
		{
			setParam(params, REQUEST_PARAM_DEBUG, true);
		}

		// optional
		if (optionalParams != null && optionalParams.size() > 0)
		{
			params.putAll(optionalParams);
		}

		return params;
	}

	////////////////////////////////////////////////////////////////
	// Helpers

	private String createURLFromPath(String path)
	{
		if (baseURL.endsWith("/"))
		{
			return baseURL + path;
		}

		return baseURL + "/" + path;
	}

	private void setParam(Map<String, Object> params, String name, Object value)
	{
		if (value != null)
		{
			String stringValue = value.toString();
			if (stringValue.length() > 0)
			{
				params.put(name, value);
			}
		}
	}

	////////////////////////////////////////////////////////////////
	// Getters/Setters

	public void setBaseURL(String baseURL)
	{
		if (baseURL == null)
		{
			throw new NullPointerException("Base URL is null");
		}
		this.baseURL = baseURL;
	}

	public String getBaseURL()
	{
		return baseURL;
	}
	
	public String getWrapperName()
    {
        return wrapperName;
    }
	
	public void setWrapperName(String wrapperName)
    {
	    if (wrapperName == null)
        {
            throw new NullPointerException("'wrapperName' is null");
        }
        this.wrapperName = wrapperName;
    }
	
	public String getWrapperVersion()
    {
        return wrapperVersion;
    }
	
	public void setWrapperVersion(String wrapperVersion)
    {
	    if (wrapperVersion == null)
        {
            throw new NullPointerException("'wrapperVersion' is null");
        }
        this.wrapperVersion = wrapperVersion;
    }
	
	public void setGoogleAidInfo(GoogleAdvertisingID.Info googleAidInfo)
    {
        this.googleAidInfo = googleAidInfo;
    }
	
	public GoogleAdvertisingID.Info getGoogleAidInfo()
    {
        return googleAidInfo;
    }
}
