//
//  Global.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion;

import android.content.Context;

import com.gamehouse.crosspromotion.implementation.CrossPromotionImpl;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView;
import com.gamehouse.crosspromotion.implementation.settings.Settings;
import com.gamehouse.crosspromotion.implementation.utils.ClassUtils;
import com.gamehouse.crosspromotion.implementation.utils.timers.Timer;
import com.gamehouse.crosspromotion.implementation.utils.timers.TimerGroup;

public class Global
{
	public static String getBaseURL()
	{
		return getInstance().baseURL();
	}
	
	public static void setBaseURL(String baseURL)
	{
		getInstance().setBaseURL(baseURL);
	}
	
	public static String getAppId()
	{
		return getInstance().getAppId();
	}
	
	public static void setAppId(String appId)
	{
		getInstance().setAppId(appId);
	}
	
	public static InterstitialAdView getCurrentAdView()
	{
		return getInstance().getInterstitialAdView();
	}
	
	public static void setWrapperName(String name)
	{
	    CrossPromotionImpl cp = getImpl();
	    if (cp != null)
	    {
	        cp.setWrapperName(name);
	    }
	}
	
	public static void setWrapperVersion(String version)
	{
	    CrossPromotionImpl cp = getImpl();
	    if (cp != null)
	    {
	        cp.setWrapperVersion(version);
	    }
	}
	
	public static Settings getSettings()
	{
	    CrossPromotionImpl cp = getImpl();
	    return cp != null ? cp.getSettings() : null;
	}
	
	public static boolean clearInstallTrackFlag(Context context)
	{
	    CrossPromotionImpl impl = getImpl();
	    if (impl != null)
	    {
	        impl.setInstallTracked(context, false);
	        return true;
	    }
	    
	    return false;
	}
	
	////////////////////////////////////////////////////////////////
	// Timers
	
	public static Timer scheduleTimer(long delayMillis, Runnable target)
	{
		return scheduleTimer(delayMillis, target, false, null, null);
	}
	
	public static Timer scheduleTimer(long delayMillis, Runnable target, boolean repeated)
	{
		return scheduleTimer(delayMillis, target, repeated, null, null);
	}
	
	public static Timer scheduleTimer(long delayMillis, Runnable target, boolean repeated, TimerGroup group)
	{
		return scheduleTimer(delayMillis, target, repeated, group, null);
	}
	
	public static Timer scheduleTimer(long delayMillis, Runnable target, boolean repeated, TimerGroup group, String tag)
	{
		CrossPromotionImpl impl = getImpl();
		if (impl != null)
		{
			return impl.scheduleTimer(delayMillis, target, repeated, group, tag);
		}
		
		return null;
	}
	
	public static CrossPromotionImpl getImpl()
	{
		return ClassUtils.tryCast(getInstance(), CrossPromotionImpl.class);
	}
	
	private static CrossPromotion getInstance()
	{
		return CrossPromotion.instance();
	}
}
