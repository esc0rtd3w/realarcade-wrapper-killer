//
//  Log.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import static android.util.Log.DEBUG;
import static android.util.Log.ERROR;
import static android.util.Log.INFO;
import static android.util.Log.WARN;

public class Log
{
	public static enum LogLevel
	{
		Crit(ERROR), //
		Error(ERROR), //
		Warn(WARN), //
		Info(INFO), //
		Debug(DEBUG), //
		None(-1); //

		private int androidLogPriority;

		LogLevel(int priority)
		{
			androidLogPriority = priority;
		}

		public int getAndroidLogPriority()
		{
			return androidLogPriority;
		}
	}

	private static final String TAG = "CP";

	private static LogLevel logLevel = LogLevel.Info;
	
	private static int logTag = (1 << Tag.COMMON) | (1 << Tag.CALLBACKS);

	public static void setLogLevel(LogLevel level)
	{
		logLevel = level;
		logHelper(LogLevel.Info, "Log level: %s", level.toString());
	}

	public static LogLevel getLogLevel()
	{
		return logLevel;
	}
	
	public static void i(int tag, String format, Object... args)
	{
	    log(LogLevel.Info, tag, format, args);
	}

	public static void i(boolean condition, int tag, String format, Object... args)
	{
	    if (condition)
	    {
	        i(tag, format, args);
	    }
	}

	public static void w(int tag, String format, Object... args)
	{
	    log(LogLevel.Warn, tag, format, args);
	}

	public static void w(boolean condition, int tag, String format, Object... args)
	{
	    if (condition)
        {
            w(tag, format, args);
        }
	}

	public static void d(int tag, String format, Object... args)
	{
		log(LogLevel.Debug, tag, format, args);
	}

	public static void d(boolean condition, int tag, String format, Object... args)
	{
	    if (condition)
        {
            d(tag, format, args);
        }
	}

	public static void e(int tag, String format, Object... args)
	{
	    log(LogLevel.Error, tag, format, args);
	}

	public static void e(boolean condition, int tag, String format, Object... args)
	{
	    if (condition)
        {
            e(tag, format, args);
        }
	}

	public static void logCrit(String format, Object... args)
	{
		log(LogLevel.Crit, Tag.ALL, format, args);
	}

	public static void logException(int tag, Throwable t)
	{
		if (t != null)
		{
			logException(t, "%s is thrown: %s", t.getClass().getName(), t.getMessage());
		}
		else
		{
			e(tag, "Exception is thrown");
		}
	}

	public static void logException(Throwable t, String format, Object... args)
	{
		e(Tag.ALL, format, args);
		if (shouldLogLevel(LogLevel.Error) && t != null)
		{
			t.printStackTrace(); // TODO: handle stack trace manually
		}
	}

	public static void logAssertion(String format, Object... args)
	{
		logCrit(format, args);
	}

	public static String getStackTrace()
	{
		try
		{
			StackTraceElement[] elements = Thread.currentThread().getStackTrace();
			if (elements != null)
			{
				StringBuilder buffer = new StringBuilder();
				for (int elementIndex = 0; elementIndex < elements.length; ++elementIndex)
				{
					buffer.append(elements[elementIndex]);
					if (elementIndex < elements.length - 1)
					{
						buffer.append("\n");
					}
				}
				return buffer.toString();
			}
		}
		catch (Exception e)
		{
		}
		return null;
	}

	private static void log(LogLevel level, int tag, String format, Object... args)
	{
		if (shouldLogLevel(level) && shouldLogTag(tag))
		{
			if (format != null)
			{
				logHelper(level, format, args);
			}
			else
			{
				logHelper(level, "null");
			}
		}
	}

	private static void logHelper(LogLevel level, String format, Object... args)
	{
		int priority = level.getAndroidLogPriority();
		
		String message = StringUtils.tryFormatString(format, args);
		String threadName = Thread.currentThread().getName();
		String tag = TAG + "/" + threadName;
		android.util.Log.println(priority, tag, message);
		
		Debug.sendLog(level.ordinal(), threadName, message);
	}

	private static boolean shouldLogLevel(LogLevel level)
	{
		return level.ordinal() <= logLevel.ordinal();
	}
	
	private static boolean shouldLogTag(int tag)
	{
	    return (logTag & (1 << tag)) != 0;
	}
	
	public static void setTagMask(int mask)
	{
		logTag = mask;
	}
	
	public static void setTagEnabled(int tag, boolean flag)
	{
	    if (flag)
	    {
	        logTag |= 1 << tag;
	    }
	    else
	    {
	        logTag &= ~(1 << tag);
	    }
	}
}
