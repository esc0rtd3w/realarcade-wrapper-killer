//
//  HttpRequest.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.network;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.StringUtils;
import com.gamehouse.crosspromotion.implementation.utils.ThreadUtils;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class HttpRequest
{
	private static final float DEFAULT_TIMEOUT_SECONDS = 60.0f;
	private static int nextRequestId;

	private RequestManager manager;

	private RequestAsyncTask asyncTask;
	private HttpURLConnection connection;

	private String name;
	private int id;
	
	private String urlString;
	private Map<String, Object> params;
	private Map<String, Object> headers;
	private String method;

	private long timeoutMillis;

	private int responseCode;
	private byte[] responseData;

	private Exception thrownException;

	@SuppressWarnings("rawtypes")
	private HttpRequestListener listener;

	private int tag;

	private long startTimestamp;
	private long duration;
	
	private boolean debugShouldFailConnection;
	private boolean debugShouldFailResponse;
	private long debugConnectionHoldDelay;

	public HttpRequest(String urlString)
	{
		this(urlString, DEFAULT_TIMEOUT_SECONDS);
	}

	public HttpRequest(String urlString, float timeoutSeconds)
	{
		this(urlString, timeoutSeconds, null);
	}

	public HttpRequest(String urlString, Map<String, Object> params)
	{
		this(urlString, DEFAULT_TIMEOUT_SECONDS, params);
	}

	public HttpRequest(String urlString, float timeoutSeconds, Map<String, Object> params)
	{
		this(urlString, timeoutSeconds, params, null);
	}

	public HttpRequest(String urlString, float timeoutSeconds, Map<String, Object> params, Map<String, Object> headers)
	{
		this.urlString = urlString;
		this.timeoutMillis = (int) (timeoutSeconds * 1000);
		this.id = getNextRequestId();

		setParams(params);
		setHttpHeaders(headers);

		setupDefaults();
	}

	private int getNextRequestId()
	{
		return nextRequestId++;
	}
	
	public int getId()
	{
		return id;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public String getName()
	{
		return name;
	}
	
	public String getUrlString()
	{
		return urlString;
	}
	
	public void setParam(Object value, String key)
	{
		if (value != null)
		{
			if (params == null)
			{
				params = new HashMap<String, Object>();
			}
			params.put(key, value);
		}
	}

	public void setParams(Map<String, Object> params)
	{
		if (params != null)
		{
			Set<Entry<String, Object>> entries = params.entrySet();
			for (Entry<String, Object> e : entries)
			{
				String key = e.getKey();
				if (key == null)
				{
					throw new IllegalArgumentException("Can't add http request param: key is null");
				}

				Object value = e.getValue();
				if (value != null)
				{
					setParam(value, key);
				}
			}
		}
	}

	public void setHttpHeaders(Map<String, Object> headers)
	{
		if (headers != null)
		{
			Set<Entry<String, Object>> entries = headers.entrySet();
			for (Entry<String, Object> e : entries)
			{
				String key = e.getKey();
				if (key == null)
				{
					throw new IllegalArgumentException("Can't add headers to request: map contains a null key");
				}

				Object value = e.getValue();
				if (value != null)
				{
					setHttpHeader(value, key);
				}
			}
		}
	}

	public void setHttpHeader(Object value, String key)
	{
		if (value != null)
		{
			if (headers == null)
			{
				headers = new HashMap<String, Object>();
			}
			headers.put(key, value);
		}
	}

	public void start()
	{
	    if (ThreadUtils.isRunningOnUiThread())
	    {
	        startAsyncTask();
	    }
	    else
	    {
	        ThreadUtils.runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
                    startAsyncTask();
                }
            });
	    }
	}

    private void startAsyncTask()
    {
        asyncTask = new RequestAsyncTask()
		{

			@Override
			protected void doOnSecondaryThread()
			{
				doInBackground();
			}

			@Override
			protected void onStart()
			{
				startRequest();
			}

			@Override
			protected void onFinish()
			{
				if (isCancelled())
				{
					cancelRequest();
				}
				else
				{
					finishRequest();
				}
			}

			@Override
			protected void onCancel()
			{
				cancelRequest();
			}
		};
		asyncTask.execute();
    }

	public void cancel()
	{
		asyncTask.cancel();
	}

	private void enqueue()
	{
		getManager().queueRequest(this);
	}

	private void dequeue()
	{
		getManager().removeRequest(this);
	}

	public boolean isCancelled()
	{
		return asyncTask == null || asyncTask.isCancelled();
	}
	
	public boolean isFailed()
	{
		return thrownException != null;
	}

	public boolean isRunning()
	{
		return asyncTask != null && asyncTask.isRunning();
	}

	public Exception getThrownException()
	{
		return thrownException;
	}

	////////////////////////////////////////////////////////////////
	// Setup

	private void setupDefaults()
	{
		setMethodGet();
	}

	public void setMethodGet()
	{
		method = "GET";
	}

	public void setMethodPost()
	{
		method = "POST";
	}

	////////////////////////////////////////////////////////////////
	// Lifecycle

	protected void onStart()
	{
	}

	@SuppressWarnings("unchecked")
	protected void onFinish()
	{
		try
		{
			if (listener != null)
			{
				listener.onFinish(this);
			}
		}
		catch (Exception e)
		{
			Debug.fail("Exception in request finish listener: " + e);
		}
	}

	@SuppressWarnings("unchecked")
	protected synchronized void onFinish(Exception error)
	{
		try
		{
			if (listener != null)
			{
				listener.onFailure(this, -1, error.getMessage());
			}
		}
		catch (Exception e)
		{
			Debug.fail("Exception in request fail listener: " + e);
		}
	}

	@SuppressWarnings("unchecked")
	protected synchronized void onCancel()
	{
		try
		{
			if (listener != null)
			{
				listener.onCancel(this);
			}
		}
		catch (Exception e)
		{
			Debug.fail("Exception in request cancel listener: " + e);
		}
	}

	protected void onResponseReceived(byte[] responseData) throws Exception
	{
	}

	////////////////////////////////////////////////////////////////
	// Request async task

	private void doInBackground()
	{
		try
		{
			try
			{
				startTimestamp = System.currentTimeMillis();

				URL url = createUrl(urlString);
				Log.d(NETWORK, "Performing request: %s", url);

				connection = openConnection(url, method, timeoutMillis, headers);

				if (isCancelled())
				{
					return;
				}

				responseCode = connection.getResponseCode();

				if (isCancelled())
				{
					return;
				}

				if (debugShouldFailResponse)
				{
					throw new DebugIOException("Response failed");
				}
				
				if (responseCode == HttpURLConnection.HTTP_OK)
				{
					InputStream is = connection.getInputStream();
					responseData = readResponse(is);

					if (isCancelled())
					{
						return;
					}

					onResponseReceived(responseData);
				}
				else
				{
					throw new UnexpectedResponseCodeException(url, responseCode);
				}
			}
			finally
			{
				closeConnection();
			}
		}
		catch (Exception e)
		{
			thrownException = e;
			if (!isCancelled())
			{
				Log.logException(e, "Unable to perform request");
			}
		}
	}

	private void startRequest()
	{
		enqueue();
		setupRequestStartTimestamp();

		try
		{
			onStart();
		}
		catch (Exception e)
		{
			Log.logException(e, "Error while starting request");
			thrownException = e;
			finishRequest();
		}
	}

	private void finishRequest()
	{
		calculateRequestDuration();

		if (thrownException != null)
		{
			onFinish(thrownException);
		}
		else
		{
			onFinish();
		}

		dequeue();
	}

	private void cancelRequest()
	{
		calculateRequestDuration();
		onCancel();
		dequeue();
	}

	////////////////////////////////////////////////////////////////
	// Connection

	protected HttpURLConnection openConnection(URL url, String method, long timeout, Map<String, Object> headers) throws IOException
	{
		if (url == null)
		{
			throw new IllegalArgumentException("Unable to open a connection: url is null");
		}

		if (method == null)
		{
			throw new IllegalArgumentException("Unable to open a connection: http method is null");
		}
		
		applyDebugInjector();

		HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		connection.setUseCaches(true);
		connection.setRequestMethod(method);
		connection.setConnectTimeout((int) timeout);

		if (headers != null)
		{
			setupHeaders(connection, headers);
		}

		return connection;
	}

	private void applyDebugInjector() throws DebugIOException
	{
		if (debugShouldFailConnection)
		{
			throw new DebugIOException("Connection failed");
		}
		
		if (debugConnectionHoldDelay > 0)
		{
			try
			{
				Thread.sleep(debugConnectionHoldDelay);
			}
			catch (InterruptedException e)
			{
			}
		}
	}

	private void setupHeaders(HttpURLConnection connection, Map<String, Object> headers)
	{
		if (headers == null)
		{
			throw new IllegalArgumentException("Headers are null");
		}

		Set<Entry<String, Object>> entries = headers.entrySet();
		for (Entry<String, Object> e : entries)
		{
			String name = e.getKey();
			Object value = e.getValue();

			if (name != null && value != null)
			{
				connection.setRequestProperty(name, value.toString());
			}
		}
	}

	private void closeConnection()
	{
		if (connection != null)
		{
			connection.disconnect();
			connection = null;
		}
	}

	private byte[] readResponse(InputStream is) throws IOException
	{
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		byte[] buffer = new byte[1024];
		int bytesRead;

		while ((bytesRead = is.read(buffer)) != -1)
		{
			bos.write(buffer, 0, bytesRead);
		}

		return bos.toByteArray();
	}

	////////////////////////////////////////////////////////////////
	// Request duration

	private void setupRequestStartTimestamp()
	{
		startTimestamp = System.currentTimeMillis();
	}

	private void calculateRequestDuration()
	{
		duration = System.currentTimeMillis() - startTimestamp;
	}

	////////////////////////////////////////////////////////////////
	// Helpers

	private URL createUrl(String baseUrl) throws IOException
	{
		if (params != null && params.size() > 0)
		{
			String paramsString = StringUtils.encodeURLParams(params);
			if (baseUrl.endsWith("/"))
			{
				return new URL(baseUrl + paramsString);
			}
			return new URL(baseUrl + "/" + paramsString);
		}
		return new URL(baseUrl);
	}

	////////////////////////////////////////////////////////////////
	// Getter/Setter

	public void setManager(RequestManager manager)
	{
		if (manager == null)
		{
			throw new IllegalArgumentException("Request manager is null");
		}
		this.manager = manager;
	}

	public RequestManager getManager()
	{
		return manager;
	}

	public void setListener(HttpRequestListener<?> listener)
	{
	    this.listener = listener;
	}

	public String urlString()
	{
		return urlString;
	}

	public Map<String, Object> params()
	{
		return params;
	}

	public Map<String, Object> headers()
	{
		return headers;
	}

	public float timeout()
	{
		return timeoutMillis;
	}

	public int responseCode()
	{
		return responseCode;
	}

	public byte[] responseData()
	{
		return responseData;
	}

	public long duration()
	{
		return duration;
	}

	public int tag()
	{
		return tag;
	}
	
	public void setShouldFailConnection(boolean flag)
	{
		debugShouldFailConnection = flag;
	}
	
	public void setShouldFailResponse(boolean flag)
	{
		debugShouldFailResponse = flag;
	}
	
	public void setDebugConnectionHoldDelay(long delay)
	{
		debugConnectionHoldDelay = delay;
	}

	public String toString()
	{
		return StringUtils.tryFormatString("tag: %d url:\"%s\" params:%s", tag, urlString, params);
	}
}
