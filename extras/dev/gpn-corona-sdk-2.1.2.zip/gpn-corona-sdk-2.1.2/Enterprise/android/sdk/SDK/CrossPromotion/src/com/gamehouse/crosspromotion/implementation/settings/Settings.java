//
//  Settings.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.settings;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.json.JSON;
import com.gamehouse.crosspromotion.implementation.utils.json.JSONException;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class Settings
{
    private static final int VERSION = 1;

    private static final String CH_HEARTBEAT = "hrbt";
    private static final int CH_HEARTBEAT_VER = 1;

    private static final String CH_TIMERS = "tmrs";
    private static final int CH_TIMERS_VER = 1;

    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_TIMEOUT = "timeout_ms";

    public static final String KEY_HEARTBEAT = "heartbeat";
    public static final String KEY_HEARTBEAT_SHOULD_RESTART = "should_restart";
    public static final String KEY_HEARTBEAT_SHOULD_CLOSE = "should_close";

    public static final String KEY_TIMERS = "timers";
    public static final String KEY_TIMER_LOADING = "loading";
    public static final String KEY_TIMER_PRESENTING = "presenting";
    
    public static final String KEY_INSTALL_TRACKING = "install_tracking";
    public static final String KEY_INSTALL_TRACKING_URL = "tracking_pixel_url";

    public static final boolean DEFAULT_HEARTBEAT_ENABLED = false;
    public static final boolean DEFAULT_HEARTBEAT_SHOULD_RESTART = true;
    public static final boolean DEFAULT_HEARTBEAT_SHOULD_CLOSE = true;
    public static final int DEFAULT_HEARTBEAT_TIMEOUT = 60 * 1000;

    public static final boolean DEFAULT_LOADING_TIMER_ENABLED = false;
    public static final int DEFAULT_LOADING_TIMEOUT = 3 * 60 * 1000;

    public static final boolean DEFAULT_PRESENTING_TIMER_ENABLED = false;
    public static final int DEFAULT_PRESENTING_TIMEOUT = 5 * 1000;

    private TimerInfo heartbeatTimer;

    /** True if the ad should be restarted on heartbeat timeout */
    private boolean restartOnHeartbeatTimeout;

    /** True if the open ad should be closed on heartbeat timeout */
    private boolean forceCloseOnHeartbeatTimeout;

    private TimerInfo loadingTimer;

    private TimerInfo presentingTimer;

    private Map<String, ChunkSerialization> serializationLookup;
    
    private String installTrackingURL;

    public Settings()
    {
        heartbeatTimer = new TimerInfo();
        loadingTimer = new TimerInfo();
        presentingTimer = new TimerInfo();

        initDefaults();
        initSerialization();
    }

    ////////////////////////////////////////////////////////////////
    // Defaults

    private void initDefaults()
    {
        defaultHeartbeat();
        defaultTimers();
    }

    ////////////////////////////////////////////////////////////////
    // Loading

    public void load(JSON json)
    {
        JSON hbJson = json.jsonForKey(KEY_HEARTBEAT);
        if (hbJson != null)
        {
            try
            {
                loadHeartbeat(hbJson);
            }
            catch (Exception e)
            {
                Log.e(SETTINGS, "Unable to load 'heartbeat'. Use defaults");
                defaultHeartbeat();
            }
        }

        JSON timersJson = json.jsonForKey(KEY_TIMERS);
        if (timersJson != null)
        {
            loadTimers(timersJson);
        }
        
        JSON installTrackingJson = json.jsonForKey(KEY_INSTALL_TRACKING);
        if (installTrackingJson != null)
        {
        	loadInstallTracking(installTrackingJson);
        }
    }

	public void load(String filename) throws IOException
    {
        if (filename == null)
        {
            throw new NullPointerException("filename is null");
        }

        FileInputStream fis = null;
        try
        {
            fis = new FileInputStream(filename);
            DataInputStream dis = new DataInputStream(fis);
            read(dis);
        }
        finally
        {
            if (fis != null)
                fis.close();
        }
    }

    public void save(String filename) throws IOException
    {
        if (filename == null)
        {
            throw new NullPointerException("filename is null");
        }

        FileOutputStream fos = null;
        try
        {
            fos = new FileOutputStream(filename);
            DataOutputStream dos = new DataOutputStream(fos);
            write(dos);
        }
        finally
        {
            if (fos != null)
                fos.close();
        }
    }

    private void read(DataInputStream in) throws IOException
    {
        int version = in.readByte();
        if (version != getVersion())
        {
            throw new IOException("Version doesn't match");
        }

        // read chunks
        while (in.available() > 0)
        {
            readChunk(in);
        }
    }

    private void write(DataOutput out) throws IOException
    {
        out.writeByte(getVersion());

        // heart beat
        writeChunk(out, CH_HEARTBEAT);
        
        // timers
        writeChunk(out, CH_TIMERS);
    }

    ////////////////////////////////////////////////////////////////
    // Unit tests

    protected int getVersion() // made protected for unit tests
    {
        return VERSION;
    }

    protected void overrideChunkVersion(String name, int version)
    {
        ChunkSerialization cs = serializationLookup.get(name);
        cs.setVersion(version);
    }

    ////////////////////////////////////////////////////////////////
    // Data chunk

    private void writeChunk(DataOutput out, String name) throws IOException
    {
        ChunkSerialization cs = findChunkSerialization(name);
        if (cs == null)
        {
            throw new IOException("Serializer not found: " + name);
        }

        out.writeUTF(name);
        out.writeByte(cs.getVersion());

        byte[] data = createChunkData(cs);

        out.writeInt(data.length);
        out.write(data);
    }

    private void readChunk(DataInput in) throws IOException
    {
        String name = in.readUTF();
        int version = in.readByte();

        int length = in.readInt();

        ChunkSerialization cs = findChunkSerialization(name);
        if (cs == null)
        {
            in.skipBytes(length);
            Log.w(SETTINGS, "Deserializer not found: '%s'", name);
            return;
        }

        if (cs.getVersion() != version)
        {
            in.skipBytes(length);
            Log.w(SETTINGS, "Unexpected serializer version: 'd' expected: 'd'", version, cs.getVersion());
            cs.setDefaults();
            return;
        }

        try
        {
            byte[] data = new byte[length];
            in.readFully(data);

            ByteArrayInputStream bis = new ByteArrayInputStream(data);
            DataInputStream dis = new DataInputStream(bis);

            cs.read(dis);
        }
        catch (Exception e)
        {
            Log.logException(e, "Can't read chunk '%s'", name);
            cs.setDefaults();
        }
    }

    private byte[] createChunkData(ChunkSerialization cs) throws IOException
    {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(bos);
        cs.write(dos);
        return bos.toByteArray();
    }

    ////////////////////////////////////////////////////////////////
    // Loading timer

    public boolean isLoadingTimerEnabled()
    {
        return loadingTimer.enabled;
    }

    public void setLoadingTimerEnabled(boolean enabled)
    {
        loadingTimer.enabled = enabled;
    }

    public int getLoadingTimeout()
    {
        return loadingTimer.timeout;
    }

    public void setLoadingTimeout(int timeout)
    {
        loadingTimer.timeout = timeout;
    }

    ////////////////////////////////////////////////////////////////
    // Presenting timer

    public boolean isPresentingTimerEnabled()
    {
        return presentingTimer.enabled;
    }

    public void setPresentingTimeout(int timeout)
    {
        presentingTimer.timeout = timeout;
    }

    public int getPresentingTimeout()
    {
        return presentingTimer.timeout;
    }

    public void setPresentingTimerEnabled(boolean enabled)
    {
        presentingTimer.enabled = enabled;
    }

    ////////////////////////////////////////////////////////////////
    // Heartbeat

    private void defaultHeartbeat()
    {
        defaultHeartbeatTimer();
        restartOnHeartbeatTimeout = DEFAULT_HEARTBEAT_SHOULD_RESTART;
        forceCloseOnHeartbeatTimeout = DEFAULT_HEARTBEAT_SHOULD_CLOSE;
    }

    private void defaultHeartbeatTimer()
    {
        heartbeatTimer.enabled = DEFAULT_HEARTBEAT_ENABLED;
        heartbeatTimer.timeout = DEFAULT_HEARTBEAT_TIMEOUT;
    }

    private void loadHeartbeat(JSON json) throws JSONException
    {
        loadTimerInfo(json, heartbeatTimer);

        forceCloseOnHeartbeatTimeout = json.boolForKey(KEY_HEARTBEAT_SHOULD_CLOSE, DEFAULT_HEARTBEAT_SHOULD_CLOSE);
        restartOnHeartbeatTimeout = json.boolForKey(KEY_HEARTBEAT_SHOULD_RESTART, DEFAULT_HEARTBEAT_SHOULD_RESTART);
    }

    public boolean isHeartbeatEnabled()
    {
        return heartbeatTimer.enabled;
    }

    public void setHeartbeatEnabled(boolean enabled)
    {
        heartbeatTimer.enabled = enabled;
    }

    public long getHeartbeatTimeout()
    {
        return heartbeatTimer.timeout;
    }

    public void setHeartbeatTimeout(int timeout)
    {
        heartbeatTimer.timeout = timeout;
    }

    public boolean isRestartOnHeartbeatTimeout()
    {
        return restartOnHeartbeatTimeout;
    }

    public void setRestartOnHeartbeatTimeout(boolean restartOnHeartbeatTimeout)
    {
        this.restartOnHeartbeatTimeout = restartOnHeartbeatTimeout;
    }

    public boolean isForceCloseOnHeartbeatTimeout()
    {
        return forceCloseOnHeartbeatTimeout;
    }

    public void setForceCloseOnHeartbeatTimeout(boolean forceCloseOnHeartbeatTimeout)
    {
        this.forceCloseOnHeartbeatTimeout = forceCloseOnHeartbeatTimeout;
    }

    ////////////////////////////////////////////////////////////////
    // Timers

    private void defaultTimers()
    {
        defaultLoadingTimer();
        defaultPresentingTimer();
    }

    private void defaultPresentingTimer()
    {
        presentingTimer.enabled = DEFAULT_PRESENTING_TIMER_ENABLED;
        presentingTimer.timeout = DEFAULT_PRESENTING_TIMEOUT;
    }

    private void defaultLoadingTimer()
    {
        loadingTimer.enabled = DEFAULT_LOADING_TIMER_ENABLED;
        loadingTimer.timeout = DEFAULT_LOADING_TIMEOUT;
    }

    private void loadTimers(JSON json)
    {
        // 'loading' timer
        try
        {
            JSON loadingJson = json.jsonForKey(KEY_TIMER_LOADING);
            if (loadingJson != null)
            {
                loadTimerInfo(loadingJson, loadingTimer);
            }
        }
        catch (Exception e)
        {
            Log.e(SETTINGS, "Unable to load 'loading' timer. Using defaults...");
            defaultLoadingTimer();
        }

        // 'presenting' timer
        try
        {
            JSON presentingJson = json.jsonForKey(KEY_TIMER_PRESENTING);
            if (presentingJson != null)
            {
                loadTimerInfo(presentingJson, presentingTimer);
            }
        }
        catch (Exception e)
        {
            Log.e(SETTINGS, "Unable to load 'presenting' timer. Using defaults...");
            defaultPresentingTimer();
        }
    }

    private TimerInfo loadTimerInfo(JSON json, TimerInfo timerInfo) throws JSONException
    {
        boolean enabled = json.boolForKey(KEY_ENABLED);
        int timeout = json.intForKey(KEY_TIMEOUT);

        timerInfo.enabled = enabled;
        timerInfo.timeout = timeout;

        return timerInfo;
    }
    
    ////////////////////////////////////////////////////////////////
	// Install tracking
    
    private void loadInstallTracking(JSON json)
	{
    	String installTrackingURL = json.notEmptyStringForKey(KEY_INSTALL_TRACKING_URL, null);
    	if (installTrackingURL != null)
    	{
    		this.installTrackingURL = installTrackingURL;
    	}
	}
    
    public String getInstallTrackingURL()
	{
		return installTrackingURL;
	}

    ////////////////////////////////////////////////////////////////
    // Readers/Writers

    private void initSerialization()
    {
        serializationLookup = new HashMap<String, ChunkSerialization>();
        serializationLookup.put(CH_HEARTBEAT, new ChunkSerialization(CH_HEARTBEAT_VER)
        {
            @Override
            public void write(DataOutput out) throws IOException
            {
                writeTimerInfo(out, heartbeatTimer);
                out.writeBoolean(forceCloseOnHeartbeatTimeout);
                out.writeBoolean(restartOnHeartbeatTimeout);
            }

            @Override
            public void read(DataInput in) throws IOException
            {
                readTimerInfo(in, heartbeatTimer);
                forceCloseOnHeartbeatTimeout = in.readBoolean();
                restartOnHeartbeatTimeout = in.readBoolean();
            }

            @Override
            public void setDefaults()
            {
                defaultHeartbeat();
            }
        });

        serializationLookup.put(CH_TIMERS, new ChunkSerialization(CH_TIMERS_VER)
        {
            @Override
            public void write(DataOutput out) throws IOException
            {
                writeTimerInfo(out, loadingTimer);
                writeTimerInfo(out, presentingTimer);
            }

            @Override
            public void read(DataInput in) throws IOException
            {
                readTimerInfo(in, loadingTimer);
                readTimerInfo(in, presentingTimer);
            }

            @Override
            public void setDefaults()
            {
                defaultTimers();
            }
        });
    }

    private void writeTimerInfo(DataOutput out, TimerInfo info) throws IOException
    {
        out.writeBoolean(info.enabled);
        out.writeInt(info.timeout);
    }

    private void readTimerInfo(DataInput in, TimerInfo timerInfo) throws IOException
    {
        timerInfo.enabled = in.readBoolean();
        timerInfo.timeout = in.readInt();
    }

    private ChunkSerialization findChunkSerialization(String name)
    {
        return serializationLookup.get(name);
    }

    private abstract class ChunkSerialization
    {
        private int version;

        public ChunkSerialization(int version)
        {
            this.version = version;
        }

        public abstract void read(DataInput in) throws IOException;

        public abstract void write(DataOutput out) throws IOException;

        public abstract void setDefaults();

        public int getVersion()
        {
            return version;
        }

        public void setVersion(int version)
        {
            this.version = version;
        }
    }

    private static class TimerInfo
    {
        public boolean enabled;
        public int timeout;
    }
}
