//
//  InterstitialActivity.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.ads.interstitial;

import static com.gamehouse.crosspromotion.implementation.Notifications.INTERSTITIAL_CLOSED_NOTIFICATION;

import java.lang.ref.WeakReference;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.observing.NotificationObserver;
import com.gamehouse.crosspromotion.implementation.utils.observing.NotificationService;

public class InterstitialActivity extends Activity implements NotificationObserver
{
    private RelativeLayout layout;
    private WeakReference<InterstitialAdView> adViewRef;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        initializeWindow();
        initializeAdView();

        layout = new RelativeLayout(this);
        final LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);

        try
        {
            InterstitialAdView adView = getAdView();
            if (adView != null)
            {
                adView.detachFromParent();
                layout.addView(adView, layoutParams);
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Exception while adding adview into interstitial activity");
        }
        
        setContentView(layout);
        
        registerNotificationObservers();
    }

    @Override
    protected void onPause()
    {
        super.onPause();
        CrossPromotion.instance().onPause();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        CrossPromotion.instance().onResume();
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        layout.removeAllViews();
        unregisterNotificationObservers();
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();

        unregisterNotificationObservers(); // don't need "close" notification

        InterstitialAdView adView = getAdView();
        Debug.assertNotNull(adView, "adView");
        
        if (adView != null)
        {
            adView.onBackPressed();
        }
    }

    ////////////////////////////////////////////////////////////////
    // Notifications

    private void registerNotificationObservers()
    {
        NotificationService.instance().addObserver(this, INTERSTITIAL_CLOSED_NOTIFICATION);
    }

    private void unregisterNotificationObservers()
    {
        NotificationService.instance().removeObserver(this, INTERSTITIAL_CLOSED_NOTIFICATION);
    }

    ////////////////////////////////////////////////////////////////
    // Notifications

    @Override
    public void onNotificationReceive(String name, Object data)
    {
        if (name.equals(INTERSTITIAL_CLOSED_NOTIFICATION))
        {
            finish();
        }
    }

    ////////////////////////////////////////////////////////////////
    // Helpers

    private void initializeAdView()
    {
        InterstitialAdView adView = Global.getCurrentAdView();
        Debug.assertNotNull(adView, "adView");

        if (adView != null)
        {
            adViewRef = new WeakReference<InterstitialAdView>(adView);
        }
    }

    private void initializeWindow()
    {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        getWindow().getAttributes().dimAmount = 0.75f;
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
    }

    private InterstitialAdView getAdView()
    {
        return adViewRef != null ? adViewRef.get() : null;
    }
}
