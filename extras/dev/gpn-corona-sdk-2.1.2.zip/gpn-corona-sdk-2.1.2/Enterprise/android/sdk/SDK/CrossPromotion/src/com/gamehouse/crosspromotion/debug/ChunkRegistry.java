//
//  ChunkRegistry.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.debug;

import java.util.HashMap;
import java.util.Map;

public class ChunkRegistry
{
	private static ChunkRegistry instance;
	
	private Map<String, Class<? extends Chunk>> chunksClasses;
	
	public ChunkRegistry()
	{
		chunksClasses = new HashMap<String, Class<? extends Chunk>>();
	}
	
	public static void createInstance()
	{
		instance = new ChunkRegistry();
	}
	
	public static void destroyInstance()
	{
		instance = null;
	}
	
	public static ChunkRegistry getInstance()
	{
		return instance;
	}
	
	public void register(String name, Class<? extends Chunk> chunkClass)
	{
		Class<? extends Chunk> existingClass = chunksClasses.get(name);
		if (existingClass != null && !existingClass.equals(chunkClass))
		{
			throw new IllegalArgumentException("Already registered: name=" + name + " class=" + existingClass);
		}
		
		chunksClasses.put(name, chunkClass);
	}
	
	public Chunk createChunk(String name)
	{
		Class<? extends Chunk> chunkClass = findClass(name);
		if (chunkClass != null)
		{
			return newInstance(chunkClass);
		}
		
		return null;
	}
	
	public Class<? extends Chunk> findClass(String name)
	{
		return chunksClasses.get(name);
	}
	
	private <T> T newInstance(Class<? extends T> cls)
	{
		try
		{
			return cls.newInstance();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}
}
