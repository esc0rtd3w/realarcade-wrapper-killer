//
//  IdentifierUtils.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import java.io.DataInputStream;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.UUID;

import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Environment;
import android.provider.Settings;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class IdentifierUtils
{
	private static String uID;
	private static String androidID;
	private static String macID;

	private static final String KEY_DEVICE_INDENTIFIER = "com.gamehouse.gpn.deviceid";

	public static String uniqueDeviceId(Context context)
	{
		if (uID == null)
		{
			uID = generateUniqueId(context);
		}

		return uID;
	}

	public static String systemAndroidID(Context context)
	{
		if (androidID == null)
		{
			androidID = generateAndroidId(context);
		}

		return androidID;
	}

	public static String deviceMacID(Context context)
	{
		if (macID == null)
		{
			if (ManifestUtils.isGrantedPermissions(context, Manifest.permission.ACCESS_WIFI_STATE))
			{
				macID = generateMacId(context);
			}
			else
			{
				Log.w(VERBOSE, "Can't get device's mac address. Missing manifest permission: %s", Manifest.permission.ACCESS_WIFI_STATE);
			}
		}
		return macID;

	}

	private static String generateUniqueId(Context context)
	{
		String stored = readUniqueIDFromMemory(context);
		if (stored != null)
		{
			return stored;
		}

		String identifier = UUID.randomUUID().toString();
		if (identifier == null || identifier.trim().length() == 0)
		{
			return null;
		}

		try
		{
			MessageDigest md = MessageDigest.getInstance("MD5");
			if (md != null)
			{
				String uuid = StringUtils.toHexString(md.digest(identifier.getBytes()));
				if (uuid != null)
				{
					boolean succeed = writeUniqueIDToMemory(context, uuid);
					if (succeed)
					{
						return uuid;
					}
				}
			}
		}
		catch (Exception e)
		{
			Log.w(VERBOSE, "Unable to generate unique device id: %s", e.getMessage());
		}

		return null;
	}

	private static String generateAndroidId(Context context)
	{
		try
		{
			ContentResolver contentResolver = context.getContentResolver();
			String name = Settings.Secure.ANDROID_ID;
			String systemID = Settings.Secure.getString(contentResolver, name);

			if (systemID == null || systemID.trim().length() == 0)
			{
				return null;
			}

			MessageDigest md = MessageDigest.getInstance("MD5");
			if (md != null)
			{
				return StringUtils.toHexString(md.digest(systemID.getBytes()));
			}
		}
		catch (Exception e)
		{
			Log.w(VERBOSE, "Unable to get android id: %s", e.getMessage());
		}

		return null;
	}

	private static String generateMacId(Context context)
	{
		try
		{
			WifiManager manager = ServiceUtils.getWifiManager(context);
			if (manager == null)
			{
				return null;
			}

			WifiInfo info = manager.getConnectionInfo();
			if (info == null)
			{
				return null;
			}

			String mac = info.getMacAddress();

			MessageDigest md = MessageDigest.getInstance("MD5");
			if (md != null)
			{
				return StringUtils.toHexString(md.digest(mac.getBytes()));
			}
		}
		catch (Exception e)
		{
			Log.w(VERBOSE, "Unable to get device mac address: %s", e.getMessage());
		}
		return null;
	}

	private static String readUniqueIDFromMemory(Context context)
	{
		try
		{
			String uuid = readFromExternalMemory();
			if (uuid != null)
			{
				return uuid;
			}
		}
		catch (Exception e)
		{
			Log.w(VERBOSE, "Unable to read unique id from external storage: %s", e.getMessage());
		}

		try
		{
			return readFromInternalMemory(context);
		}
		catch (Exception e)
		{
			Log.w(VERBOSE, "Unable to read unique id from internal storage: %s", e.getMessage());
		}

		return null;
	}

	private static String readFromInternalMemory(Context context)
	{
		SharedPreferences sharedPreferences = context.getSharedPreferences("PlacePlayAds", Context.MODE_PRIVATE);
		return sharedPreferences.getString(KEY_DEVICE_INDENTIFIER, null);
	}

	private static String readFromExternalMemory() throws IOException
	{
		String state = Environment.getExternalStorageState();
		if (state.equals(Environment.MEDIA_MOUNTED) || state.equals(Environment.MEDIA_MOUNTED_READ_ONLY))
		{
			File root = Environment.getExternalStorageDirectory();
			File file = new File(root, KEY_DEVICE_INDENTIFIER);
			if (!file.exists())
			{
				Log.w(VERBOSE, "Unable to read device unique id. File not exists: %s", file.getPath());
				return null;
			}

			FileInputStream fis = null;
			try
			{
				fis = new FileInputStream(file);
				DataInputStream dis = new DataInputStream(fis);
				return dis.readUTF();
			}
			finally
			{
				if (fis != null)
				{
					fis.close();
				}
			}
		}

		return null;
	}

	private static boolean writeUniqueIDToMemory(Context context, String uuid)
	{
		boolean succeed = writeToExternalMemory(context, uuid);
		return writeToInternalMemory(context, uuid) || succeed;
	}

	private static boolean writeToInternalMemory(Context context, String uuid)
	{
		try
		{
			SharedPreferences sharedPreferences = context.getSharedPreferences("PlacePlayAds", Context.MODE_PRIVATE);
			Editor editor = sharedPreferences.edit();
			editor.putString(KEY_DEVICE_INDENTIFIER, uuid);
			editor.commit();

			return true;
		}
		catch (Exception e)
		{
			Log.w(VERBOSE, "Unable to write to internal storage: %s", e.getMessage());
		}

		return false;
	}

	private static boolean writeToExternalMemory(Context context, String uuid)
	{
		if (uuid == null)
		{
			throw new IllegalArgumentException("UUID is null");
		}

		if (!ManifestUtils.isGrantedPermissions(context, Manifest.permission.WRITE_EXTERNAL_STORAGE))
		{
			Log.w(VERBOSE, "Unable to write unique id to the external storage. Missing manifest permission: %s", Manifest.permission.WRITE_EXTERNAL_STORAGE);
			return false;
		}

		try
		{
			String storageState = Environment.getExternalStorageState();
			if (storageState.equals(Environment.MEDIA_MOUNTED))
			{
				File root = Environment.getExternalStorageDirectory();
				File file = new File(root, KEY_DEVICE_INDENTIFIER);
				FileOutputStream fos = null;
				try
				{
					fos = new FileOutputStream(file);
					DataOutputStream dos = new DataOutputStream(fos);
					dos.writeUTF(uuid);
					dos.flush();

					return true;
				}
				finally
				{
					if (fos != null)
					{
						fos.close();
					}
				}
			}
		}
		catch (Exception e)
		{
			Log.w(VERBOSE, "Unable to write to external storage: %s", e.getMessage());
		}

		return false;
	}
}
