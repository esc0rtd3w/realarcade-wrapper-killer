//
//  JavaScriptCommand.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.gpn;

import java.util.Map;

import com.gamehouse.crosspromotion.implementation.utils.StringUtils;

public abstract class JavaScriptCommand
{	
	private HtmlAdView view;
	private String id;
	private Map<String, String> params;

	public abstract void execute() throws JavaScriptCommandException;
	
	////////////////////////////////////////////////////////////////
	// Getters/Setters
	
	protected HtmlAdView getAdView()
	{
		return view;
	}

	protected void setView(HtmlAdView view)
	{
		this.view = view;
	}
	
	protected String getId()
	{
		return id;
	}
	
	protected void setId(String id)
	{
		this.id = id;
	}
	
	public Map<String, String> getParams()
	{
		return params;
	}
	
	protected void setParams(Map<String, String> params)
	{
		this.params = params;
	}

	public String getType()
	{
		return getClass().getName();
	}
	
	////////////////////////////////////////////////////////////////
	// Helper methods
	
	// TODO: cover methods with tests
	// TODO: make separate class for that
	
	protected float getFloatParam(String key)
	{
		return getFloatParam(key, 0.0f);
	}

	protected float getFloatParam(String key, float defaultValue)
	{
		String stringValue = params.get(key);
		return StringUtils.tryParseFloat(stringValue, defaultValue);
	}

	protected boolean getBoolParam(String key)
	{
		return getBoolParam(key, false);
	}
	
	protected boolean getBoolParam(String key, boolean defaultValue)
	{
		String stringValue = params.get(key);
		return StringUtils.tryParseBool(stringValue, defaultValue);
	}

	protected int getIntParam(String key)
	{
		return getIntParam(key, 0);
	}
	
	protected int getIntParam(String key, int defaultValue)
	{
		String stringValue = params.get(key);
		return StringUtils.tryParseInt(stringValue, defaultValue);
	}

	protected String getStringParam(String key)
	{
		return getStringParam(key, null);
	}
	
	protected String getStringParam(String key, String defaultValue)
	{
	    String value = params.get(key);
	    if (value != null)
	    {
	    	value = value.trim();
	    	if (value.length() > 0)
	    	{
	    		return value;
	    	}
	    }
	    
	    return defaultValue;
	}
}
