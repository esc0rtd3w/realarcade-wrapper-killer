//
//  GoogleAdvertisingID.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;

import android.content.Context;
import android.os.AsyncTask;

public class GoogleAdvertisingID
{
    public static final int ERROR_NONE = 0;
    public static final int ERROR_NOT_SUPPOTED = 1;
    public static final int ERROR_EXCEPTION = 2;
    
    public static void getId(Context context, ResolveListener listener)
    {
        new ResolverTask(listener).execute(context);
    }
    
    public static class Info
    {
        private String id;
        private boolean enabled;
        
        private Info(String id, boolean enabled)
        {
            this.id = id;
            this.enabled = enabled;
        }
        
        public String getId()
        {
            return id;
        }
        
        public boolean isEnabled()
        {
            return enabled;
        }
    }
    
    public static interface ResolveListener
    {
        void onGoogleAdvertisingIDResolved(Info info);
        void onGoogleAdvertisingIDResolveError(int code, String message);
    }

    private static class ResolverTask extends AsyncTask<Context, Void, Info>
    {
        private static final String CLASS_ADVERTISING_ID_CLIENT = "com.google.android.gms.ads.identifier.AdvertisingIdClient";
        private static final String CLASS_ADVERTISING_ID_CLIENT_INFO = "com.google.android.gms.ads.identifier.AdvertisingIdClient$Info";

        private static final String METHOD_GET_ADVERTISING_ID_INFO = "getAdvertisingIdInfo";
        private static final String METHOD_GET_ID = "getId";
        private static final String METHOD_IS_LIMIT_AD_TRACKING_ENABLED = "isLimitAdTrackingEnabled";
        
        private WeakReference<ResolveListener> listenerRef;
        private int errorCode;
        private String errorMessage;

        public ResolverTask(ResolveListener listener)
        {
            if (listener == null)
            {
                throw new NullPointerException("'listener' is null");
            }
            
            listenerRef = new WeakReference<ResolveListener>(listener);
            errorCode = ERROR_NONE;
        }
        
        @Override
        protected Info doInBackground(Context... params)
        {
            try
            {
                Log.d(COMMON, "Resolve Google Advertising ID in background...");

                Context context = params[0];
                if (context == null)
                {
                    Log.e(COMMON, "Can't resolve Google Advertising ID: context is null");
                    return null;
                }

                Class<?> advertisingIdClientClass = Class.forName(CLASS_ADVERTISING_ID_CLIENT);
                Class<?> advertisingIdClientClassInfo = Class.forName(CLASS_ADVERTISING_ID_CLIENT_INFO);

                Method getAdvertisingIdInfoMethod = advertisingIdClientClass.getMethod(METHOD_GET_ADVERTISING_ID_INFO, Context.class);
                Method getIdMethod = advertisingIdClientClassInfo.getMethod(METHOD_GET_ID);
                Method isLimitAdTrackingEnabledMethod = advertisingIdClientClassInfo.getMethod(METHOD_IS_LIMIT_AD_TRACKING_ENABLED);

                Object adInfoObject = getAdvertisingIdInfoMethod.invoke(null, context);
                boolean limitAdTrackingEnabled = ((Boolean) isLimitAdTrackingEnabledMethod.invoke(adInfoObject)).booleanValue();
                String id = (String) getIdMethod.invoke(adInfoObject);
                boolean enabled = !limitAdTrackingEnabled; // Google Advertising ID usage is enabled if "Opt out of interest-based ads" checkbox is unchecked
                
                return new Info(id, enabled);
            }
            catch (ClassNotFoundException e)
            {
                errorCode = ERROR_NOT_SUPPOTED;
                errorMessage = e.getMessage();
            }
            catch (NoSuchMethodException e)
            {
                errorCode = ERROR_NOT_SUPPOTED;
                errorMessage = e.getMessage();
            }
            catch (Exception e)
            {
                errorCode = ERROR_EXCEPTION;
                errorMessage = e.getMessage();
                Log.logException(e, "Can't resolve Google Advertising ID");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Info info)
        {
            ResolveListener listener = getListener();
            if (listener != null)
            {
                try
                {
                    if (info != null)
                    {
                        listener.onGoogleAdvertisingIDResolved(info);
                    }
                    else
                    {
                        listener.onGoogleAdvertisingIDResolveError(errorCode, errorMessage);
                    }
                }
                catch (Exception e)
                {
                    Log.logException(e, "Error while notifying relove listener");
                }
            }
            else
            {
                Log.logCrit("ResolverListener reference is lost");
            }
        }
        
        private ResolveListener getListener()
        {
            return listenerRef.get();
        }
    }
}
