//
//  InterstitialAdView.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.ads.interstitial;

import static com.gamehouse.crosspromotion.CrossPromotion.ERROR_EXCEPTION_THROWN;
import static com.gamehouse.crosspromotion.CrossPromotion.ERROR_URL_LOADING;

import java.util.Map;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.Constants;
import com.gamehouse.crosspromotion.implementation.CrossPromotionImpl;
import com.gamehouse.crosspromotion.implementation.ads.BaseAdView;
import com.gamehouse.crosspromotion.implementation.ads.URLRequest;
import com.gamehouse.crosspromotion.implementation.gpn.HtmlAdView;
import com.gamehouse.crosspromotion.implementation.gpn.HtmlAdViewListener;
import com.gamehouse.crosspromotion.implementation.settings.Settings;
import com.gamehouse.crosspromotion.implementation.utils.ClassUtils;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.ThreadUtils;
import com.gamehouse.crosspromotion.implementation.utils.timers.Timer;
import com.gamehouse.crosspromotion.implementation.utils.timers.TimerGroup;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class InterstitialAdView extends BaseAdView implements HtmlAdViewListener
{
    public enum InterstitialResult
    {
        Presented, NotPresented, NotPresentedForbidsPosition, Failed;
    }

    private enum State
    {
        NotLoaded, Loading, Loaded, Failed, Presented, Closed;
    }

    private HtmlAdView adView;
    private InterstitialAdViewListener listener;
    private State state;

    private String[] includesPositions;
    private String[] excludesPositions;

    private TimerGroup timers;

    public InterstitialAdView(Context context)
    {
        super(context);
        setState(State.NotLoaded);

        timers = new TimerGroup(3);
    }

    @Override
    public void stop()
    {
        if (ThreadUtils.isRunningOnUiThread())
        {
            stop0();
        }
        else
        {
            ThreadUtils.runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
                    stop0();
                }
            });
        }
        super.stop();
    }

    private void stop0()
    {
        destroyAdView();
    }

    ////////////////////////////////////////////////////////////////
    // Present

    public InterstitialResult present(final Context context, final Map<String, Object> params)
    {
        try
        {
            if (isLoaded())
            {
                if (adView != null)
                {
                    if (ThreadUtils.isRunningOnUiThread())
                    {
                        adView.firePresentingState();
                    }
                    else
                    {
                        ThreadUtils.runOnUiThread(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                adView.firePresentingState();
                            }
                        });
                    }
                }

                Debug.assertNotNull(adView, "adView");
                if (adView != null)
                {
                    if (params != null)
                    {
                        String position = ClassUtils.tryStrictCast(params.get("position"), String.class); // TODO: change map type
                        if (position != null && !isPositionAllowed(position))
                        {
                            Log.w(COMMON, "Position is not allowed: '%s'", position);
                            return InterstitialResult.NotPresentedForbidsPosition;
                        }
                    }

                    if (ThreadUtils.isRunningOnUiThread())
                    {
                        present0(context, params);
                    }
                    else
                    {
                        ThreadUtils.runOnUiThread(new Runnable()
                        {
                            @Override
                            public void run()
                            {
                                present0(context, params);
                            }
                        });
                    }

                    return InterstitialResult.Presented;
                }

                return InterstitialResult.Failed;
            }
        }
        catch (ActivityNotFoundException e)
        {
            Log.logCrit("Unable to present interstitial ad. Make sure you've added InterstitialActivity into your manifest file");
            return InterstitialResult.Failed;
        }
        catch (Throwable e)
        {
            Log.logException(e, "Unable to present interstitial");
            return InterstitialResult.Failed;
        }

        return InterstitialResult.NotPresented;
    }

    private void present0(Context context, Map<String, Object> params)
    {
        schedulePresentedTimer();

        Debug.assertion(ThreadUtils.isRunningOnUiThread());
        adView.present(context, params);
        start();
    }

    public void close()
    {
        if (isPresented())
        {
            Debug.assertNotNull(adView, "adView");
            if (adView != null)
            {
                adView.close();
            }
        }
    }
    
    public void onBackPressed()
    {
        if (isPresented())
        {
            Debug.assertNotNull(adView, "adView");
            if (adView != null)
            {
                adView.onBackPressed();
            }
        }
        else
        {
            Debug.assertion(state == State.Presented, "Unexpected state: %s", state);
        }
    }

    public void setExcludesPositions(String[] excludesPositions)
    {
        this.excludesPositions = excludesPositions;
    }

    public void setIncludesPositions(String[] includesPositions)
    {
        this.includesPositions = includesPositions;
    }

    private boolean isPositionAllowed(String position)
    {
        if (excludesPositions != null && excludesPositions.length > 0 && hasPosition(excludesPositions, position))
        {
            return false;
        }

        if (includesPositions != null && includesPositions.length > 0 && !hasPosition(includesPositions, position))
        {
            return false;
        }

        return true;
    }

    private boolean hasPosition(String[] array, String position)
    {
        if (position != null)
        {
            for (int i = 0; i < array.length; i++)
            {
                if (position.equals(array[i]))
                {
                    return true;
                }
            }
        }

        return false;
    }
    
    public boolean detachFromParent()
    {
        ViewGroup parent = ClassUtils.tryCast(getParent(), ViewGroup.class);
        if (parent != null)
        {
            parent.removeView(this);
            return true;
        }
        return false;
    }

    ////////////////////////////////////////////////////////////////
    // Request

    public void loadRequest(URLRequest request)
    {
        if (request == null)
        {
            throw new NullPointerException("request is null");
        }

        super.loadContent();

        String url = request.absoluteURL();
        Log.d(NETWORK, "Loading url: %s", url);

        if (adView == null)
        {
            createAdView(getContext());
        }

        setState(State.Loading);
        adView.loadUrl(url);

        scheduleLoadingTimer();
        scheduleHeartbeatTimer();
    }

    ////////////////////////////////////////////////////////////////
    // Content

    @Override
    public void cancelLoadContent()
    {
        setState(State.NotLoaded);

        if (ThreadUtils.isRunningOnUiThread())
        {
            cancelLoadContent0();
        }
        else
        {
            ThreadUtils.runOnUiThread(new Runnable()
            {
                @Override
                public void run()
                {
                    cancelLoadContent0();
                }
            });
        }

        super.cancelLoadContent();
    }

    @Override
    public void contentDidLoad()
    {
        setState(State.Loaded);

        super.contentDidLoad();
        notifyAdReceive();
    }

    @Override
    public void contentDidFailWithError(Throwable error)
    {
        setState(State.Failed);

        super.contentDidFailWithError(error);
        notifyAdFail(ERROR_EXCEPTION_THROWN, error != null ? error.getMessage() : null);
    }

    private void setState(State state)
    {
        State oldState = this.state;
        this.state = state;
        Log.d(COMMON, "Interstitial ad view state: %s", state);
        
        if (Debug.flag)
        {
            switch (state)
            {
                case NotLoaded:
                    break;
                    
                case Loading:
                    Debug.assertion(oldState == State.NotLoaded || oldState == State.Failed, "Unexpected old state: " + oldState);
                    break;
                    
                case Loaded:
                    Debug.assertion(oldState == State.Loading || oldState == State.Closed, "Unexpected old state: " + oldState);
                    break;
                    
                case Failed:
                    Debug.assertion(oldState == State.Loading, "Unexpected old state: " + oldState);
                    break;
                    
                case Closed:
                    Debug.assertion(oldState == State.Presented, "Unexpected old state: " + oldState);
                    break;
                    
                case Presented:
                    Debug.assertion(oldState == State.Loaded, "Unexpected old state: " + oldState);
                    break;
            }
        }
    }

    public boolean isPresented()
    {
        return state == State.Presented;
    }

    private void cancelLoadContent0()
    {
        if (adView != null)
        {
            adView.stopLoading();
        }

        cancelHeartbeatTimer();
        cancelLoadingTimer();
    }

    ////////////////////////////////////////////////////////////////
    // Listener notifications

    protected void notifyAdReceive()
    {
        cancelLoadingTimer();

        Log.i(CALLBACKS, "Interstitial ad view received");

        InterstitialAdViewListener listener = getListener();
        if (listener != null)
        {
            listener.onInterstitialAdReceive(this);
        }
    }

    protected void notifyAdFail(int code, String reason)
    {
        cancelLoadingTimer();
        cancelHeartbeatTimer();

        Log.e(CALLBACKS, "Interstitial ad did fail to receive: code=%d reason=%s", code, reason);
        
        InterstitialAdViewListener listener = getListener();
        if (listener != null)
        {
            listener.onInterstitialAdFail(this, code, reason);
        }
    }

    protected void notifyAdOpen()
    {
        Log.i(CALLBACKS, "Interstitial ad did open");
        
        InterstitialAdViewListener listener = getListener();
        if (listener != null)
        {
            listener.onInterstitialAdOpen(this);
        }
    }

    protected void notifyAdClose()
    {
        Log.i(CALLBACKS, "Interstitial ad did close");
        
        InterstitialAdViewListener listener = getListener();
        if (listener != null)
        {
            listener.onInterstitialAdClose(this);
        }
    }

    protected void notifyAdLeaveApplication()
    {
        Log.i(CALLBACKS, "Interstitial ad will leave");
        
        InterstitialAdViewListener listener = getListener();
        if (listener != null)
        {
            listener.onInterstitialAdLeaveApplication(this);
        }
    }

    ////////////////////////////////////////////////////////////////
    // Ad view

    protected void createAdView(Context context)
    {
        Debug.assertNull(adView, "adView");
        destroyAdView();

        adView = createHtmlAdView(context);
        adView.setListener(this);

        setState(State.NotLoaded);
    }

    protected HtmlAdView createHtmlAdView(Context context)
    {
        HtmlAdView adView = new HtmlAdView(context);

        LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        layoutParams.addRule(RelativeLayout.CENTER_IN_PARENT);
        addView(adView, layoutParams);

        return adView;
    }

    private void destroyAdView()
    {
        if (adView != null)
        {
            removeView(adView);
            adView.destroy();
            adView = null;

            setState(State.NotLoaded);
        }

        timers.cancel();
    }

    ////////////////////////////////////////////////////////////////
    // GpnViewListener

    @Override
    public void onAdViewLoad(HtmlAdView view)
    {
        contentDidLoad();
    }

    @Override
    public void onAdViewFail(HtmlAdView htmlAdView, int errorCode, String description, String failingUrl)
    {
        notifyAdFail(ERROR_URL_LOADING, description);
    }

    @Override
    public void onModalViewShow(HtmlAdView view)
    {
        setState(State.Presented);
        notifyAdOpen();
    }

    @Override
    public void onModalViewHide(HtmlAdView view)
    {
        detachFromParent();
        
        setState(State.Closed);
        notifyAdClose();
    }

    @Override
    public void onApplicationWillLeave(HtmlAdView view)
    {
        notifyAdLeaveApplication();
    }

    @Override
    public void onHeartBeat(HtmlAdView view)
    {
        resetHeartbeatTimer();
    }

    @Override
    public void onPresented(HtmlAdView htmlAdView)
    {
        cancelPresentedTimer();
    }

    @Override
    public void onDebugEvent(HtmlAdView view, String name, Map<String, Object> params)
    {
        Debug.logEvent(name, params);
    }

    public void onForegroundStateChanged(boolean runsInForeground)
    {
        if (adView != null)
        {
            adView.onForegroundStateChanged(runsInForeground);
        }
    }

    ////////////////////////////////////////////////////////////////
    // Loading timer

    protected boolean scheduleLoadingTimer()
    {
        Settings settings = getSettings();
        if (settings != null)
        {
            if (settings.isLoadingTimerEnabled())
            {
                long timeout = settings.getLoadingTimeout();
                Debug.assertion(timeout > 0);
                if (timeout > 0)
                {
                    scheduleLoadingTimer(timeout);
                    return true;
                }

                Log.w(TIMERS, "Can't schedule 'loading' timer. Delay is incorrect: %d", timeout);
            }
            else
            {
                Log.w(TIMERS, "'loading' timer is disabled in settings");
            }
        }

        return false;
    }

    private void scheduleLoadingTimer(long delay)
    {
        cancelLoadingTimer();

        Timer timer = Global.scheduleTimer(delay, new Runnable()
        {
            @Override
            public void run()
            {
                onLoadingTimer();
            }
        }, false, timers, Constants.TIMER_LOADING);
        timer.setTicksWhenSuspended(true);

        Log.d(TIMERS, "Scheduled loading timer: %d", delay);
    }

    protected boolean cancelLoadingTimer()
    {
        boolean succeed = timers.cancel(Constants.TIMER_LOADING);
        Log.d(succeed, TIMERS, "Cancelled loading timer");
        return succeed;
    }

    protected void onLoadingTimer()
    {
        CrossPromotionImpl cp = Global.getImpl();
        Debug.assertNotNull(cp, "cp");
        if (cp != null)
        {
            cp.onLoadingTimeout();
        }
    }

    ////////////////////////////////////////////////////////////////
    // Presented timer

    protected boolean schedulePresentedTimer()
    {
        Settings settings = getSettings();
        if (settings != null)
        {
            if (settings.isPresentingTimerEnabled())
            {
                long timeout = settings.getPresentingTimeout();
                Debug.assertion(timeout > 0);
                if (timeout > 0)
                {
                    schedulePresentedTimer(timeout);
                    return true;
                }

                Log.w(TIMERS, "Can't schedule 'presenting' timer. Delay is incorrect: %d", timeout);
            }
            else
            {
                Log.w(TIMERS, "Presenting timer disabled in settings");
            }
        }

        return false;
    }

    private void schedulePresentedTimer(long delay)
    {
        cancelPresentedTimer();

        Timer timer = Global.scheduleTimer(delay, new Runnable()
        {
            @Override
            public void run()
            {
                onPresentingTimer();
            }
        }, false, timers, Constants.TIMER_PRESENTING);
        timer.setTicksWhenSuspended(true);

        Log.d(TIMERS, "Scheduled presenting timer: %d", delay);
    }

    protected boolean cancelPresentedTimer()
    {
        boolean succeed = timers.cancel(Constants.TIMER_PRESENTING);
        Log.d(succeed, TIMERS, "Cancelled presenting timer");
        return succeed;
    }

    protected void onPresentingTimer()
    {
        CrossPromotionImpl cp = Global.getImpl();
        Debug.assertNotNull(cp, "cp");
        if (cp != null)
        {
            cp.onPresentedTimeout();
        }
    }

    ////////////////////////////////////////////////////////////////
    // Hearbeat timer

    protected boolean scheduleHeartbeatTimer()
    {
        Settings settings = getSettings();
        if (settings != null)
        {
            if (settings.isHeartbeatEnabled())
            {
                long timeout = settings.getHeartbeatTimeout();
                Debug.assertion(timeout > 0);
                if (timeout > 0)
                {
                    scheduleHeartbeatTimer(timeout);
                    return true;
                }

                Log.w(TIMERS, "Can't schedule 'heartbeat' timer. Delay is incorrect: %d", timeout);
            }
            else
            {
                Log.w(TIMERS, "Heartbeat timer is disabled in settings");
            }
        }

        return false;
    }

    private void scheduleHeartbeatTimer(long delay)
    {
        cancelHeartbeatTimer();

        Timer heartbeatTimer = Global.scheduleTimer(delay, new Runnable()
        {
            @Override
            public void run()
            {
                onHeartbeatTimer();
            }
        }, false, timers, Constants.TIMER_HEARTBEAT);
        heartbeatTimer.setTicksWhenSuspended(true);

        Log.d(TIMERS, "Scheduled heartbeat timer: %d", delay);
    }

    protected void resetHeartbeatTimer()
    {
        Timer heartbeatTimer = timers.timerNamed(Constants.TIMER_HEARTBEAT);
        if (heartbeatTimer != null)
        {
            heartbeatTimer.reset();
            Log.d(TIMERS, "Resetted heart beat timer");
        }
    }

    protected boolean cancelHeartbeatTimer()
    {
        boolean succeed = timers.cancel(Constants.TIMER_HEARTBEAT);
        Log.d(succeed, TIMERS, "Cancelled hearbeat timer");
        return succeed;
    }

    protected void onHeartbeatTimer()
    {
        CrossPromotionImpl cp = Global.getImpl();
        Debug.assertNotNull(cp, "cp");
        if (cp != null)
        {
            cp.onHeartbeatTimeout();
        }
    }

    ////////////////////////////////////////////////////////////////
    // Getters/Setters

    public InterstitialAdViewListener getListener()
    {
        return listener;
    }

    public void setListener(InterstitialAdViewListener listener)
    {
        this.listener = listener;
    }

    protected HtmlAdView getAdView()
    {
        return adView;
    }

    public boolean isLoaded()
    {
        return state == State.Loaded;
    }

    private Settings getSettings()
    {
        Settings settings = Global.getSettings();
        Debug.assertNotNull(settings, "settings");

        return settings;
    }
}
