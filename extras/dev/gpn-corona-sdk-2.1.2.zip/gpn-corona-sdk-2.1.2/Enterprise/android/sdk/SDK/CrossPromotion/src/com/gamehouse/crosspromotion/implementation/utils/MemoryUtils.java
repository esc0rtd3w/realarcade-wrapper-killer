//
//  MemoryUtils.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import android.text.SpannableStringBuilder;

public class MemoryUtils
{
	private static long KILOBYTE = 1024;
	private static long MEGABYTE = 1024 * 1024;
	
	private static float TO_KILOBYTES_MUL = 1.0f / KILOBYTE;
	private static float TO_MEGABYTES_MUL = 1.0f / MEGABYTE;
	
	private static StringBuilder tempBuffer = new StringBuilder();
	
	public static long getAvailableMemory()
	{
		return getTotalMemory() - getUsedMemory();
	}
	
	public static long getFreeHeapMemory()
	{
		return Runtime.getRuntime().freeMemory();
	}
	
	public static long getHeapMemory()
	{
		return Runtime.getRuntime().totalMemory();
	}
	
	public static long getUsedMemory()
	{
		return getHeapMemory() - getFreeHeapMemory();
	}
	
	public static long getTotalMemory()
	{
		return Runtime.getRuntime().maxMemory();
	}
	
	public static String toMemString(long bytes)
	{
		tempBuffer.setLength(0);
		appendMemString(tempBuffer, bytes);
		
		return tempBuffer.toString();
	}
	
	public static void appendMemString(SpannableStringBuilder buffer, long bytes)
	{
		tempBuffer.setLength(0);
		appendMemString(tempBuffer, bytes);
		buffer.append(tempBuffer);
	}
	
	public static void appendMemString(StringBuilder buffer, long bytes)
	{
		if (bytes > MEGABYTE)
		{
			appendMemString(buffer, toMegabytes(bytes), " MB");
		}
		else if (bytes > KILOBYTE)
		{
			appendMemString(buffer, toKilobytes(bytes), " KB");
		}
		else
		{
			buffer.append(bytes);
			buffer.append(" B");
		}
	}
	
	private static void appendMemString(StringBuilder buffer, float value, String prefix)
	{
		int integer = (int)value;
		int fractional = ((int)(value * 10)) % 10;
		buffer.append(integer);
		buffer.append('.');
		buffer.append(fractional);
		if (prefix != null)
		{
			buffer.append(prefix);
		}
	}
	
	public static float toKilobytes(long bytes)
	{
		return (float) (bytes * TO_KILOBYTES_MUL);
	}
	
	public static float toMegabytes(long bytes)
	{
		return (float) (bytes * TO_MEGABYTES_MUL);
	}
	
	public static long megabytesToBytes(float megabytes)
	{
		return (long) (megabytes * MEGABYTE);
	}
	
	public static long kilobytesToBytes(float kilobytes)
	{
		return (long) (kilobytes * KILOBYTE);
	}
}
