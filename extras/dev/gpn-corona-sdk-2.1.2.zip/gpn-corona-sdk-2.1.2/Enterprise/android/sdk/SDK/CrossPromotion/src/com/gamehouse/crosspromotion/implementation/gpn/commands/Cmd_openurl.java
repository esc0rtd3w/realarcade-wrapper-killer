//
//  Cmd_openurl.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.gpn.commands;

import com.gamehouse.crosspromotion.implementation.gpn.HtmlAdView;
import com.gamehouse.crosspromotion.implementation.gpn.JavaScriptCommand;
import com.gamehouse.crosspromotion.implementation.gpn.JavaScriptCommandException;

public class Cmd_openurl extends JavaScriptCommand
{
    private static final String PARAM_URL = "url";

    @Override
    public void execute() throws JavaScriptCommandException
    {
        String url = getStringParam(PARAM_URL);
        if (url == null)
        {
            throw new JavaScriptCommandException("Required param is missing: " + PARAM_URL);
        }

        HtmlAdView adView = getAdView();
        if (adView != null)
        {
            boolean succeed = adView.tryOpenWithExternalActivity(url);
            if (!succeed)
            {
                throw new JavaScriptCommandException("Opening external URL failed");
            }
        }
    }

}
