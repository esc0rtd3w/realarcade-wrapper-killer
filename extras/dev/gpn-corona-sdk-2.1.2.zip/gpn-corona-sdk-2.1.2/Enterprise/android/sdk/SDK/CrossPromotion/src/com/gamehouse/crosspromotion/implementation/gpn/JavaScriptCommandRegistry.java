//
//  JavaScriptCommandRegistry.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.gpn;

import java.util.HashMap;
import java.util.Map;

import com.gamehouse.crosspromotion.implementation.gpn.commands.Cmd_cancel;
import com.gamehouse.crosspromotion.implementation.gpn.commands.Cmd_close;
import com.gamehouse.crosspromotion.implementation.gpn.commands.Cmd_complete;
import com.gamehouse.crosspromotion.implementation.gpn.commands.Cmd_debugEvent;
import com.gamehouse.crosspromotion.implementation.gpn.commands.Cmd_error;
import com.gamehouse.crosspromotion.implementation.gpn.commands.Cmd_hearbeat;
import com.gamehouse.crosspromotion.implementation.gpn.commands.Cmd_openurl;
import com.gamehouse.crosspromotion.implementation.gpn.commands.Cmd_presented;
import com.gamehouse.crosspromotion.implementation.utils.ClassUtils;

public class JavaScriptCommandRegistry
{
	private static Map<String, JavaScriptCommandFactory> commandMap = new HashMap<String, JavaScriptCommandFactory>();
	
	static
	{
		commandMap.put("close", new JavaScriptCommandFactory()
		{
			public JavaScriptCommand create()
			{
				return new Cmd_close();
			}
		});
		
		commandMap.put("cancel", new JavaScriptCommandFactory()
		{
			@Override
			public JavaScriptCommand create()
			{
				return new Cmd_cancel();
			}
		});
		
		commandMap.put("complete", new JavaScriptCommandFactory()
		{
			@Override
			public JavaScriptCommand create()
			{
				return new Cmd_complete();
			}
		});
		
		commandMap.put("presented", new JavaScriptCommandFactory()
        {
            @Override
            public JavaScriptCommand create()
            {
                return new Cmd_presented();
            }
        });
		
		commandMap.put("error", new JavaScriptCommandFactory()
		{
			@Override
			public JavaScriptCommand create()
			{
				return new Cmd_error();
			}
		});
		
		commandMap.put("heartbeat", new JavaScriptCommandFactory()
        {
            @Override
            public JavaScriptCommand create()
            {
                return new Cmd_hearbeat();
            }
        });
		
		commandMap.put("openurl", new JavaScriptCommandFactory()
        {
            @Override
            public JavaScriptCommand create()
            {
                return new Cmd_openurl();
            }
        });
		
		commandMap.put("devt", new JavaScriptCommandFactory()
        {
            @Override
            public JavaScriptCommand create()
            {
                return new Cmd_debugEvent();
            }
        });
	}
	
	public static void registerCommand(String name, final Class<? extends JavaScriptCommand> commandClass)
	{
		commandMap.put(name, new JavaScriptCommandFactory()
		{
			@Override
			public JavaScriptCommand create()
			{
				return ClassUtils.tryNewInstance(commandClass);
			}
		});
	}

	static JavaScriptCommand createCommand(String name)
	{
		JavaScriptCommandFactory factory = commandMap.get(name);
		return (factory != null) ? factory.create() : null;
	}

	private interface JavaScriptCommandFactory
	{
		public JavaScriptCommand create();
	}
}
