//
//  Chunk.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.debug;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.gamehouse.crosspromotion.debug.utils.ObjectsPoolEntry;

public abstract class Chunk extends ObjectsPoolEntry
{
	private String name;
	
	protected Chunk(String name)
	{
		if (name.length() != 4)
		{
			throw new IllegalArgumentException("Name length should be 4 chars long");
		}
		
		this.name = name;
	}
	
	public abstract void write(DataOutput output) throws IOException;
	public abstract void read(DataInput input) throws IOException;
	
	protected static void writeUTF(DataOutput out, Object obj) throws IOException
	{
		out.writeBoolean(obj != null);
		if (obj != null)
		{
			out.writeUTF(obj.toString());
		}
	}
	
	protected static String readUTF(DataInput in) throws IOException
	{
		boolean notNull = in.readBoolean();
		if (notNull)
		{
			return in.readUTF();
		}
		
		return null;
	}
	
	protected static void writeMap(DataOutput out, Map<String, Object> map) throws IOException
	{
		out.writeBoolean(map != null);
		if (map != null)
		{
			out.writeInt(map.size());
			Set<Entry<String, Object>> entries = map.entrySet();
			for (Entry<String, Object> e : entries)
			{
				writeUTF(out, e.getKey());
				writeUTF(out, e.getValue());
			}
		}
	}
	
	protected static Map<String, Object> readMap(DataInput in) throws IOException
	{
		boolean notNull = in.readBoolean();
		if (notNull)
		{
			int size = in.readInt();
			Map<String, Object> map = new HashMap<String, Object>();
			
			for (int i = 0; i < size; ++i)
			{
				String key = readUTF(in);
				String value = readUTF(in);
				
				map.put(key, value);
			}
			
			return map;
		}
		
		return null;
	}
	
	public String getName()
	{
		return name;
	}
}
