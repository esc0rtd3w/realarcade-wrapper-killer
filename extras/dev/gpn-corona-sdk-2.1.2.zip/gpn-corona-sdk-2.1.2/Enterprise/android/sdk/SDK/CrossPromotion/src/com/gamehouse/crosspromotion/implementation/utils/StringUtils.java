//
//  StringUtils.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class StringUtils
{
	/** Tries to parse string. Returns 0 if impossible or value is null. */
	public static int tryParseInt(String value)
	{
		return tryParseInt(value, 0);
	}

	/**
	 * Tries to parse string. Returns <code>defaultValue</code> if impossible or
	 * value is null.
	 */
	public static int tryParseInt(String value, int defaultValue)
	{
		if (value == null)
		{
			return defaultValue;
		}

		try
		{
			return Integer.parseInt(value);
		}
		catch (NumberFormatException e)
		{
			Log.logException(e, "Can't parse int value '%s'", value);
		}
		return defaultValue;
	}

	/**
	 * Tries to parse string. Returns <code>0.0f</code> if impossible or value
	 * is null.
	 */
	public static float tryParseFloat(String value)
	{
		return tryParseFloat(value, 0.0f);
	}

	/**
	 * Tries to parse string. Returns <code>defaultValue</code> if impossible or
	 * value is null.
	 */
	public static float tryParseFloat(String value, float defaultValue)
	{
		if (value == null)
		{
			return defaultValue;
		}

		try
		{
			return Float.parseFloat(value);
		}
		catch (NumberFormatException e)
		{
			Log.logException(e, "Can't parse float value '%s'", value);
		}
		return defaultValue;
	}

	/** Tries to parse string. Returns false if impossible or value is null. */
	public static boolean tryParseBool(String value)
	{
		return tryParseBool(value, false);
	}

	/**
	 * Tries to parse string. Returns <code>defaultValue</code> if impossible or
	 * value is null.
	 */
	public static boolean tryParseBool(String value, boolean defaultValue)
	{
		if (value == null)
		{
			return defaultValue;
		}

		try
		{
			return Boolean.parseBoolean(value);
		}
		catch (Exception e)
		{
			Log.logException(e, "Can't parse bool value: %s", value);
		}

		return defaultValue;
	}

	/** Tries to perform string format. Returns null if fails. */
	public static String tryFormatString(String format, Object... args)
	{
		if (format != null && args != null && args.length > 0)
		{
			try
			{
				return String.format(format, args);
			}
			catch (Exception e)
			{
				Log.logException(e, "Error in string format: " + format);
			}
		}

		return format;
	}

	public static String tryRemovePrefix(String str, String prefix)
	{
		if (prefix == null)
		{
			throw new IllegalArgumentException("Prefix is null");
		}

		if (str != null && str.startsWith(prefix))
		{
			return str.substring(prefix.length());
		}

		return str;
	}

	public static String tryRemoveSuffix(String str, String sufix)
	{
		if (sufix == null)
		{
			throw new IllegalArgumentException("Prefix is null");
		}

		if (str != null && str.endsWith(sufix))
		{
			return str.substring(0, str.length() - sufix.length());
		}

		return str;
	}
	
	/**
     * Create URL encoded params string from the map of key-value pairs
     * 
     * @throws IllegalArgumentException
     *             if map, any key or value appears to be null
     */
    // TODO: cover me with tests, please
    public static String encodeURLParams(Map<String, Object> params)
    {
        if (params == null)
        {
            throw new IllegalArgumentException("Params are null");
        }

        StringBuilder result = new StringBuilder();

        Set<Entry<String, Object>> entries = params.entrySet();
        for (Entry<String, Object> e : entries)
        {

            String key = e.getKey();
            if (key == null)
            {
                throw new IllegalArgumentException("key is null");
            }

            Object valueObj = e.getValue();
            if (valueObj == null)
            {
                throw new IllegalArgumentException("value is null for key '" + key + "'");
            }

            String value = valueObj.toString();

            @SuppressWarnings("deprecation")
            String encodedKey = URLEncoder.encode(key);
            @SuppressWarnings("deprecation")
            String encodedValue = URLEncoder.encode(value);

            result.append(result.length() == 0 ? "?" : "&");
            result.append(encodedKey);
            result.append("=");
            result.append(encodedValue);
        }
        return result.toString();
    }

	public static String encodeURLString(String value)
	{
		try
		{
			return value != null ? URLEncoder.encode(value, "utf-8") : null;
		}
		catch (Exception e)
		{
		}

		return value;
	}

	public static String decodeURLString(String value)
	{
		try
		{
			return value != null ? URLDecoder.decode(value, "utf-8") : null;
		}
		catch (Exception e)
		{
		}

		return value;
	}

	/** Tries to create string from bytes array. Returns null is not succeed. */
	public static String stringFromBytes(byte[] data, String charset)
	{
		try
		{
			return new String(data, charset);
		}
		catch (Exception e)
		{
			Log.logException(e, "Unable to create string from the byte array");
		}
		return null;
	}

	/**
	 * Converts the byte[] to 32 bit String representation of md5 hash format
	 * 
	 * @param data
	 *            : The byte[] having the md5 representation that needs the
	 *            conversion
	 */
	public static String toHexString(byte[] data)
	{
		StringBuffer buf = new StringBuffer();
		for (byte element : data)
		{
			int halfbyte = element >>> 4 & 0xF;
			int two_halfs = 0;
			do
			{
				if ((halfbyte >= 0) && (halfbyte <= 9))
					buf.append((char) (48 + halfbyte));
				else
				{
					buf.append((char) (97 + halfbyte - 10));
				}
				halfbyte = element & 0xF;
			}
			while (two_halfs++ < 1);
		}
		return buf.toString();
	}
}
