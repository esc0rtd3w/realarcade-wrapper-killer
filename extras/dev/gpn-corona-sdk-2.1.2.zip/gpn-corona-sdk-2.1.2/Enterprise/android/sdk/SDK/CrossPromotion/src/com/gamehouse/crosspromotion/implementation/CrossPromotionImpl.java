//
//  CrossPromotionImpl.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation;

import static com.gamehouse.crosspromotion.implementation.Constants.PREFS_NAMES;
import static com.gamehouse.crosspromotion.implementation.Constants.SERVER_DEFAULT_URL;

import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.Map;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotion.implementation.ads.URLRequest;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView.InterstitialResult;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdViewInternal;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdViewListener;
import com.gamehouse.crosspromotion.implementation.network.HttpJSonRequest;
import com.gamehouse.crosspromotion.implementation.network.HttpRequest;
import com.gamehouse.crosspromotion.implementation.network.HttpRequestAdapter;
import com.gamehouse.crosspromotion.implementation.network.RequestManager;
import com.gamehouse.crosspromotion.implementation.settings.Settings;
import com.gamehouse.crosspromotion.implementation.utils.ClassUtils;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.GoogleAdvertisingID;
import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.ManifestUtils;
import com.gamehouse.crosspromotion.implementation.utils.ThreadUtils;
import com.gamehouse.crosspromotion.implementation.utils.GoogleAdvertisingID.Info;
import com.gamehouse.crosspromotion.implementation.utils.json.JSON;
import com.gamehouse.crosspromotion.implementation.utils.observing.NotificationService;
import com.gamehouse.crosspromotion.implementation.utils.timers.Timer;
import com.gamehouse.crosspromotion.implementation.utils.timers.TimerGroup;
import com.gamehouse.crosspromotion.implementation.utils.timers.TimerManager;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class CrossPromotionImpl extends CrossPromotion implements InterstitialAdViewListener, GoogleAdvertisingID.ResolveListener
{
	private String appId;
	private WeakReference<Context> contextRef;

	private ServerApi serverApi;
	private InterstitialAdView interstitialAdView;
	
	private int onStartOnStopCallsCount;
	private boolean runsInForeground;
	
	private TimerManager timerMananger;
	private RequestManager requestManager;
	
	private Settings settings;
	private SettingsListener settingsListener;
	
	private WeakReference<InterstitialAdViewListener> listenerRef;
	
	private static String overridenServerURL;

	public CrossPromotionImpl(Context context, String appId)
	{
	    if (context == null)
        {
            throw new NullPointerException("context is null");
        }
	    
	    if (appId == null)
        {
            throw new NullPointerException("appId is null");
        }
	    
		checkPermissions(context);

		this.appId = appId;

		String serverURL = SERVER_DEFAULT_URL;
		if (Debug.flag && overridenServerURL != null)
		{
		    serverURL = overridenServerURL;
		}
		
        serverApi = new ServerApi(context, serverURL);
		contextRef = new WeakReference<Context>(context.getApplicationContext());
		
		timerMananger = new TimerManager();
		Debug.onTimerManagerCreated(timerMananger); // TODO: replace with notification
		
		requestManager = new RequestManager();
		Debug.onRequestManagerCreated(requestManager);
		
		settings = new Settings();
		
		GoogleAdvertisingID.getId(context, this);
	}

	////////////////////////////////////////////////////////////////
	// Request

	@Override
	public void startRequestingInterstitials(final InterstitialAdViewListener listener)
	{
		if (listener == null)
		{
			throw new NullPointerException("listener is null");
		}

		final Context context = getContext();
		if (context == null)
		{
			Log.logCrit("Can't request interstitial ad view. Application context is lost");
			return;
		}
		
		if (ThreadUtils.isRunningOnUiThread())
		{
			startRequestingInterstitials(context, listener);
		}
		else
		{
			Log.d(COMMON, "Request interstitial is called a secondary thread. Calling on ui thread...");
			ThreadUtils.runOnUiThread(new Runnable() 
			{
				@Override
				public void run() 
				{
					startRequestingInterstitials(context, listener);
				}
			});
		}
	}

	protected void startRequestingInterstitials(Context context, InterstitialAdViewListener listener) 
	{
		Debug.assertion(ThreadUtils.isRunningOnUiThread());
		
		try
		{
			stopRequestingInterstitials();
			
			interstitialAdView = createInterstitialAdView(context);
			listenerRef = new WeakReference<InterstitialAdViewListener>(listener);

			Log.i(COMMON, "Requesting interstitial ad...");
			Map<String, Object> params = listener.createInterstitialAdParams();

			URLRequest request = serverApi.createInitRequest(context, appId, params);
			interstitialAdView.setListener(this);
			interstitialAdView.loadRequest(request);
		}
		catch (Throwable e)
		{
			Log.logException(e, "Unable to request interstitial ad");
			listener.onInterstitialAdFail(interstitialAdView, ERROR_EXCEPTION_THROWN, e.getMessage());
		}
	}

	@Override
	public boolean stopRequestingInterstitials()
	{
		try
		{
			if (interstitialAdView != null)
			{
			    interstitialAdView.close();
				interstitialAdView.setListener(null);
				interstitialAdView.destroy();

				interstitialAdView = null;
				
				return true;
			}
		}
		catch (Throwable e)
		{
			Log.logException(e, "Error while cancelling interstitial request");
		}
		
		return false;
	}

	protected InterstitialAdView createInterstitialAdView(Context context)
	{
		return new InterstitialAdViewInternal(context);
	}

	////////////////////////////////////////////////////////////////
	// Present

	@Override
	public InterstitialResult present(Context context)
	{
		return present(context, null);
	}

	@Override
	public InterstitialResult present(Context context, Map<String, Object> params)
	{
		if (context == null)
		{
			throw new NullPointerException("activity is null");
		}

		return interstitialAdView != null ? interstitialAdView.present(context, params) : InterstitialResult.NotPresented;
	}

	public void hide()
	{
		if (interstitialAdView != null)
		{
			interstitialAdView.close();
		}
	}
	
	////////////////////////////////////////////////////////////////
    // InterstitialAdViewListener
	
	@Override
    public void onInterstitialAdReceive(InterstitialAdView adView)
    {
	    try
        {
            InterstitialAdViewListener listener = getListener();
            if (listener != null)
            {
                listener.onInterstitialAdReceive(adView);
            }
            else
            {
                Log.logCrit("Unable to notify listener since its weak reference is null");
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while notifying listener");
        }
    }

    @Override
    public void onInterstitialAdFail(InterstitialAdView adView, int code, String reason)
    {
        stopRequestingInterstitials();
        
        try
        {
            InterstitialAdViewListener listener = getListener();
            if (listener != null)
            {
                listener.onInterstitialAdFail(adView, code, reason);
            }
            else
            {
                Log.logCrit("Unable to notify listener since its weak reference is null");
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while notifying listener");
        }
    }

    @Override
    public void onInterstitialAdOpen(InterstitialAdView adView)
    {
        try
        {
            InterstitialAdViewListener listener = getListener();
            if (listener != null)
            {
                listener.onInterstitialAdOpen(adView);
            }
            else
            {
                Log.logCrit("Unable to notify listener since its weak reference is null");
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while notifying listener");
        }
    }

    @Override
    public void onInterstitialAdClose(InterstitialAdView adView)
    {
        try
        {
            InterstitialAdViewListener listener = getListener();
            if (listener != null)
            {
                listener.onInterstitialAdClose(adView);
            }
            else
            {
                Log.logCrit("Unable to notify listener since its weak reference is null");
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while notifying listener");
        }
    }

    @Override
    public void onInterstitialAdLeaveApplication(InterstitialAdView adView)
    {
        try
        {
            InterstitialAdViewListener listener = getListener();
            if (listener != null)
            {
                listener.onInterstitialAdLeaveApplication(adView);
            }
            else
            {
                Log.logCrit("Unable to notify listener since its weak reference is null");
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while notifying listener");
        }
    }

    @Override
    public Map<String, Object> createInterstitialAdParams()
    {
        try
        {
            InterstitialAdViewListener listener = getListener();
            if (listener != null)
            {
                return listener.createInterstitialAdParams();
            }
            else
            {
                Log.logCrit("Unable to create interstitial params since listener's weak reference is null");
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while creating interstitial params");
        }
        
        return null;
    }
	
	////////////////////////////////////////////////////////////////
	// Activity callbacks
	
	@Override
	public void onResume()
	{
		try
        {
            ++onStartOnStopCallsCount;
            if (onStartOnStopCallsCount == 1)
            {
            	postForegroundRunnable();
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while handling activity resume");
        }
	}
	
	@Override
	public void onPause()
	{
		Debug.assertion(onStartOnStopCallsCount > 0, "Unballanced calls onStart()/onStop() calls count: %d", onStartOnStopCallsCount);
		try
        {
            --onStartOnStopCallsCount;
            if (onStartOnStopCallsCount == 0)
            {
            	postBackgroundRunnable();
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while handling activity pause");
        }
	}
	
	////////////////////////////////////////////////////////////////
	// Background/Foreground
	
	private Runnable backgroundRunnable = new Runnable()
	{
		@Override
		public void run()
		{
			if (runsInForeground)
			{
				runsInForeground = false;
				onEnterBackground();
			}
		}
	};
	
	private Runnable foregroundRunnable = new Runnable()
	{
		@Override
		public void run()
		{
			if (!runsInForeground)
			{
				runsInForeground = true;
				onEnterForeground();
			}
		}
	};
	
	private void postBackgroundRunnable()
	{
		cancelCallbacks();
		scheduleTimer(1000, backgroundRunnable, false, null, "Background");
	}
	
	private void postForegroundRunnable()
	{
		cancelCallbacks();
		scheduleTimer(1000, foregroundRunnable, false, null, "Foreground");
	}
	
	private void cancelCallbacks()
	{
		cancelTimer(backgroundRunnable);
		cancelTimer(foregroundRunnable);
	}
	
	private void onEnterForeground()
	{
		Log.d(COMMON, "Application enters foreground");
		try
		{
			if (interstitialAdView != null)
			{
				interstitialAdView.onForegroundStateChanged(true);
			}
			timerMananger.resume();
		}
		catch (Throwable e)
		{
			Log.logException(e, "Error while entering foreground");
		}
	}
	
	private void onEnterBackground()
	{
		Log.d(COMMON, "Application enters background");
		try
		{
			if (interstitialAdView != null)
			{
				interstitialAdView.onForegroundStateChanged(false);
			}
			timerMananger.suspend();
		}
		catch (Throwable e)
		{
			Log.logException(e, "Error while entering background");
		}
	}
	
	public boolean isRunningForeground()
	{
		return runsInForeground;
	}

	////////////////////////////////////////////////////////////////
	// Timers
	
	public Timer scheduleTimer(long delayMillis, Runnable target, boolean repeated, TimerGroup group, String tag)
	{
		return timerMananger.scheduleTimer(delayMillis, target, repeated, group, tag);
	}
	
	public void cancelTimer(Runnable target)
	{
		timerMananger.cancel(target);
	}
	
	public TimerManager getTimerMananger()
    {
        return timerMananger;
    }
	
	////////////////////////////////////////////////////////////////
    // Settings
	
    protected void requestSettings()
    {
        final Context context = getContext();
	    if (context == null)
	    {
	        Log.logCrit("Can't request settings. Context is null");
	        return;
	    }
	    
        try
        {
            File dir = context.getDir("com.gamehouse.gpn.data", Context.MODE_PRIVATE);
            File file = new File(dir, "settings.dat");
            final String filename = file.getAbsolutePath();
            
            // try to load settigns from file
            if (file.exists())
            {
                try
                {
                    settings.load(filename);
                    Log.d(SETTINGS, "Settings loaded from file: %s", filename);
                }
                catch (IOException e)
                {
                    Log.logException(e, "Can't load GPN settings");
                }
            }
            
            // request settings from the server
            URLRequest request = serverApi.createSettingsRequest(context, getAppId());
            Log.d(SETTINGS, "Loading settings with URL: %s", request.absoluteURL());
            
            HttpJSonRequest settingsRequest = new HttpJSonRequest(request.absoluteURL());
            settingsRequest.setListener(new HttpRequestAdapter<HttpJSonRequest>()
            {
                @Override
                public void onFinish(HttpJSonRequest request)
                {
                    JSON json = request.getResponseJson();
                    Debug.assertNotNull(json, "json");
                    
                    Log.d(SETTINGS, "Settings response: %s", json);
                    
                    try
                    {
                        settings.load(json);
                        Log.d(SETTINGS, "Settings loaded from the server");
                        settings.save(filename);
                        Log.d(SETTINGS, "Settings save to file: %s", filename);
                        
                        if (settingsListener != null)
                        {
                            settingsListener.onSettingsLoaded(settings);
                        }

                        // install tracking URL
                        String installTrackingURL = settings.getInstallTrackingURL();
                        if (installTrackingURL != null)
                        {
                            if (!isInstallTracked(context))
                            {
                                trackInstall(context, installTrackingURL);
                            }
                            else
                            {
                                Log.d(COMMON, "Install already tracked");
                            }
                        }
                        else
                        {
                            Log.w(COMMON, "Can't track installation: no tracking URL");
                        }
                    }
                    catch (Throwable e)
                    {
                        Log.logException(e, "Unable to get settings from the server");
                    }
                }
                
                @Override
                public void onFailure(HttpJSonRequest request, int code, String message)
                {
                    Log.e(SETTINGS, "Settings request failed: %s", message);
                }
            });
            
            settingsRequest.setManager(requestManager);
            settingsRequest.start();
        }
        catch (Exception e)
        {
            Log.logException(e, "Unable to initialize settings");
        }
    }
    
    ////////////////////////////////////////////////////////////////
    // Loading timeout
    
    public void onLoadingTimeout()
    {
        Log.d(TIMERS, "Loading timeout");
        
        try
        {
            Debug.assertNotNull(interstitialAdView, "interstitialAdView");
            if (interstitialAdView != null)
            {
                // keep the listener for the notification
                
                Log.i(COMMON, "Stop requesting interstitials...");
                stopRequestingInterstitials();
                
                onInterstitialAdFail(interstitialAdView, ERROR_JAVASCRIPT_FAILURE, "Loading timeout");
            }
        }
        catch (Throwable e)
        {
            Log.logCrit("Unable to restart interstitials");
        }
    }
	
	////////////////////////////////////////////////////////////////
    // Heartbeat
	
	public void onHeartbeatTimeout()
    {
	    Log.d(TIMERS, "Heartbeat timeout");
	    
	    try
        {
            Debug.assertNotNull(interstitialAdView, "interstitialAdView");
            if (interstitialAdView != null)
            {
                
                if (!settings.isForceCloseOnHeartbeatTimeout() && interstitialAdView.isShown())
                {
                    Log.d(TIMERS, "Don't force close on heartbeat");
                    InterstitialAdViewInternal internal = ClassUtils.tryStrictCast(interstitialAdView, InterstitialAdViewInternal.class);
                    if (internal != null)
                    {
                        internal.scheduleHeartbeatTimer();
                    }
                    return;
                }
                
                Log.i(COMMON, "Stop requesting interstitials...");
                stopRequestingInterstitials();
                
                if (settings.isRestartOnHeartbeatTimeout())
                {
                    InterstitialAdViewListener listener = getListener();
                    if (listener == null)
                    {
                        Log.e(COMMON, "Can't restart interstitial. Listener object is gone");
                        return;
                    }
                    
                    Log.i(COMMON, "Restart requesting interstitials...");
                    startRequestingInterstitials(listener);
                }
                else
                {
                    onInterstitialAdFail(interstitialAdView, ERROR_JAVASCRIPT_FAILURE, "Heartbeat timeout");
                }
            }
        }
        catch (Throwable e)
        {
            Log.logCrit("Unable to restart interstitials");
        }
    }
	
	////////////////////////////////////////////////////////////////
    // Presented timeout
	
	public void onPresentedTimeout()
    {
	    Log.d(TIMERS, "Presented timeout");
	    
	    try
        {
            Debug.assertNotNull(interstitialAdView, "interstitialAdView");
            if (interstitialAdView != null)
            {
                Log.i(COMMON, "Stop requesting interstitials...");
                stopRequestingInterstitials();
                
                onInterstitialAdFail(interstitialAdView, ERROR_JAVASCRIPT_FAILURE, "Presenting timeout");
            }
        }
        catch (Throwable e)
        {
            Log.logException(e, "Error while handling presenting timeout");
        }
    }
	
	////////////////////////////////////////////////////////////////
	// Install tracking
	
	private static final String KEY_INSTALL_TRACKED_FLAG = "InstallTrackedFlag";
	
	private void trackInstall(final Context context, String trackinURL)
	{
		if (context == null)
		{
			throw new NullPointerException("'context' is null");
		}
		
		if (trackinURL == null)
		{
			throw new NullPointerException("'trackinURL' is null");
		}
		
        try
        {
            URLRequest URLRequest = serverApi.createInstallTrackingRequest(context, trackinURL, getAppId());
            Log.d(COMMON, "Install tracking with URL: %s", URLRequest.absoluteURL());
            
            HttpRequest request = new HttpRequest(URLRequest.absoluteURL());
            request.setListener(new HttpRequestAdapter<HttpRequest>()
            {
                @Override
                public void onFinish(HttpRequest request)
                {
                	try
                	{
                		setInstallTracked(context, true);
                		Log.d(COMMON, "Install tracked!");
                    }
                    catch (Exception e)
                    {
                        Log.logException(e, "Unable to track install");
                    }
                }
                
                @Override
                public void onFailure(HttpRequest request, int code, String message)
                {
                    Log.e(SETTINGS, "Install not tracked: %s", message);
                }
            });
            
            request.setManager(requestManager);
            request.start();
        }
        catch (Throwable e)
        {
            Log.logException(e, "Unable to initialize settings");
        }
	}
	
	private boolean isInstallTracked(Context context)
	{
		if (context == null)
		{
			throw new NullPointerException("'context' is null");
		}
		
		try
		{
			return getPrefs(context).getBoolean(KEY_INSTALL_TRACKED_FLAG, false);
		}
		catch (Throwable e)
		{
			Log.logException(e, "Exception while checking install tracking flag");
		}
		
		return false;
	}
	
	public void setInstallTracked(Context context, boolean flag)
	{
		if (context == null)
		{
			throw new NullPointerException("'context' is null");
		}
		
		try
		{
			Editor edit = getPrefs(context).edit();
			edit.putBoolean(KEY_INSTALL_TRACKED_FLAG, flag);
			edit.commit();
		}
		catch (Throwable e)
		{
			Log.logException(e, "Exception while setting install tracking flag");
		}
	}
	
	////////////////////////////////////////////////////////////////
    // GoogleAdvertisingID.ResolveListener
	
	@Override
    public void onGoogleAdvertisingIDResolved(Info info)
    {
	    Log.d(COMMON, "Resolved Google Advertising ID: enabled %s id %s", info.isEnabled() ? "true" : "false", info.getId());
	    
        serverApi.setGoogleAidInfo(info);
        onGoogleAdvertisingFinished();
    }
    
    @Override
    public void onGoogleAdvertisingIDResolveError(int code, String message)
    {
        Log.e(COMMON, "Unable to resolve Google Advertising ID: code=%d message=%s", code, message);
        onGoogleAdvertisingFinished();
    }
    
    private void onGoogleAdvertisingFinished()
    {
        // request settings right after Google Advertising ID resolving is finished
        requestSettings();
    }
	
	////////////////////////////////////////////////////////////////
	// Getters/Setters

	@Override
	protected InterstitialAdView getInterstitialAdView()
	{
		return interstitialAdView;
	}

	@Override
	public String baseURL()
	{
		return serverApi.getBaseURL();
	}

	@Override
	public void setBaseURL(String baseURL)
	{
		serverApi.setBaseURL(baseURL);
		Log.d(COMMON, "Set base URL: %s", baseURL);
	}

	@Override
	protected String getAppId()
	{
		return appId;
	}
	
	@Override
	protected void setAppId(String appId)
	{
		this.appId = appId;
	}
	
	public String getWrapperName()
    {
        return serverApi != null ? serverApi.getWrapperName() : null;
    }
    
    public void setWrapperName(String wrapperName)
    {
        Debug.assertNotNull(serverApi, "serverApi");
        if (serverApi != null)
        {
            serverApi.setWrapperName(wrapperName);
        }
    }
    
    public String getWrapperVersion()
    {
        return serverApi != null ? serverApi.getWrapperVersion() : null;
    }
    
    public void setWrapperVersion(String wrapperVersion)
    {
        Debug.assertNotNull(serverApi, "serverApi");
        if (serverApi != null)
        {
            serverApi.setWrapperVersion(wrapperVersion);
        }
    }
	
	public Settings getSettings()
    {
        return settings;
    }
	
	public SettingsListener getSettingsListener()
    {
        return settingsListener;
    }
	
	public void setSettingsListener(SettingsListener settingsListener)
    {
        this.settingsListener = settingsListener;
    }

	protected Context getContext()
	{
		return contextRef != null ? contextRef.get() : null;
	}

	public InterstitialAdViewListener getListener()
    {
        return listenerRef != null ? listenerRef.get() : null;
    }
	
	public static void setOverridenServerURL(String overridenServerURL)
    {
        CrossPromotionImpl.overridenServerURL = overridenServerURL;
    }
	
	private SharedPreferences getPrefs(Context context)
	{
		return context.getSharedPreferences(PREFS_NAMES, Context.MODE_PRIVATE);
	}

	////////////////////////////////////////////////////////////////
	// Permissions

	private static final String[] REQUIRED_PERMISSIONS = 
	{ 
		Manifest.permission.INTERNET, 
		Manifest.permission.ACCESS_NETWORK_STATE, 
		Manifest.permission.ACCESS_WIFI_STATE, 
	};

	protected void checkPermissions(Context context)
	{
		for (String permission : REQUIRED_PERMISSIONS)
		{
			if (!ManifestUtils.isGrantedPermissions(context, permission))
			{
				Log.logCrit("Missing permisson: %s", permission);
			}
		}
	}

	////////////////////////////////////////////////////////////////
	// Inheritance

	@Override
	protected void destroyInstance()
	{
		if (ThreadUtils.isRunningOnUiThread())
		{
			destroyInstance0();
		}
		else
		{
			ThreadUtils.runOnUiThread(new Runnable() 
			{
				@Override
				public void run() 
				{
					destroyInstance0();
				}
			});
		}
	}

	private void destroyInstance0() 
	{
		stopRequestingInterstitials();
		cancelCallbacks();
		NotificationService.instance().clearObservers();
		
		timerMananger.destroy();
		Debug.onTimerManagerDestroyed(timerMananger); // TODO: replace with notification
		
		requestManager.destroy();
		Debug.onRequestManagerDestroyed(requestManager);
	}

	@Override
	protected boolean isNull()
	{
		return false;
	}
}
