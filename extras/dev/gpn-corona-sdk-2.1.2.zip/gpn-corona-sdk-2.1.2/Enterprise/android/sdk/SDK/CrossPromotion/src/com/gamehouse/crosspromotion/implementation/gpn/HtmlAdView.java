//
//  HtmlAdView.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.gpn;

import static com.gamehouse.crosspromotion.CrossPromotion.ERROR_EXCEPTION_THROWN;
import static com.gamehouse.crosspromotion.implementation.Notifications.INTERSTITIAL_CLOSED_NOTIFICATION;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.ConsoleMessage;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialActivity;
import com.gamehouse.crosspromotion.implementation.gpn.properties.ConnectionTypeProperty;
import com.gamehouse.crosspromotion.implementation.gpn.properties.ForegroundStateProperty;
import com.gamehouse.crosspromotion.implementation.gpn.properties.PresentParamsProperty;
import com.gamehouse.crosspromotion.implementation.gpn.properties.ScreenSizeProperty;
import com.gamehouse.crosspromotion.implementation.gpn.properties.StateProperty;
import com.gamehouse.crosspromotion.implementation.utils.Connectivity;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.DisplayUtils;
import com.gamehouse.crosspromotion.implementation.utils.Log;
import com.gamehouse.crosspromotion.implementation.utils.StringUtils;
import com.gamehouse.crosspromotion.implementation.utils.observing.NotificationService;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class HtmlAdView extends WebView
{
    private static final String GPN_URL_SCHEME = "gpn";
    private static final String GPN_COMMAND_ID = "id";

    private static final String[] WEB_PAGE_URLS = { "http", "https" };

    private WebViewClient webViewClient;
    private WebChromeClient webChromeClient;

    private HtmlAdViewListener listener;

    private boolean mHasFiredReadyEvent;

    private int modalViewCount;

    public HtmlAdView(Context context)
    {
        super(context);
        initialize(context);
    }

    private HtmlAdView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    private HtmlAdView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }

    private void initialize(Context context)
    {
        setScrollContainer(false);
        setBackgroundColor(Color.TRANSPARENT);

        setVerticalScrollBarEnabled(false);
        setHorizontalScrollBarEnabled(false);

        setOnTouchListener(new View.OnTouchListener()
        {
            public boolean onTouch(View v, MotionEvent event)
            {
                switch (event.getAction())
                {
                case MotionEvent.ACTION_DOWN:
                case MotionEvent.ACTION_UP:
                    if (!v.hasFocus())
                    {
                        v.requestFocus();
                    }
                    break;
                }
                return false;
            }
        });

        initializeSettings(getSettings());

        webViewClient = new HtmlAdWebViewClient();
        setWebViewClient(webViewClient);

        webChromeClient = new HtmlAdWebChromeClient();
        setWebChromeClient(webChromeClient);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initializeSettings(WebSettings settings)
    {
        settings.setJavaScriptEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDatabaseEnabled(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setDomStorageEnabled(true);
        settings.setDatabasePath(createDatabasePath(getContext()));
    }

    private String createDatabasePath(Context context)
    {
        return context.getFilesDir().getPath() + "/databases";
    }

    public void destroy()
    {
        try
        {
            super.destroy();
        }
        catch (Throwable e)
        {
            Log.logException(e, "Exception on ad view destory");
        }
    }

    ////////////////////////////////////////////////////////////////
    // Loading

    public void loadUrl(String url)
    {
        super.loadUrl(url);
    }

    @Override
    public void stopLoading()
    {
        try
        {
            super.stopLoading();
        }
        catch (Throwable e)
        {
            Log.logException(e, "Exception on ad view stop loading");
        }
    }

    ////////////////////////////////////////////////////////////////
    // JavaScript

    public void executeJavascript(String javascript)
    {
        Debug.assertion(javascript != null, "Javascript is null");
        if (javascript != null)
        {
            super.loadUrl("javascript:" + javascript);
        }
    }

    ////////////////////////////////////////////////////////////////
    // JavaScript communication API

    protected void initializeJavaScriptState()
    {
        Point ds = DisplayUtils.getDisplaySize(getContext());

        ArrayList<JavaScriptProperty> properties = new ArrayList<JavaScriptProperty>();
        properties.add(new ScreenSizeProperty(ds.x, ds.y));
        properties.add(new StateProperty(HtmlAdViewState.Hidden));

        fireChangeEventForProperties(properties);
    }

    protected void fireChangeEventForProperty(JavaScriptProperty property)
    {
        String json = "{" + property.toString() + "}";
        executeJavascript("window.gpnbridge.fireChangeEvent(" + json + ");");
        Log.d(JAVASCRIPT, "Fire change: " + json);
    }

    protected void fireChangeEventForProperties(List<JavaScriptProperty> properties)
    {
        String props = properties.toString();
        if (props.length() < 2)
            return;

        String json = "{" + props.substring(1, props.length() - 1) + "}";
        executeJavascript("window.gpnbridge.fireChangeEvent(" + json + ");");
        Log.d(JAVASCRIPT, "Fire changes: " + json);
    }

    protected void fireErrorEvent(String action, String message)
    {
        executeJavascript("window.gpnbridge.fireErrorEvent('" + action + "', '" + message + "');");
    }

    protected void fireReadyEvent()
    {
        executeJavascript("window.gpnbridge.fireReadyEvent();");
    }

    public void firePresentingState()
    {
        fireChangeEventForProperty(new StateProperty(HtmlAdViewState.Presenting)); // TODO: refactor this
    }

    protected void fireNativeCommandCompleteEvent(JavaScriptCommand command)
    {
        executeJavascript("window.gpnbridge.nativeCallComplete('" + command.getId() + "');");
    }

    protected void fireNativeCommandFailedEvent(JavaScriptCommand command)
    {
        fireNativeCommandFailedEvent(command != null ? command.getId() : null);
    }

    protected void fireNativeCommandFailedEvent(String commandId)
    {
        String param = commandId != null ? "'" + commandId + "'" : null;
        executeJavascript("window.gpnbridge.nativeCallFailed(" + param + ");"); // TODO: add command's parameters
    }

    protected void fireNativeCommandCancelledEvent(JavaScriptCommand command)
    {
        executeJavascript("window.gpnbridge.nativeCallCancelled('" + command.getId() + "');");
    }

    ////////////////////////////////////////////////////////////////
    // Commands

    protected boolean tryURLStringAsCommand(String urlString) throws JavaScriptCommandException
    {
        try
        {
            return tryProcessCommand(urlString);
        }
        catch (Throwable e)
        {
            Log.logException(e, "Unable to process url string as a command: %s", urlString);

            String commandId = null; // TODO: figure out the command id
            fireNativeCommandFailedEvent(commandId);

            throw new JavaScriptCommandException(e);
        }
    }

    public boolean tryOpenWithExternalActivity(String url)
    {
        try
        {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(intent);
            return true;
        }
        catch (Throwable e)
        {
            Log.logException(e, "Unable to open external activity: " + url);
        }

        return false;
    }

    private boolean tryProcessCommand(String urlString)
    {
        URI uri = URI.create(urlString);

        String commandType = uri.getHost();
        List<NameValuePair> list = URLEncodedUtils.parse(uri, "UTF-8");
        Map<String, String> params = new HashMap<String, String>(list.size());
        for (NameValuePair p : list)
        {
            params.put(p.getName(), p.getValue());
        }

        return tryProcessCommand(commandType, params);
    }

    private boolean tryProcessCommand(String commandName, Map<String, String> parameters)
    {
        String commandId = parameters.get(GPN_COMMAND_ID);
        if (commandId == null)
        {
            Log.w(COMMANDS, "Missing command id:'%s' params:%s", commandName, parameters);
            fireNativeCommandFailedEvent(commandId);
            return false;
        }

        JavaScriptCommand cmd = JavaScriptCommandRegistry.createCommand(commandName);
        if (cmd == null)
        {
            Log.w(COMMANDS, "Unknown command:'%s' params:%s", commandName, parameters);
            fireNativeCommandFailedEvent(commandId);
            return false;
        }

        cmd.setId(commandId);
        cmd.setParams(parameters);
        cmd.setView(this);

        try
        {
            Log.d(COMMANDS, "Executing command: name=%s id=%s params=%s", commandName, commandId, parameters);

            cmd.execute();
            fireNativeCommandCompleteEvent(cmd);

            return true;
        }
        catch (Throwable e)
        {
            fireNativeCommandFailedEvent(cmd);
        }

        return false;
    }

    ////////////////////////////////////////////////////////////////
    // Heart beat

    public void onHeartBeat()
    {
        notifyHeartBeat();
    }

    ////////////////////////////////////////////////////////////////
    // Presented event

    public void onPresented()
    {
        notifyPresented();
    }

    ////////////////////////////////////////////////////////////////
    // Debug events

    public void onDebugEvent(String name, Map<String, Object> params)
    {
        notifyDebugEvent(name, params);
    }

    ////////////////////////////////////////////////////////////////
    // Listener notifications

    public void notifyViewLoad()
    {
        if (listener != null)
        {
            listener.onAdViewLoad(this);
        }
    }

    public void notifyViewException(String description, String failingUrl)
    {
        notifyViewFail(ERROR_EXCEPTION_THROWN, description, failingUrl);
    }

    public void notifyViewFail(int errorCode, String description, String failingUrl)
    {
        if (listener != null)
        {
            listener.onAdViewFail(this, errorCode, description, failingUrl);
        }
    }

    public void notifyModalViewShow()
    {
        if (listener != null)
        {
            listener.onModalViewShow(this);
        }
    }

    public void notifyModalViewHide()
    {
        if (listener != null)
        {
            listener.onModalViewHide(this);
        }
    }

    public void notifyApplicationLeave()
    {
        if (listener != null)
        {
            listener.onApplicationWillLeave(this);
        }
    }

    private void notifyHeartBeat()
    {
        if (listener != null)
        {
            listener.onHeartBeat(this);
        }
    }

    private void notifyPresented()
    {
        if (listener != null)
        {
            listener.onPresented(this);
        }
    }

    private void notifyDebugEvent(String name, Map<String, Object> params)
    {
        if (listener != null)
        {
            listener.onDebugEvent(this, name, params);
        }
    }

    ////////////////////////////////////////////////////////////////
    // Controllers

    private void onPresentModalView()
    {
        modalViewCount++;
        if (modalViewCount == 1)
        {
            notifyModalViewShow();
        }
    }

    private void onDismissModalView()
    {
        modalViewCount--;
        Debug.assertion(modalViewCount >= 0, "Modal view count cannot be negative.");
        if (modalViewCount == 0)
        {
            notifyModalViewHide();
        }
    }

    public void present(Context context, Map<String, Object> params)
    {
        if (params != null)
        {
            fireChangeEventForProperty(new PresentParamsProperty(params));
        }

        present(context);
        onPresentModalView();
    }

    protected void present(Context context)
    {
        Intent intent = new Intent(context, InterstitialActivity.class);
        if (!(context instanceof Activity))
        {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(intent);

        fireChangeEventForProperty(new StateProperty(HtmlAdViewState.Presented));
    }

    public void close()
    {
        fireChangeEventForProperty(new StateProperty(HtmlAdViewState.Hidden));
        NotificationService.instance().postNotification(INTERSTITIAL_CLOSED_NOTIFICATION, this);

        onDismissModalView();
    }

    public void onBackPressed()
    {
        executeJavascript("window.gpnbridge.fireEvent('back', 'pressed');");
        close();
    }

    public void onConnectivityChanged(Connectivity connectivity)
    {
        fireChangeEventForProperty(new ConnectionTypeProperty(connectivity.getConnectionTypeName()));
    }

    public void onForegroundStateChanged(boolean flag)
    {
        fireChangeEventForProperty(new ForegroundStateProperty(flag));
    }

    ////////////////////////////////////////////////////////////////
    // Getters/Setters

    public HtmlAdViewListener getListener()
    {
        return listener;
    }

    public void setListener(HtmlAdViewListener listener)
    {
        this.listener = listener;
    }

    protected WebViewClient getWebViewClient()
    {
        return webViewClient;
    }

    protected WebChromeClient getWebChromeClient()
    {
        return webChromeClient;
    }

    private boolean isWebPageScheme(String scheme)
    {
        if (scheme == null)
        {
            throw new NullPointerException("scheme is null");
        }

        for (int i = 0; i < WEB_PAGE_URLS.length; ++i)
        {
            if (WEB_PAGE_URLS[i].equalsIgnoreCase(scheme))
            {
                return true;
            }
        }

        return false;
    }

    ////////////////////////////////////////////////////////////////
    // Internal classes

    private class HtmlAdWebChromeClient extends WebChromeClient
    {
        @Override
        public boolean onJsAlert(WebView view, String url, String message, JsResult result)
        {
            Log.d(JAVASCRIPT, message);
            return false;
        }

        @Override
        public boolean onConsoleMessage(ConsoleMessage consoleMessage)
        {
            String message = consoleMessage(consoleMessage.message(), consoleMessage.lineNumber(), consoleMessage.sourceId());
            switch (consoleMessage.messageLevel())
            {
            case WARNING:
            {
                Log.w(JAVASCRIPT, message);
                break;
            }
            case ERROR:
            {
                Log.e(JAVASCRIPT, message);
                break;
            }
            case DEBUG:
            case TIP:
            case LOG:
            {
                Log.d(JAVASCRIPT, message);
                break;
            }
            }
            return true;
        }

        @Override
        public void onConsoleMessage(String message, int lineNumber, String sourceId)
        {
            Log.d(JAVASCRIPT, consoleMessage(message, lineNumber, sourceId));
        }

        private String consoleMessage(String message, int lineNumber, String sourceId)
        {
            String encodedMessage = StringUtils.decodeURLString(message);
            if (sourceId != null)
            {
                return StringUtils.tryFormatString("javascript %s:%d: %s", sourceId, lineNumber, encodedMessage);
            }
            return StringUtils.tryFormatString("javascript %d: %s", lineNumber, encodedMessage);
        }
    }

    private class HtmlAdWebViewClient extends WebViewClient
    {
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
        {
            Log.e(JAVASCRIPT, "Error loading web view: code=%d description=%s failingUrl=%s", errorCode, description, failingUrl);
            notifyViewFail(errorCode, description, failingUrl);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url)
        {
            try
            {
                Log.i(NETWORK, "Load URL: %s", url);

                Uri uri = Uri.parse(url);
                String scheme = uri.getScheme();

                if (GPN_URL_SCHEME.equals(scheme))
                {
                    tryURLStringAsCommand(url);
                    return true;
                }

                if (isWebPageScheme(scheme))
                {
                    return false;
                }

                if (tryOpenWithExternalActivity(url))
                {
                    notifyApplicationLeave();
                    return true;
                }

                return false;
            }
            catch (Throwable e)
            {
                Log.logException(e, "Error while handling web view request");

                String description = StringUtils.tryFormatString("Error while processing url request: url=%s message=%s", url, e.getMessage());
                notifyViewException(description, url);

                return false;
            }
        }

        @Override
        public void onPageFinished(WebView view, String url)
        {
            try
            {
                if (!mHasFiredReadyEvent)
                {
                    initializeJavaScriptState();
                    fireReadyEvent();
                    mHasFiredReadyEvent = true;
                }
            }
            catch (Throwable e)
            {
                Log.logException(e, "Error while handling page loading finish");

                String description = StringUtils.tryFormatString("Error on loading finish: %s", e.getMessage());
                notifyViewException(description, url);
            }
        }

        @Override
        public void onLoadResource(WebView view, String url)
        {
            Log.i(JAVASCRIPT, "Loaded resource: " + url);
        }
    }
}
