//
//  DebugMonitor.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.debug;

import java.util.Map;

import android.os.Looper;
import android.util.Log;

import com.gamehouse.crosspromotion.debug.chunks.EventChunk;
import com.gamehouse.crosspromotion.debug.chunks.LogChunk;
import com.gamehouse.crosspromotion.debug.chunks.RequestChunk;
import com.gamehouse.crosspromotion.debug.chunks.TimerChunk;
import com.gamehouse.crosspromotion.debug.utils.ObjectsPool;
import com.gamehouse.crosspromotion.implementation.network.HttpRequest;
import com.gamehouse.crosspromotion.implementation.network.RequestManager;
import com.gamehouse.crosspromotion.implementation.network.RequestManagerListener;
import com.gamehouse.crosspromotion.implementation.utils.timers.Timer;
import com.gamehouse.crosspromotion.implementation.utils.timers.TimerManager;
import com.gamehouse.crosspromotion.implementation.utils.timers.TimerSampler;
import com.gamehouse.crosspromotion.implementation.utils.timers.TimerSamplerListener;

public class DebugMonitor implements AsyncChunkSocketListener
{
	private static final String TAG = "RM";
	
	private AsyncChunkSocket socket;
	
	private ObjectsPool<LogChunk> logChunks;
	private ObjectsPool<EventChunk> eventChunks;
	private ObjectsPool<RequestChunk> requestChunks;
	
	private TimerSampler timerSampler;
	
	public DebugMonitor()
	{	
		logChunks = new ObjectsPool<LogChunk>(LogChunk.class);
		eventChunks = new ObjectsPool<EventChunk>(EventChunk.class);
		requestChunks = new ObjectsPool<RequestChunk>(RequestChunk.class);
	}
	
	public void start(String host, int port)
	{
		if (socket != null)
		{
			Log.w(TAG, "Remote monitor already started");
		}
		
		socket = new AsyncChunkSocket(this, Looper.getMainLooper());
		boolean succeed = socket.connect(host, port);
		if (!succeed)
		{
			Log.w(TAG, "Remote monitor not started");
		}
	}

	public void stop()
	{
		if (socket != null)
		{
			socket.disconnect();
			socket = null;
		}
	}
	
	public boolean isConnected()
	{
		return socket != null && socket.isConnected();
	}
	
	////////////////////////////////////////////////////////////////
	// Timers
	
	public void onTimerManagerCreated(TimerManager manager)
	{
		stopSampler();
		
		timerSampler = new TimerSampler(manager, 500);
		timerSampler.setListener(new TimerSamplerListener()
        {
		    private ObjectsPool<TimerChunk> timerChunks = new ObjectsPool<TimerChunk>(TimerChunk.class);
		    
		    @Override
            public void onTimerSuspended(TimerSampler timerSampler, Timer timer)
            {
                send(timerChunks.get().initSuspend(timer));
            }
            
            @Override
            public void onTimerScheduled(TimerSampler timerSampler, Timer timer)
            {
                send(timerChunks.get().initSchedule(timer));
            }
            
            @Override
            public void onTimerSampled(TimerSampler timerSampler, Timer timer)
            {
                send(timerChunks.get().initSample(timer));
            }
            
            @Override
            public void onTimerResumed(TimerSampler timerSampler, Timer timer)
            {
                send(timerChunks.get().initResume(timer));
            }
            
            @Override
            public void onTimerFired(TimerSampler timerSampler, Timer timer)
            {
                send(timerChunks.get().initFire(timer));
            }
            
            @Override
            public void onTimerFinished(TimerSampler timerSampler, Timer timer)
            {
                send(timerChunks.get().initFinish(timer));
            }
            
            @Override
            public void onTimerCancelled(TimerSampler timerSampler, Timer timer)
            {
                send(timerChunks.get().initCancel(timer));
            }
        });
		timerSampler.start();
	}
	
	public void onTimerManagerDestroyed(TimerManager manager)
	{
		stopSampler();
	}
	
	private void stopSampler()
	{
		if (timerSampler != null)
		{
			timerSampler.stop();
			timerSampler = null;
		}
	}
	
	////////////////////////////////////////////////////////////////
    // Requests
	
	public void onRequestManagerCreated(RequestManager manager)
	{
	    manager.setListener(new RequestManagerListener()
        {
            @Override
            public void onRequestQueued(RequestManager manager, HttpRequest request)
            {
                send(requestChunks.get().initQueued(request));
            }
            
            @Override
            public void onRequestFinished(RequestManager manager, HttpRequest request)
            {
                send(requestChunks.get().initFinished(request));
            }
            
            @Override
            public void onRequestFailed(RequestManager manager, HttpRequest request)
            {
                send(requestChunks.get().initFailed(request, request.getThrownException()));
            }
            
            @Override
            public void onRequestCancelled(RequestManager manager, HttpRequest request)
            {
                send(requestChunks.get().initCancelled(request));
            }
            
            @Override
            public void onAllRequestsCancelled(RequestManager manager)
            {
                // TODO
            }
        });
	}
	
	public void onRequestManagerDestroyed(RequestManager manager)
	{
	    manager.setListener(null);
	}
	
	////////////////////////////////////////////////////////////////
	// Chunks
	
	public void sendLog(int priority, String thread, String message)
	{
		send(logChunks.get().init(priority, thread, message));
	}
	
	public void sendEvent(String name, Map<String, Object> params)
	{
	    send(eventChunks.get().init(name, params));
	}
	
	////////////////////////////////////////////////////////////////
	// Chunk
	
	private void send(Chunk chunk)
	{
		socket.send(chunk);
	}
	
	////////////////////////////////////////////////////////////////
	// AsyncChunkSocketListener

	@Override
	public void onConnectedToHost()
	{
	}

	@Override
	public void onNotConnectedToHost(String message)
	{
	}

	@Override
	public void onChunkReceive(Chunk chunk)
	{
	}

	@Override
	public void onChunkSend(Chunk chunk)
	{
	}

	@Override
	public void onChunkFail(String name, int size)
	{
	}

	@Override
	public void onDisconnectedFromHost()
	{
	}
}
