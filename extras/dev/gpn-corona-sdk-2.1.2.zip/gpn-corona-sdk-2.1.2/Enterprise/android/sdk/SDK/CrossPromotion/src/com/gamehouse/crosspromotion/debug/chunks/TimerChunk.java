//
//  TimerChunk.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.debug.chunks;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.gamehouse.crosspromotion.debug.IDChunk;
import com.gamehouse.crosspromotion.implementation.utils.timers.Timer;

public class TimerChunk extends IDChunk
{
	public enum Type
	{
		None, Schedule, Suspend, Resume, Fire, Finish, Cancel, Sample;
	}
	
	private Type type;
	
	private String timerName;
	private long delay;
	private long remaining;
	private boolean ticksWhenSuspended;
	
	public TimerChunk()
	{
		super("tmer");
	}
	
	public TimerChunk initSchedule(Timer timer)
	{
		return init(Type.Schedule, timer);
	}
	
	public TimerChunk initSuspend(Timer timer)
	{
		return init(Type.Suspend, timer);
	}
	
	public TimerChunk initResume(Timer timer)
	{
		return init(Type.Resume, timer);
	}
	
	public TimerChunk initFire(Timer timer)
	{
		return init(Type.Fire, timer);
	}
	
	public TimerChunk initFinish(Timer timer)
	{
		return init(Type.Finish, timer);
	}
	
	public TimerChunk initCancel(Timer timer)
	{
		return init(Type.Cancel, timer);
	}
	
	public TimerChunk initSample(Timer timer)
	{
		return init(Type.Sample, timer);
	}
	
	private TimerChunk init(Type type, Timer timer)
	{
		super.init(timer.getId());
		this.type = type;
		this.timerName = timer.getName();
		this.delay = timer.getDelayMillis();
		this.remaining = timer.getRemainingMillis();
		this.ticksWhenSuspended = timer.isTicksWhenSuspended();
		
		return this;
	}
	
	@Override
	protected void onRecycle()
	{
		super.onRecycle();
		
		type = Type.None;
		timerName = null;
		delay = remaining = 0;
		ticksWhenSuspended = false;
	}
	
	@Override
	public void write(DataOutput output) throws IOException
	{
		super.write(output);
		
		writeUTF(output, type);
		
		Serialization serialization = findSerialization(type);
		serialization.write(output, this);
	}

	@Override
	public void read(DataInput input) throws IOException
	{
		super.read(input);
		
		String typeName = readUTF(input);
		Type type = Type.valueOf(typeName);
		
		this.type = type;
		Serialization serialization = findSerialization(type);
		serialization.read(input, this);
	}
	
	public Type getType()
	{
		return type;
	}
	
	public String getTimerName()
	{
		return timerName;
	}
	
	public float getDelay()
	{
		return delay;
	}
	
	public float getRemaining()
	{
		return remaining;
	}
	
	public boolean isTicksWhenSuspended()
	{
		return ticksWhenSuspended;
	}
	
	////////////////////////////////////////////////////////////////
	// Serialization
	
	private static Map<Type, Serialization> serializationLookup;
	
	static
	{
		serializationLookup = new HashMap<Type, Serialization>();
		
		// schedule
		serializationLookup.put(Type.Schedule, new Serialization()
		{
			@Override
			public void write(DataOutput output, TimerChunk chunk) throws IOException
			{
				writeUTF(output, chunk.timerName);
				output.writeInt((int) chunk.delay);
			}

			@Override
			public void read(DataInput input, TimerChunk chunk) throws IOException
			{
				chunk.timerName = readUTF(input);
				chunk.delay = input.readInt();
			}
		});

		// suspend
		serializationLookup.put(Type.Suspend, new Serialization()
		{
			@Override
			public void write(DataOutput output, TimerChunk chunk) throws IOException
			{
				output.writeInt((int) chunk.remaining);
				output.writeBoolean(chunk.ticksWhenSuspended);
			}
			
			@Override
			public void read(DataInput input, TimerChunk chunk) throws IOException
			{
				chunk.remaining = input.readInt();
				chunk.ticksWhenSuspended = input.readBoolean();
			}
		});
		
		// resume
		serializationLookup.put(Type.Resume, new Serialization()
		{
			@Override
			public void write(DataOutput output, TimerChunk chunk) throws IOException
			{
				output.writeInt((int) chunk.remaining);
			}
			
			@Override
			public void read(DataInput input, TimerChunk chunk) throws IOException
			{
				chunk.remaining = input.readInt();
			}
		});
		
		// fire
		serializationLookup.put(Type.Fire, new Serialization()
		{
			@Override
			public void write(DataOutput output, TimerChunk chunk) throws IOException
			{
			}
			
			@Override
			public void read(DataInput input, TimerChunk chunk) throws IOException
			{
			}
		});
		
		// finish
		serializationLookup.put(Type.Finish, new Serialization()
		{
			@Override
			public void write(DataOutput output, TimerChunk chunk) throws IOException
			{
			}
			
			@Override
			public void read(DataInput input, TimerChunk chunk) throws IOException
			{
			}
		});
		
		// cancel
		serializationLookup.put(Type.Cancel, new Serialization()
		{
			@Override
			public void write(DataOutput output, TimerChunk chunk) throws IOException
			{
				output.writeInt((int) chunk.remaining);
			}
			
			@Override
			public void read(DataInput input, TimerChunk chunk) throws IOException
			{
				chunk.remaining = input.readInt();
			}
		});

		// sample
		serializationLookup.put(Type.Sample, new Serialization()
		{
			@Override
			public void write(DataOutput output, TimerChunk chunk) throws IOException
			{
				output.writeInt((int) chunk.remaining);
			}
			
			@Override
			public void read(DataInput input, TimerChunk chunk) throws IOException
			{
				chunk.remaining = input.readInt();
			}
		});
	}
	
	private static Serialization findSerialization(Type type)
	{
		Serialization serialization = serializationLookup.get(type);
		if (serialization == null)
		{
			throw new IllegalArgumentException("Can't find serialization for type: " + type);
		}
		
		return serialization;
	}
	
	private static abstract class Serialization
	{
		public abstract void write(DataOutput output, TimerChunk chunk) throws IOException;
		public abstract void read(DataInput input, TimerChunk chunk) throws IOException;
	}
}
