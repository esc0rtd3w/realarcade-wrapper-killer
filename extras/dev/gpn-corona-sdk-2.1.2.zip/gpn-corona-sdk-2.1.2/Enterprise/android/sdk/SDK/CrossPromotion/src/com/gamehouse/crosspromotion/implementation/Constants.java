//
//  Constants.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation;

public class Constants
{
    public static final String SDK_VERSION                          = "2.2.3";

    public static final String SERVER_DEFAULT_URL                   = "http://gpn-api.gamehouse.com";

    public static final String REQUEST_PARAM_SDK_VERSION            = "sdk_version";

    public static final String REQUEST_PARAM_APP_ID                 = "app_id[gpn]";
    public static final String REQUEST_PARAM_PACKAGE_NAME           = "app_id[package_name]";
    public static final String REQUEST_PARAM_VERSION_CODE           = "app[version_code]";
    public static final String REQUEST_PARAM_VERSION_NAME           = "app[version_name]";

    public static final String REQUEST_PARAM_MAC_ID                 = "device_id[mac_id]";
    public static final String REQUEST_PARAM_ANDROID_ID             = "device_id[android_id]";
    public static final String REQUEST_PARAM_GOOGLE_ID              = "device_id[google_aid]";
    public static final String REQUEST_PARAM_GOOGLE_ID_TRACK        = "device_id[google_aid_track]";

    public static final String REQUEST_PARAM_FREE_MEMORY            = "system[free_memory]";
    public static final String REQUEST_PARAM_FREE_HEAP_MEMORY       = "system[free_heap_memory]";
    public static final String REQUEST_PARAM_HEAP_MEMORY            = "system[heap_memory]";
    public static final String REQUEST_PARAM_MAX_MEMORY             = "system[max_memory]";

    public static final String REQUEST_PARAM_SCREEN_WIDTH           = "screen_size[width]";
    public static final String REQUEST_PARAM_SCREEN_HEIGHT          = "screen_size[height]";
    
    public static final String REQUEST_PARAM_WRAPPER_NAME           = "wrapper[name]";
    public static final String REQUEST_PARAM_WRAPPER_VERSION        = "wrapper[version]";

    public static final String REQUEST_PARAM_CONNECTION_TYPE        = "connection_type";
    public static final String REQUEST_PARAM_CONNECTION_SUBTYPE     = "connection_subtype";

    public static final String REQUEST_PARAM_CARRIER                = "carrier";

    public static final String REQUEST_PARAM_COUNTRY                = "country";

    public static final String REQUEST_PARAM_DEBUG                  = "debug_mode";

    public static final String TIMER_HEARTBEAT                      = "heartbeat";
    public static final String TIMER_LOADING                        = "loading";
    public static final String TIMER_PRESENTING                     = "presenting";
    
    public static final String PREFS_NAMES                          = "com.gamehouse.crosspromotion.Preferences";
}
