//
//  JSON.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils.json;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONObject;

import com.gamehouse.crosspromotion.implementation.utils.Debug;

public class JSON
{
    private JSONObject jsonObject;

    public static JSON parse(String jsonString) throws JSONException
    {
        try
        {
            JSONObject jsonObj = new JSONObject(jsonString);
            return new JSON(jsonObj);
        }
        catch (Exception e)
        {
            throw new JSONException(e);
        }
    }

    public JSON(JSONObject jsonObject)
    {
        if (jsonObject == null)
        {
            throw new IllegalArgumentException("JSONObject is null");
        }

        this.jsonObject = jsonObject;
    }

    private Object objectForKey(String name)
    {
        try
        {
            return jsonObject.get(name);
        }
        catch (Exception e)
        {
        }

        return null;
    }

    public String stringForKey(String name) throws JSONException
    {
        try
        {
            return jsonObject.getString(name);
        }
        catch (Exception e)
        {
            throw new JSONException(e);
        }
    }

    public String stringForKey(String name, String defaultValue)
    {
        try
        {
            return stringForKey(name);
        }
        catch (Exception e)
        {
        }

        return defaultValue;
    }

    public String notEmptyStringForKey(String key) throws JSONException
    {
        String str = stringForKey(key);
        if (str.length() == 0)
        {
            throw new JSONException("String is empty: " + key);
        }
        
        return str;
    }

    public String notEmptyStringForKey(String key, String defaultValue)
    {
        try
        {
            String str = stringForKey(key);
			return str != null && str.length() > 0 ? str : null;
        }
        catch (Exception e)
        {
        }
        
        return defaultValue;
    }

    public int intForKey(String name) throws JSONException
    {
        try
        {
            return jsonObject.getInt(name);
        }
        catch (Exception e)
        {
            throw new JSONException(e);
        }
    }

    public int intForKey(String name, int defaultValue)
    {
        try
        {
            return intForKey(name);
        }
        catch (Exception e)
        {
        }

        return defaultValue;
    }

    public double doubleForKey(String name) throws JSONException
    {
        try
        {
            return jsonObject.getDouble(name);
        }
        catch (Exception e)
        {
            throw new JSONException(e);
        }
    }

    public double doubleForKey(String name, double defaultValue)
    {
        try
        {
            return doubleForKey(name);
        }
        catch (Exception e)
        {
        }

        return defaultValue;
    }

    public float floatForKey(String name) throws JSONException
    {
        return (float) doubleForKey(name);
    }

    public float floatForKey(String name, float defaultValue)
    {
        return (float) doubleForKey(name, defaultValue);
    }

    public boolean boolForKey(String name) throws JSONException
    {
        try
        {
            return jsonObject.getBoolean(name);
        }
        catch (Exception e)
        {
            throw new JSONException(e);
        }
    }

    public boolean boolForKey(String name, boolean defaultValue)
    {
        try
        {
            return boolForKey(name);
        }
        catch (Exception e)
        {
        }

        return defaultValue;
    }

    public URL URLForKey(String name) throws MalformedURLException, JSONException
    {
        String urlString = notEmptyStringForKey(name);
        return new URL(urlString);
    }

    public JSON jsonForKey(String name)
    {
        try
        {
            return new JSON(jsonObject.getJSONObject(name));
        }
        catch (Exception e)
        {
            
        }

        return null;
    }

    // TODO: add unit tests
    public JSONArray arrayForKey(String name)
    {
        try
        {
            return new JSONArray(jsonObject.getJSONArray(name));
        }
        catch (Exception e)
        {
        }
        return null;
    }

    public String[] stringArrayForKey(String name)
    {
        JSONArray array = arrayForKey(name);
        if (array != null)
        {
            int length = array.length();
            String[] result = new String[length];
            for (int i = 0; i < length; ++i)
            {
                String string = array.getString(i);
                if (string == null)
                {
                    return null;
                }

                result[i] = string;
            }

            return result;
        }

        return null;
    }

    public boolean contains(String... names)
    {
        Debug.assertion(names != null, "names supposed to be not null");

        if (names != null)
        {
            for (String name : names)
            {
                Debug.assertion(name != null, "null entry in the names array: " + Arrays.toString(names));

                if (name == null || !jsonObject.has(name))
                {
                    return false;
                }
            }
        }

        return true;
    }

    @Override
    public String toString()
    {
        return jsonObject.toString();
    }

    public Map<String, Object> toMap()
    {
        Map<String, Object> map = new HashMap<String, Object>();

        @SuppressWarnings("unchecked")
        Iterator<String> keys = jsonObject.keys();

        while (keys.hasNext())
        {
            String key = keys.next();
            if (key == null)
            {
                continue;
            }

            Object value = objectForKey(key);
            if (value == null)
            {
                continue;
            }

            map.put(key, value);
        }

        return map;
    }
}
