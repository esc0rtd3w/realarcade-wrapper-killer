//
//  RequestAsyncTask.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.network;

import android.os.AsyncTask;
import android.os.AsyncTask.Status;

import com.gamehouse.crosspromotion.implementation.utils.Debug;

public abstract class RequestAsyncTask {
	private AsyncTask<Void, Void, Void> task;

	public RequestAsyncTask() {
		task = createTask();
	}

	/** Called on a worker thread to perform some task */
	protected abstract void doOnSecondaryThread();

	/** Called on the main thread when started */
	protected abstract void onStart();

	/** Called on the main thread when finished */
	protected abstract void onFinish();

	/** Called on the main thread when canceled */
	protected abstract void onCancel();

	private AsyncTask<Void, Void, Void> createTask() {
		return new AsyncTask<Void, Void, Void>() {

			@Override
			protected Void doInBackground(Void... params) {
				try {
					if (!isCancelled()) {
						doOnSecondaryThread();
					}
				} catch (Exception e) {
					Debug.fail("Exception occured while running background task\n"
							+ e);
				}

				return null; // dummy return value
			}

			@Override
			protected void onPreExecute() {
				try {
					if (!isCancelled()) {
						onStart();
					}
				} catch (Exception e) {
					Debug.fail("Exception occured while starting async task\n"
							+ e);
				}
			}

			@Override
			protected void onPostExecute(Void result) {
				try {
					if (!isCancelled()) {
						onFinish();
					} else {
						onCancel();
					}
				} catch (Exception e) {
					Debug.fail("Exception occured while running async task post execute\n"
							+ e);
				}
			}

			@Override
			protected void onCancelled() {
				try {
					onCancel();
				} catch (Exception e) {
					Debug.fail("Exception occured while cancelling async task\n"
							+ e);
				}
			}
		};
	}

	public void execute() {
		task.execute();
	}

	public void cancel() {
		task.cancel(true);
	}

	public boolean isCancelled() {
		return task.isCancelled();
	}
	
	public boolean isRunning() {
		return !isCancelled() && (task.getStatus() == Status.PENDING || task.getStatus() == Status.RUNNING);
	}
}
