//
//  ServiceUtils.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;
import android.view.WindowManager;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class ServiceUtils
{
	public static ActivityManager getActivityManager(Context context)
	{
		return getSystemService(context, Context.ACTIVITY_SERVICE, ActivityManager.class);
	}
	
	public static WindowManager getWindowManager(Context context)
	{
		return getSystemService(context, Context.WINDOW_SERVICE, WindowManager.class);
	}

	public static ConnectivityManager getConnectivityManager(Context context)
	{
		return getSystemService(context, Context.CONNECTIVITY_SERVICE, ConnectivityManager.class);
	}
	
	public static WifiManager getWifiManager(Context context)
	{
		return getSystemService(context, Context.WIFI_SERVICE, WifiManager.class);
	}
	
	public static TelephonyManager getTelephonyManager(Context context)
	{
		return getSystemService(context, Context.TELEPHONY_SERVICE, TelephonyManager.class);
	}

	public static NetworkInfo getNetworkInfo(Context context)
	{
		ConnectivityManager cm = getConnectivityManager(context);
		if (cm != null)
		{
			try
			{
				return cm.getActiveNetworkInfo();
			}
			catch (SecurityException e)
			{
				Log.w(VERBOSE, "Unable to get network info.\nHave you included \"android.permission.ACCESS_NETWORK_STATE\" in your manifest?");
			}
			catch (Exception e)
			{
				Log.logException(e, "Unable to get network info");
			}
		}

		return null;
	}

	private static <T> T getSystemService(Context context, String name, Class<? extends T> clazz)
	{
		try
		{
			return ClassUtils.tryStrictCast(context.getSystemService(name), clazz);
		}
		catch (Exception e)
		{
			Log.logException(e, "Unable to get system service: %s", name);
		}

		return null;
	}
}
