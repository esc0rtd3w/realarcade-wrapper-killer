//
//  Connectivity.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import java.lang.ref.WeakReference;

import android.Manifest;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class Connectivity
{
	public enum ConnectionType
	{
		Unreachable("unreachable"), 
		WiFi("wi-fi"), 
		Carrier("carrier"), 
		Unknown("unknown");

		private String name;

		private ConnectionType(String name)
		{
			this.name = name;
		}

		public String getName()
		{
			return name;
		}

		@Override
		public String toString()
		{
			return name;
		}
	}
	
	private WeakReference<Context> contextRef;

	public Connectivity(Context context)
	{
		if (context == null)
		{
			throw new NullPointerException("context is null");
		}

		contextRef = new WeakReference<Context>(context.getApplicationContext());
	}

	////////////////////////////////////////////////////////////////
	// Connection types

	public static ConnectionType getConnectionType(Context context)
	{
		if (context == null)
		{
			throw new NullPointerException("context is null");
		}

		if (isGrantedAccessNetworkStatePermission(context))
		{
			NetworkInfo info = ServiceUtils.getNetworkInfo(context);
			if (info != null && info.isConnected())
			{
				return getConnectionType(info.getType());
			}

			return ConnectionType.Unreachable;
		}

		return ConnectionType.Unknown;
	}
	
	public static String getConnectionSubTypeName(Context context)
	{
		if (context == null)
		{
			throw new NullPointerException("context is null");
		}
		
		NetworkInfo info = ServiceUtils.getNetworkInfo(context);
		if (info != null && info.isConnected())
		{
			return info.getSubtypeName();
		}

		return null;
	}

	public boolean isConnected()
	{
		NetworkInfo info = getNetworkInfo();
		return info != null && info.isConnected();
	}

	public ConnectionType getConnectionType()
	{
		Context context = getContext();
		if (context != null)
		{
			return getConnectionType(context);
		}

		return ConnectionType.Unknown;
	}

	public String getConnectionTypeName()
	{
		return getConnectionType().getName();
	}

	public String getConnectionSubTypeName()
	{
		Context context = getContext();
		return context != null ? getConnectionSubTypeName(context) : null;
	}

	private static ConnectionType getConnectionType(int type)
	{
		if (type == ConnectivityManager.TYPE_WIFI)
		{
			return ConnectionType.WiFi;
		}
		else if (type == ConnectivityManager.TYPE_MOBILE)
		{
			return ConnectionType.Carrier;
		}

		return ConnectionType.Unknown;
	}


	////////////////////////////////////////////////////////////////
	// Helpers

	private NetworkInfo getNetworkInfo()
	{
		Context context = getContext();
		return context != null ? ServiceUtils.getNetworkInfo(context) : null;
	}

	private static boolean isGrantedAccessNetworkStatePermission(Context context)
	{
		return ManifestUtils.isGrantedPermissions(context, Manifest.permission.ACCESS_NETWORK_STATE);
	}

	private Context getContext()
	{
		return contextRef.get();
	}
}
