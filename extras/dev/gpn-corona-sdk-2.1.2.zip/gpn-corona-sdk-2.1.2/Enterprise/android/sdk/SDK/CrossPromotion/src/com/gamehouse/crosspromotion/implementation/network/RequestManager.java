//
//  RequestManager.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.network;

import java.util.ArrayList;
import java.util.List;

// TODO: think about keeping request manager as a part of another singleton object
public class RequestManager
{
	private List<HttpRequest> requests;
	private RequestManagerListener listener;
	private RequestManagerInjector injector;

	public RequestManager()
	{
		requests = new ArrayList<HttpRequest>();
	}
	
	public void destroy()
	{
	    cancelAll();
	}

	public void queueRequest(HttpRequest request)
	{
		requests.add(request);
		notifyQueued(request);
	}

	protected void removeRequest(HttpRequest request)
	{
		requests.remove(request);
		notifyRemoved(request);
	}

	public HttpRequest findRunningRequest(String name)
	{
		if (name == null)
		{
			throw new IllegalArgumentException("Request search name cannot be null");
		}

		for (HttpRequest request : requests)
		{
			if (name.equals(request.getName()) && request.isRunning())
			{
				return request;
			}
		}

		return null;
	}

	public void cancelAll()
	{
		if (requests.size() > 0)
		{
			List<HttpRequest> temp = new ArrayList<HttpRequest>(requests);
			for (HttpRequest request : temp)
			{
				request.cancel();
			}
			requests.clear();
			notifyCancelledAll();
		}
	}

	public RequestManagerListener getListener()
	{
		return listener;
	}
	
	public void setListener(RequestManagerListener listener)
	{
		this.listener = listener;
	}
	
	public RequestManagerInjector getInjector()
	{
		return injector;
	}
	
	public void setInjector(RequestManagerInjector injector)
	{
		this.injector = injector;
	}

	private void notifyQueued(HttpRequest request)
	{
		if (injector != null)
		{
			injector.onRequestQueued(this, request);
		}
		
		if (listener != null)
		{
			listener.onRequestQueued(this, request);
		}
	}

	private void notifyRemoved(HttpRequest request)
	{
		if (listener != null)
		{
			if (request.isCancelled())
			{
				listener.onRequestCancelled(this, request);
			}
			else if (request.isFailed())
			{
				listener.onRequestFailed(this, request);
			}
			else
			{
				listener.onRequestFinished(this, request);
			}
		}
	}

	private void notifyCancelledAll()
	{
		if (listener != null)
		{
			listener.onAllRequestsCancelled(this);
		}
	}
}
