//
//  InterstitialAdViewListener.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.ads.interstitial;

import java.util.Map;

public interface InterstitialAdViewListener
{
	/** Interstitial ad is received: it's safe to present it now. */
	void onInterstitialAdReceive(InterstitialAdView adView);

	/** Interstitial ad is failed to receive. */
	void onInterstitialAdFail(InterstitialAdView adView, int code, String reason);

	/** Interstitial ad presented full screen modal view. You can pause your game here. */
	void onInterstitialAdOpen(InterstitialAdView adView);

	/** Interstitial ad hided full screen modal view. You can resume your game here. */
	void onInterstitialAdClose(InterstitialAdView adView);
	
	/** Interstitial ad will leave the application. */
	void onInterstitialAdLeaveApplication(InterstitialAdView adView);

	/** Optional parameters to be passed with ad request. Return 'null' is you don't need any params. */
	Map<String, Object> createInterstitialAdParams();
}
