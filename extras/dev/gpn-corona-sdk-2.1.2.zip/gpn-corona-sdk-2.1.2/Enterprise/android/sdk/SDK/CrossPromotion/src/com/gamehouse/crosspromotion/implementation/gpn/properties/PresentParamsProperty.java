//
//  PresentParamsProperty.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.gpn.properties;

import java.util.Map;

import com.gamehouse.crosspromotion.implementation.gpn.JavaScriptProperty;
import com.gamehouse.crosspromotion.implementation.utils.JSONUtils;
import com.gamehouse.crosspromotion.implementation.utils.StringUtils;

public class PresentParamsProperty extends JavaScriptProperty
{
	private Map<String, Object> params;

	public PresentParamsProperty(Map<String, Object> params)
	{
		if (params == null)
		{
			throw new NullPointerException("params is null");
		}
		
		this.params = params;
	}
	
	@Override
	public String jsonString()
	{
		String jsonString = JSONUtils.toString(params);
		return StringUtils.tryFormatString("properties: %s", jsonString);
	}
}
