//
//  ObjectsPool.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.debug.utils;

import com.gamehouse.crosspromotion.implementation.utils.ClassUtils;
import com.gamehouse.crosspromotion.implementation.utils.Debug;

public class ObjectsPool<T extends ObjectsPoolEntry>
{
	private Class<? extends T> cls;
	private ObjectsPoolEntry freeRoot; // TODO: use soft reference
	private int size;

	public ObjectsPool(Class<? extends T> cls)
	{
		this.cls = cls;
	}

	public synchronized T get()
	{
		ObjectsPoolEntry e;
		if (freeRoot != null)
		{
			e = freeRoot;
			removeFromFreeList(e);
		}
		else
		{
			e = newInstance();
			if (e == null)
			{
				throw new IllegalStateException("Can't create an instance of " + cls);
			}
		}
		
		e.pool = this;
		return ClassUtils.tryStrictCast(e, cls);
	}
	
	public synchronized void add(T e)
	{
		recycle(e);
	}
	
	public synchronized void drain()
	{
		for (ObjectsPoolEntry e = freeRoot; e != null;)
		{
			ObjectsPoolEntry next = e.next;
			e.prev = e.next = null;
			e.pool = null;
			e = next;
		}
		freeRoot = null;
		size = 0;
	}
	
	synchronized void recycle(ObjectsPoolEntry e)
	{
		e.innerRecycle();
		addToFreeList(e);
	}
	
	private void addToFreeList(ObjectsPoolEntry e)
	{
		freeRoot = addToList(freeRoot, e);
		++size;
	}
	
	private void removeFromFreeList(ObjectsPoolEntry e)
	{
		Debug.assertion(size > 0);
		--size;
		freeRoot = removeFromList(freeRoot, e);
	}
	
	private ObjectsPoolEntry addToList(ObjectsPoolEntry root, ObjectsPoolEntry e)
	{
		if (root != null)
		{
			root.prev = e;
		}

		e.next = root;
		root = e;

		return root;
	}

	private ObjectsPoolEntry removeFromList(ObjectsPoolEntry root, ObjectsPoolEntry e)
	{
		ObjectsPoolEntry prev = e.prev;
		ObjectsPoolEntry next = e.next;

		if (prev != null)
			prev.next = next;
		else
			root = next;

		if (next != null)
			next.prev = prev;

		e.prev = e.next = null;
		return root;
	}
	
	protected T getRoot()
	{
		return ClassUtils.tryStrictCast(freeRoot, cls);
	}
	
	public int getSize()
	{
		return size;
	}
	
	private T newInstance()
	{
		return ClassUtils.tryNewInstance(cls);
	}
}
