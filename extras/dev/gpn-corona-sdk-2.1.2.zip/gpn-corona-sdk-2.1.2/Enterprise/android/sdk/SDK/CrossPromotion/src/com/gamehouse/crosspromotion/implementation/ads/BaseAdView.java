//
//  BaseAdView.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.ads;

import com.gamehouse.crosspromotion.implementation.Destroyable;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.RelativeLayout;

public class BaseAdView extends RelativeLayout implements Destroyable
{
	private enum ContentState
	{
		Created, Loading, Loaded, NotLoaded;
	}

	private ContentState state;
	private BaseAdViewContentListener contentListener;

	public BaseAdView(Context context)
	{
		super(context);
		
		state = ContentState.Created;
		
		setHorizontalScrollBarEnabled(false);
        setVerticalScrollBarEnabled(false);

        setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
	}

	private BaseAdView(Context context, AttributeSet attrs)
	{
		super(context, attrs);
	}

	private BaseAdView(Context context, AttributeSet attrs, int defStyle)
	{
		super(context, attrs, defStyle);
	}
	
	@Override
	public void destroy()
	{
		stop();
	}
	
	////////////////////////////////////////////////////////////////
	// Content

	public void loadContent()
	{
		state = ContentState.Loading;
	}

	public void cancelLoadContent()
	{
		state = ContentState.NotLoaded;
		notifyCancelLoad();
	}

	public boolean isContentLoaded()
	{
		return state == ContentState.Loaded;
	}

	public boolean isContentLoading()
	{
		return state == ContentState.Loading;
	}

	public void contentDidLoad()
	{
		state = ContentState.Loaded;
		notifyContentDidLoad();
	}

	public void contentDidFailWithError(Throwable error)
	{
		notifyFailLoadWithError(error);
	}

	////////////////////////////////////////////////////////////////
	// Life cycle
	
	public void start()
	{
	}

	public void stop()
	{
		if (isContentLoading())
		{
			cancelLoadContent();
		}
	}
	
	////////////////////////////////////////////////////////////////
	// Content listener notifications

	protected void notifyStartLoad()
	{
		if (contentListener != null)
		{
			contentListener.onViewStartLoad(this);
		}
	}

	protected void notifyContentDidLoad()
	{
		if (contentListener != null)
		{
			contentListener.onViewFinishLoad(this);
		}
	}

	protected void notifyFailLoadWithError(Throwable error)
	{
		if (contentListener != null)
		{
			contentListener.onViewLoadFail(this, error);
		}
	}

	protected void notifyCancelLoad()
	{
		if (contentListener != null)
		{
			contentListener.onViewCancelLoad(this);
		}
	}
}
