//
//  AsyncChunkSocket.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.debug;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

public class AsyncChunkSocket
{
	private final Object mutex = new Object();

	private AsyncChunkSocketListener listener;

	private Handler listenerHandler;
	
	private Socket socket;
	
	private AsyncChunkSender chunkSender;
	private AsyncChunkReceiver chunkReceiver;
	
	private Queue<Chunk> saveQueue;

	public AsyncChunkSocket(AsyncChunkSocketListener listener, Looper listenerLooper)
	{
		if (listener == null)
		{
			throw new NullPointerException("Listener is null");
		}
		this.listener = listener;

		listenerHandler = new Handler(listenerLooper);
		saveQueue = new LinkedList<Chunk>();
	}

	public boolean connect(final String host, final int port)
	{
		if (socket == null)
		{
			Thread t = new Thread(new Runnable()
			{
				@Override
				public void run()
				{
					try
					{
						socket = new Socket(host, port);
						AsyncChunkReceiver receiver = new AsyncChunkReceiver(socket.getInputStream());
						AsyncChunkSender sender = new AsyncChunkSender(socket.getOutputStream());

						chunkSender = sender;
						chunkReceiver = receiver;
						
						receiver.start();
						sender.start();
						
						notifyConnect();
						
						sendSaveQueue();
						
						receiver.join();
						sender.join();
						
						notifyDisconnect();
					}
					catch (IOException e)
					{
						notifyFailConnect(e.getMessage());
					}
					
					socket = null;
					chunkSender = null;
					chunkReceiver = null;
				}
			});
			t.start();
			return true;
		}

		return false;
	}

	public void disconnect()
	{
		synchronized (mutex)
		{
			if (socket != null)
			{
				if (chunkSender != null)
				{
					chunkSender.stop();
					chunkSender = null;
				}
				
				if (chunkReceiver != null)
				{
					chunkReceiver.stop();
					chunkReceiver = null;
				}
				
				try
				{
					socket.close();
				}
				catch (IOException e)
				{
				}
				socket = null;
			}
		}
	}
	
	public boolean isConnected()
	{
		return socket != null && socket.isConnected();
	}

	////////////////////////////////////////////////////////////////
	// Chunks

	public synchronized void send(Chunk chunk)
	{
		if (chunkSender != null)
		{
		    if (saveQueue != null)
		    {
		        sendSaveQueue();
		    }
		    
			chunkSender.send(chunk);
		}
		else if (saveQueue != null) // store items when the socket is connecting
		{
			saveQueue.add(chunk);
		}
	}

	private synchronized void sendSaveQueue()
	{
		// send stored items
		if (saveQueue != null)
		{
			for (Chunk c : saveQueue)
			{
				chunkSender.send(c);
			}
			saveQueue = null;
		}
	}

	////////////////////////////////////////////////////////////////
	// Listener

	private void notifyConnect()
	{
		listenerHandler.post(new Runnable()
		{
			@Override
			public void run()
			{
				listener.onConnectedToHost();
			}
		});
	}

	private void notifyFailConnect(final String message)
	{
		listenerHandler.post(new Runnable()
		{
			@Override
			public void run()
			{
				listener.onNotConnectedToHost(message);
			}
		});
	}
	
	private void notifyDisconnect()
	{
		listenerHandler.post(new Runnable()
		{
			@Override
			public void run()
			{
				listener.onDisconnectedFromHost();
			}
		});
	}

	private void notifyChunkReceive(final Chunk chunk)
	{
		listenerHandler.post(new Runnable()
		{
			@Override
			public void run()
			{
				listener.onChunkReceive(chunk);
			}
		});
	}
	
	@SuppressWarnings("unused")
    private void notifyChunkSend(final Chunk chunk)
	{
		listenerHandler.post(new Runnable()
		{
			@Override
			public void run()
			{
				listener.onChunkSend(chunk);
			}
		});
	}
	
	private void notifyUnknownChunk(final String name, final int size)
	{
		listenerHandler.post(new Runnable()
		{
			@Override
			public void run()
			{
				listener.onChunkFail(name, size);
			}
		});
	}

	////////////////////////////////////////////////////////////////
	// Async chunk handler

	private abstract class AsyncChunkHandler
	{
		private Thread thread;

		protected void start(Runnable runnable)
		{
			if (thread != null)
			{
				throw new IllegalStateException("Already running");
			}

			thread = new Thread(runnable);
			thread.start();
		}

		public void join()
		{
			if (thread != null)
			{
				try
				{
					thread.join();
				}
				catch (InterruptedException e)
				{
				}
			}
		}
		
		public void stop()
		{
			if (thread != null)
			{
				thread.interrupt();
				thread = null;
			}
		}
	}

	////////////////////////////////////////////////////////////////
	// Async receiver

	private class AsyncChunkReceiver extends AsyncChunkHandler
	{
		private InputStream stream;

		public AsyncChunkReceiver(InputStream stream)
		{
			if (stream == null)
			{
				throw new NullPointerException("Stream is null");
			}

			if (listener == null)
			{
				throw new NullPointerException("Listener is null");
			}

			this.stream = stream;
		}

		public void start()
		{
			start(new Runnable()
			{
				@Override
				public void run()
				{
					try
					{
						receiveChunks(stream);
					}
					catch (IOException e)
					{
						Log.e("RM", "Error receiving chunks: " + e.getMessage());
						disconnect();
					}
				}
			});
		}

		private void receiveChunks(InputStream stream) throws IOException
		{
			DataInputStream dis = null;
			try
			{
				ChunkRegistry chunkRegistry = ChunkRegistry.getInstance();

				dis = new DataInputStream(stream);
				while (!Thread.interrupted())
				{
					String name = dis.readUTF();
					int size = dis.readInt();

					Chunk chunk = chunkRegistry.createChunk(name);
					if (chunk != null)
					{
						chunk.read(dis);
						notifyChunkReceive(chunk);
					}
					else
					{
						dis.skip(size);
						notifyUnknownChunk(name, size);
					}
				}
			}
			finally
			{
				if (dis != null)
				{
					dis.close();
				}
			}
		}
	}

	////////////////////////////////////////////////////////////////
	// Async sender

	private class AsyncChunkSender extends AsyncChunkHandler
	{
		private DataOutputStream dataStream;
		private Queue<Chunk> chunkQueue;

		private final Object mutex = new Object();

		public AsyncChunkSender(OutputStream stream)
		{
			if (stream == null)
			{
				throw new NullPointerException("stream is null");
			}

			dataStream = new DataOutputStream(stream);
			chunkQueue = new LinkedList<Chunk>();
		}

		public void start()
		{
			start(new Runnable()
			{
				@Override
				public void run()
				{
					try
					{
						sendChunks(dataStream);
					}
					catch (IOException e)
					{
						Log.e("RM", "Error sending chunks: " + e.getMessage());
						disconnect();
					}
				}
			});
		}

		public void send(Chunk chunk)
		{
			synchronized (mutex)
			{
				chunkQueue.add(chunk);
				mutex.notifyAll();
			}
		}

		private void sendChunks(OutputStream stream) throws IOException
		{
			List<Chunk> temp = new ArrayList<Chunk>();
			HackByteArrayOutputStream bos = new HackByteArrayOutputStream();
			DataOutputStream output = new DataOutputStream(bos);
			
			while (!Thread.interrupted())
			{
				synchronized (mutex)
				{
					boolean interrupted = waitForQueue();
					if (interrupted)
					{
						break;
					}

					temp.addAll(chunkQueue);
					chunkQueue.clear();
				}

				for (Chunk chunk : temp)
				{
					chunk.write(output);
					
					byte[] data = bos.getBuffer(); // don't copy an array
					int length = bos.size();
					
					dataStream.writeBytes(chunk.getName());
					dataStream.writeInt(length);
					dataStream.write(data, 0, length);
					bos.reset();
					
					chunk.recycle(); // put it back to pool
				}
				temp.clear();
			}
		}

		private boolean waitForQueue()
		{
			while (chunkQueue.isEmpty())
			{
				try
				{
					mutex.wait();
				}
				catch (InterruptedException e)
				{
					return true;
				}
			}

			return false;
		}
	}
}
