//
//  NotificationObserverGroup.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils.observing;

import java.util.ArrayList;
import java.util.List;

import com.gamehouse.crosspromotion.implementation.utils.Log;

public class NotificationObserverGroup
{
	private String name;
	private List<NotificationObserver> observers = new ArrayList<NotificationObserver>();

	public NotificationObserverGroup(String name)
	{
		if (name == null)
		{
			throw new NullPointerException("name is null");
		}
		
		this.name = name;
	}
	
	public void addObserver(NotificationObserver observer)
	{
		if (observer == null)
		{
			throw new NullPointerException("observer == null");
		}
		synchronized (this)
		{
			if (!observers.contains(observer))
				observers.add(observer);
		}
	}
	
	public String getName()
	{
		return name;
	}

	public int size()
	{
		return observers.size();
	}

	public synchronized void deleteObserver(NotificationObserver observer)
	{
		observers.remove(observer);
	}

	public synchronized void deleteObservers()
	{
		observers.clear();
	}

	public void notifyObservers()
	{
		notifyObservers(null);
	}

	public void notifyObservers(Object data)
	{
		int size = 0;
		NotificationObserver[] arrays = null;
		synchronized (this)
		{
			size = observers.size();
			arrays = new NotificationObserver[size];
			observers.toArray(arrays);
		}
		if (arrays != null)
		{
			for (NotificationObserver observer : arrays)
			{
				notifyObserver(observer, data);
			}
		}
	}

	private void notifyObserver(NotificationObserver observer, Object data)
	{
		try
		{
			observer.onNotificationReceive(name, data);
		}
		catch (Exception e)
		{
			Log.logException(e, "Unable to notify the observer");
		}
	}
}
