//
//  Cmd_complete.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.gpn.commands;

import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView;
import com.gamehouse.crosspromotion.implementation.gpn.JavaScriptCommand;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.gamehouse.crosspromotion.implementation.utils.DebugCheat;
import com.gamehouse.crosspromotion.implementation.utils.Log;

import static com.gamehouse.crosspromotion.implementation.utils.Tag.*;

public class Cmd_complete extends JavaScriptCommand
{
	private static final String PARAM_INCLUDES_POSITION = "position_includes";
	private static final String PARAM_EXCLUDES_POSITION = "position_excludes";

	public Cmd_complete()
	{
	}

	@Override
	public void execute()
	{
	    if (Debug.flag && DebugCheat.disableCompleteCommand)
	    {
	        Log.w(COMMANDS, "Ignored 'complete' command");
	        return;
	    }
	    
		updatePositions();
		getAdView().notifyViewLoad();
	}

	private void updatePositions()
	{
		InterstitialAdView interstitialView = Global.getCurrentAdView();
		Debug.assertNotNull(interstitialView, "interstitialView");

		if (interstitialView != null)
		{
			String includes = getStringParam(PARAM_INCLUDES_POSITION);
			if (includes != null)
			{
				Log.d(COMMANDS, "Includes positions: %s", includes);
				interstitialView.setIncludesPositions(getPositions(includes));
			}
			else
			{
				interstitialView.setIncludesPositions(null);
			}

			String excludes = getStringParam(PARAM_EXCLUDES_POSITION);
			if (excludes != null)
			{
				Log.d(COMMANDS, "Excludes positions: %s", excludes);
				interstitialView.setExcludesPositions(getPositions(excludes));
			}
			else
			{
				interstitialView.setExcludesPositions(null);
			}
		}
	}

	private String[] getPositions(String string)
	{
		return string.split(",");
	}
}
