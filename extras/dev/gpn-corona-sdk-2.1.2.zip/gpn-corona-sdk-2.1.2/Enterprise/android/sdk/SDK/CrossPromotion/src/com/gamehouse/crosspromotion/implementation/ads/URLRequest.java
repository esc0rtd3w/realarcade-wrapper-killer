//
//  URLRequest.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.ads;

import static com.gamehouse.crosspromotion.implementation.utils.StringUtils.encodeURLString;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class URLRequest
{
	private String baseURL;
	private Map<String, Object> params;
	
	public URLRequest(String baseURL)
	{
		this(baseURL, null);
	}
	
	public URLRequest(String baseURL, Map<String, Object> params)
	{
		if (baseURL == null)
		{
			throw new NullPointerException("Base URL is null");
		}
		
		checkParams(params);
		
		this.baseURL = baseURL;
		this.params = params;
	}
	
	private void checkParams(Map<String, Object> params)
	{
		if (params != null)
		{
			Set<Entry<String, Object>> entries = params.entrySet();
			for (Entry<String, Object> e : entries)
			{
				if (e.getKey() == null)
				{
					throw new IllegalArgumentException("key is null");
				}
	
				if (e.getValue() == null)
				{
					throw new IllegalArgumentException("value is null for key: '" + e.getKey() + "'");
				}
			}
		}
	}
	
	public String absoluteURL()
	{
		String query = query();
		return query != null ? (baseURL + "?" + query) : baseURL;
	}
	
	public String query()
	{
		if (params != null && params.size() > 0)
		{
			StringBuilder query = new StringBuilder();
			Set<Entry<String, Object>> entries = params.entrySet();
			
			int entryIndex = 0;
			for (Entry<String, Object> e : entries)
			{
				String key = e.getKey();
				String value = e.getValue().toString();
				
				query.append(encodeURLString(key) + "=" + encodeURLString(value));
				
				if (++entryIndex < entries.size())
				{
					query.append("&");
				}
			}
			
			return query.toString();
		}
		
		return null;
	}
	
	public void addParam(String key, String value)
	{
		if (key == null)
		{
			throw new IllegalArgumentException("key is null");
		}

		if (value == null)
		{
			throw new IllegalArgumentException("value is null");
		}
		
		params.put(key, value);
	}
	
	public String getBaseURL()
	{
		return baseURL;
	}
	
	@Override
	public String toString()
	{
		return absoluteURL();
	}
}
