//
//  HtmlAdViewListener.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.gpn;

import java.util.Map;

public interface HtmlAdViewListener
{
	/** Called when the ad loads successfully. */
	void onAdViewLoad(HtmlAdView view);

	/** Called when the ad fails to load. */
	void onAdViewFail(HtmlAdView htmlAdView, int errorCode, String description, String failingUrl);

	/**
	 * Called when the ad is about to display modal content (thus taking over
	 * the screen).
	 */
	void onModalViewShow(HtmlAdView view);

	/**
	 * Called when the ad has dismissed any modal content (removing any
	 * on-screen takeovers).
	 */
	void onModalViewHide(HtmlAdView view);

	/**
	 * Called when the ad is about to lunch another application (like PlayStore)
	 */
	void onApplicationWillLeave(HtmlAdView view);
	
	/**
	 * Called periodically to let the receiver know if JavaScript layer is doing fine
	 */
	void onHeartBeat(HtmlAdView view);
	
	/**
     * Called to let the receiver know if present was successful
     */
	void onPresented(HtmlAdView htmlAdView);
	
	/**
	 * Called when debug event is fired on JavaScript layers 
	 */
	void onDebugEvent(HtmlAdView view, String name, Map<String, Object> params);

}
