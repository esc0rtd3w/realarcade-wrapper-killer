//
//  RequestChunk.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.debug.chunks;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.gamehouse.crosspromotion.debug.IDChunk;
import com.gamehouse.crosspromotion.implementation.network.HttpRequest;

public class RequestChunk extends IDChunk
{
    private enum Type
    {
        None, Queued, Finished, Failed, Cancelled
    }

    private Type type;
    private String requestName;
    private String urlStirng;
    private Map<String, Object> params;
    private Map<String, Object> headers;
    private long duration;

    private Throwable error;

    public RequestChunk()
    {
        super("rqst");
    }

    ////////////////////////////////////////////////////////////////
    // Objects pool

    @Override
    protected void onRecycle()
    {
        super.onRecycle();
        type = Type.None;
    }

    public RequestChunk initQueued(HttpRequest request)
    {
        return init(Type.Queued, request);
    }

    public RequestChunk initFinished(HttpRequest request)
    {
        return init(Type.Finished, request);
    }

    public RequestChunk initFailed(HttpRequest request, Throwable error)
    {
        this.error = error;
        return init(Type.Failed, request);
    }

    public RequestChunk initCancelled(HttpRequest request)
    {
        return init(Type.Cancelled, request);
    }

    private RequestChunk init(Type type, HttpRequest request)
    {
        super.init(request.getId());

        this.type = type;
        this.requestName = request.getName();
        this.urlStirng = request.getUrlString();
        this.params = request.params();
        this.headers = request.headers();
        this.duration = request.duration();

        return this;
    }

    ////////////////////////////////////////////////////////////////
    // IO

    @Override
    public void write(DataOutput output) throws IOException
    {
        super.write(output);

        writeUTF(output, type);

        Serialization serialization = findSerialization(type);
        serialization.write(output, this);
    }

    @Override
    public void read(DataInput input) throws IOException
    {
        super.read(input);

        String typeName = readUTF(input);
        Type type = Type.valueOf(typeName);

        this.type = type;
        Serialization serialization = findSerialization(type);
        serialization.read(input, this);
    }

    ////////////////////////////////////////////////////////////////
    // Serialization

    private static Map<Type, Serialization> serializationLookup;

    static
    {
        serializationLookup = new HashMap<RequestChunk.Type, Serialization>();

        // queued
        serializationLookup.put(Type.Queued, new Serialization()
        {
            @Override
            public void write(DataOutput out, RequestChunk chunk) throws IOException
            {
                writeUTF(out, chunk.requestName);
                writeUTF(out, chunk.urlStirng);
                writeMap(out, chunk.params);
                writeMap(out, chunk.headers);
            }

            @Override
            public void read(DataInput input, RequestChunk chunk) throws IOException
            {
                chunk.requestName = readUTF(input);
                chunk.urlStirng = readUTF(input);
                chunk.params = readMap(input);
                chunk.headers = readMap(input);
            }
        });

        // finished
        serializationLookup.put(Type.Finished, new Serialization()
        {
            @Override
            public void write(DataOutput output, RequestChunk chunk) throws IOException
            {
                output.writeInt((int) chunk.duration);
            }

            @Override
            public void read(DataInput input, RequestChunk chunk) throws IOException
            {
                chunk.duration = input.readInt();
            }
        });
        
        // cancelled
        serializationLookup.put(Type.Cancelled, new Serialization()
        {
            @Override
            public void write(DataOutput output, RequestChunk chunk) throws IOException
            {
                output.writeInt((int) chunk.duration);
            }
            
            @Override
            public void read(DataInput input, RequestChunk chunk) throws IOException
            {
                chunk.duration = input.readInt();
            }
        });
        
        // failed
        serializationLookup.put(Type.Failed, new Serialization()
        {
            @Override
            public void write(DataOutput output, RequestChunk chunk) throws IOException
            {
                output.writeInt((int) chunk.duration);
                writeUTF(output, chunk.error.getClass().getName());
                writeUTF(output, chunk.error.getMessage());
            }
            
            @Override
            public void read(DataInput input, RequestChunk chunk) throws IOException
            {
                chunk.duration = input.readInt();
                throw new Error("Implement me");
            }
        });
    }

    private static Serialization findSerialization(Type type)
    {
        Serialization serialization = serializationLookup.get(type);
        if (serialization == null)
        {
            throw new IllegalArgumentException("Can't find serialization for type: " + type);
        }

        return serialization;
    }

    private static abstract class Serialization
    {
        public abstract void write(DataOutput output, RequestChunk chunk) throws IOException;

        public abstract void read(DataInput input, RequestChunk chunk) throws IOException;
    }
}
