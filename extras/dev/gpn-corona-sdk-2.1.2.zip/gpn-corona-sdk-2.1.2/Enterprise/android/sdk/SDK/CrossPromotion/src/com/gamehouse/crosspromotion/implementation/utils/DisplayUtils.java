//
//  DisplayUtils.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import android.content.Context;
import android.graphics.Point;
import android.view.Display;
import android.view.WindowManager;

public class DisplayUtils
{
	private static Point size = new Point();

	@SuppressWarnings("deprecation")
	public static Point getDisplaySize(Context context)
	{
		Display display = getDisplay(context);
		if (display != null)
		{
			size.x = display.getWidth();
			size.y = display.getHeight();

			return size;
		}

		return null;
	}

	public static Display getDisplay(Context context)
	{
		WindowManager wm = ServiceUtils.getWindowManager(context);
		return wm != null ? wm.getDefaultDisplay() : null;
	}

	public static int pointsToPixels(Context context, int points)
	{
		return (int) (points * getDensity(context));
	}

	public static int pixelsToPoints(Context context, int pixels)
	{
		return (int) (pixels / getDensity(context));
	}

	private static float getDensity(Context context)
	{
		if (context == null)
		{
			throw new IllegalArgumentException("Context is null");
		}

		float density = context.getResources().getDisplayMetrics().density;
		return density == 0 ? 1 : density;
	}

}
