//
//  DebugCheat.java
//
//  Copyright 2014 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

package com.gamehouse.crosspromotion.implementation.utils;

import java.io.DataInputStream;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.content.Context;
import android.content.pm.PackageInfo;

import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.utils.Log.LogLevel;
import com.gamehouse.debugger.network.AsyncSocketConnection;
import com.gamehouse.debugger.network.AsyncSocketConnectionListener;
import com.gamehouse.debugger.network.NetCmd;
import com.gamehouse.debugger.network.NetCmdRegistry;
import com.gamehouse.debugger.network.commands.cmd_accept;
import com.gamehouse.debugger.network.commands.cmd_clritflg;
import com.gamehouse.debugger.network.commands.cmd_hello;
import com.gamehouse.debugger.network.commands.cmd_setp;

public class DebugCheat
{
	private static final String TAG = "Debugger";
	
    private static final int PROTOCOL_VERSION = 1;
    
    private static final String DEBUGGER_APP_PACKAGE = "com.gamehouse.crosspromotiondebugger";
    private static final String DEBUGGER_HOST = "localhost";
    private static final int DEBUGGER_PORT = 42511;

    public static boolean disableCompleteCommand;
    public static boolean disablePresentedCommand;
    public static boolean disableHeartbeatCommand;

    public static int tagMask = 0x80000000;
    
    public static String remoteHost;
    public static String remotePort;

    private static Cheater cheater;

    public static boolean tryCheat(final Context context)
    {
        if (isDebuggerRunning(context))
        {
            log("Debugger is running! Trying to connect...");
            
            cheater = new Cheater(context);

            Thread thread = new Thread(new Runnable()
            {
                @Override
                public void run()
                {
                    try
                    {
                        Socket socket = new Socket(DEBUGGER_HOST, DEBUGGER_PORT);
                        AsyncSocketConnection connection = AsyncSocketConnection.open(socket);
                        
                        log("Connected to debugger...");
                        
                        String packageName = context.getPackageName();
                        PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 0);
                        
                        connection.send(new cmd_hello().init(PROTOCOL_VERSION, packageName, packageInfo.versionName));
                        connection.setListener(new AsyncSocketConnectionListener()
                        {
                            @Override
                            public void onCommandReceive(AsyncSocketConnection connection, String name, int size, DataInputStream stream)
                            {
                                try
                                {
                                    readCommand(connection, name, size, stream);
                                }
                                catch (IOException e)
                                {
                                    e.printStackTrace();
                                    releaseThreadBlocker();
                                }
                            }
                        });
                        
                        Debug.init(context);
                        
                        log("Waiting for debugger state...");
                        waitForThreadBlocker();
                        log("Resuming...");

                        cheater.postExecute();
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

            try
            {
                thread.join();
            }
            catch (InterruptedException e)
            {
            	return false;
            }
            
            return true;
        }

        return false;
    }

	private static boolean isDebuggerRunning(Context context)
    {
        try
        {
            ActivityManager manager = ServiceUtils.getActivityManager(context);
            if (manager != null)
            {
                List<RunningAppProcessInfo> processes = manager.getRunningAppProcesses();
                for (int i = 0; i < processes.size(); i++)
                {
                    String processName = processes.get(i).processName;
                    if (DEBUGGER_APP_PACKAGE.equals(processName))
                    {
                        return true;
                    }
                }
            }
        }
        catch (Exception e)
        {
        }

        return false;
    }

    ////////////////////////////////////////////////////////////////
    // Commands
    
    private static void readCommand(AsyncSocketConnection connection, String name, int size, DataInputStream stream) throws IOException
    {
    	NetCmd cmd = cheater.loadCmd(name);
    	if (cmd == null)
    	{
    		log("Can't load cmd: '" + name + "'");
    		return;
    	}
    	
    	cmd.read(stream);
    	
    	onCmdReceived(cmd);
    }

	private static void onCmdReceived(NetCmd cmd)
	{
		if (cmd instanceof cmd_setp)
    	{
			onCmdReceived((cmd_setp)cmd);
    	}
    	else if (cmd instanceof cmd_accept)
        {
    		onCmdReceived((cmd_accept)cmd);
        }
    	else if (cmd instanceof cmd_clritflg)
    	{
    	    onCmdReceived((cmd_clritflg)cmd);
    	}
	}
	
	private static void onCmdReceived(cmd_accept cmd)
	{
		Map<String, Object> settings = cmd.getSettings();
		cheater.forcePreference(settings);
		
		releaseThreadBlocker();
	}
	
	private static void onCmdReceived(cmd_setp cmd)
	{
		String key = cmd.getKey();
		Object value = cmd.getValue();
		
		log("Updated pref: '" + key + "'=" + value);
		cheater.updatePreference(key, value);
	}
	
	private static void onCmdReceived(cmd_clritflg cmd)
	{
	    Context context = getContext();
	    if (context != null)
	    {
	        log("Clearing install tracking flag...");
	        Global.clearInstallTrackFlag(context);
	    }
	}
    
    ////////////////////////////////////////////////////////////////
	// Thread block
    
    private static void waitForThreadBlocker()
	{
    	if (cheater != null)
    	{
    		cheater.waitForThreadBlocker();
    	}
	}
    
    private static void releaseThreadBlocker()
    {
    	if (cheater != null)
    	{
    		cheater.releaseThreadBlocker();
    	}
    }
    
    ////////////////////////////////////////////////////////////////
	// Helpers
    
    private static void log(String format, Object... params)
    {
    	log(StringUtils.tryFormatString(format, params));
    }
    
    private static void log(String msg)
	{
		android.util.Log.w(TAG, msg);
	}
    
    private static Context getContext()
    {
        return cheater != null ? cheater.getContext() : null;
    }
    
    ////////////////////////////////////////////////////////////////
	// Cheater
    
    private static class Cheater
    {
		private static final String PREFS_DEBUGGER_ENABLED = "debugger_enabled";
    	private static final String PREFS_RM_ENABLED = "rm_enabled";
    	private static final String PREFS_RM_PORT = "rm_port";
    	private static final String PREFS_RM_HOST = "rm_host";
    	private static final String PREFS_LOG_ENABLED = "log_enabled";
    	private static final String PREFS_LOG_LEVEL = "log_level";
    	private static final String PREFS_LOG_TAGS = "log_tags";
		
    	private static final String COMMANDS_PACKAGE = "com.gamehouse.debugger.network.commands";
    	
    	private WeakReference<Context> contextRef;
    	
    	private final Object mutext;
    	private boolean waitFlag;
    	
    	private NetCmdRegistry cmdRegistry;
    	
    	private Map<String, OnPreferenceChangeListener> preferenceListenerLookup;
    	
    	private boolean debuggerEnabled;
    	private boolean remoteMonitorEnabled;
    	private String remoteMonitorHost;
    	private int remoteMonitorPort;
    	
    	/** Keep the last log level to restore it on enable/disable log flag change */
    	private LogLevel lastLogLevel;
    	
    	public Cheater(Context context)
		{
    	    if (context == null)
            {
                throw new NullPointerException("'context' is null");
            }
    	    
    	    contextRef = new WeakReference<Context>(context);
    	    
    		lastLogLevel = Log.getLogLevel();
    		
    		mutext = new Object();
    		cmdRegistry = new NetCmdRegistry(COMMANDS_PACKAGE);
    		
    		preferenceListenerLookup = createPreferenceListenerLookup();
		}

		////////////////////////////////////////////////////////////////
		// Commands
    	
    	public <T extends NetCmd> NetCmd loadCmd(String name)
    	{
    		return cmdRegistry.load(name);
    	}
    	
    	////////////////////////////////////////////////////////////////
		// Preferences
    	
    	public void forcePreference(Map<String, Object> data)
    	{
    		Set<String> keys = data.keySet();
    		for (String key : keys)
			{
				Object value = data.get(key);
				log("Forcing preference: " + key + "=" + value);
				
				onPrefereceUpdated(key, value);
			}
    	}
        
        public void updatePreference(String key, Object value)
        {
        	onPrefereceUpdated(key, value);
        }

        ////////////////////////////////////////////////////////////////
		// Preference listener
        
        private void onPrefereceUpdated(String key, Object value)
		{
        	OnPreferenceChangeListener listener = preferenceListenerLookup.get(key);
        	if (listener != null)
        	{
        		listener.onPreferenceChanged(key, value);
        	}
		}
        
        private Map<String, OnPreferenceChangeListener> createPreferenceListenerLookup()
		{
			Map<String, OnPreferenceChangeListener> lookup = new HashMap<String, OnPreferenceChangeListener>();
			
			// debugger_enabled
			lookup.put(PREFS_DEBUGGER_ENABLED, new OnPreferenceChangeListener()
			{
				@Override
				public void onPreferenceChanged(String key, Object value)
				{
					debuggerEnabled = value instanceof Boolean && ((Boolean)value).booleanValue();
				}
			});
			
			// remote monitor
			lookup.put(PREFS_RM_ENABLED, new OnPreferenceChangeListener()
			{
				@Override
				public void onPreferenceChanged(String key, Object value)
				{
					if (value instanceof Boolean)
					{
						remoteMonitorEnabled = (Boolean) value;
						if (!remoteMonitorEnabled)
						{
							log("Remote monitor disabled");
							Debug.disconnect();
						}
					}
					else
					{
						remoteMonitorEnabled = false;
					}
				}
			});
			
			lookup.put(PREFS_RM_HOST, new OnPreferenceChangeListener()
			{
				@Override
				public void onPreferenceChanged(String key, Object value)
				{
					if (value instanceof String)
					{
						remoteMonitorHost = ClassUtils.tryCast(value, String.class);
					}
				}
			});
			
			lookup.put(PREFS_RM_PORT, new OnPreferenceChangeListener()
			{
				@Override
				public void onPreferenceChanged(String key, Object value)
				{
					if (value instanceof String)
					{
						remoteMonitorPort = StringUtils.tryParseInt((String) value, 0);
					}
				}
			});
			
			// logger flag
			lookup.put(PREFS_LOG_ENABLED, new OnPreferenceChangeListener()
			{
				@Override
				public void onPreferenceChanged(String key, Object value)
				{
					if (value instanceof Boolean)
					{
						boolean enabled = (Boolean) value;
						if (enabled)
						{
							log("Logger enabled: %s", lastLogLevel);
							Log.setLogLevel(lastLogLevel);
						}
						else
						{
							lastLogLevel = Log.getLogLevel();
							Log.setLogLevel(LogLevel.None);
							
							log("Logger disabled!");
						}
					}
					else
					{
						log("Unexpected value type: " + value.getClass());
					}
				}
			});
			
			// log level
			lookup.put(PREFS_LOG_LEVEL, new OnPreferenceChangeListener()
			{
				@Override
				public void onPreferenceChanged(String key, Object value)
				{
					if (value instanceof String)
					{
						String levelName = (String) value;
						try
						{
							LogLevel level = LogLevel.valueOf(levelName);
							
							lastLogLevel = Log.getLogLevel();
							Log.setLogLevel(level);
							
							log("Set log level: %s", level);
						}
						catch (IllegalArgumentException e)
						{
							log("Illegal level name: '%s'", levelName);
						}
					}
					else
					{
						log("Unexpected value type: %s", value.getClass());
					}
				}
			});
			
			// log tag
			lookup.put(PREFS_LOG_TAGS, new OnPreferenceChangeListener()
			{
				private Map<String, Integer> tagsLookup;
				{
					tagsLookup = new HashMap<String, Integer>();
					
					tagsLookup.put("Common", Tag.COMMON);
				    tagsLookup.put("Javascript", Tag.JAVASCRIPT);
				    tagsLookup.put("Commands", Tag.COMMANDS);
				    tagsLookup.put("Network", Tag.NETWORK);
				    tagsLookup.put("Callbacks", Tag.CALLBACKS);
				    tagsLookup.put("Purchase", Tag.PURCHASE);
				    tagsLookup.put("Settings", Tag.SETTINGS);
				    tagsLookup.put("Timers", Tag.TIMERS);
				    tagsLookup.put("Verbose", Tag.VERBOSE);
				}
				
				@Override
				@SuppressWarnings("unchecked")
				public void onPreferenceChanged(String key, Object value)
				{
					if (value instanceof Set)
					{
						Set<String> values = (Set<String>) value;
						Log.setTagMask(Tag.NONE);
						
						for (String tagName : values)
						{
							Integer tag = tagsLookup.get(tagName);
							if (tag != null)
							{
								Log.setTagEnabled(tag, true);
								log("Enable tag: " + tagName);
							}
							else
							{
								log("Unknown tag: " + tagName);
							}
						}
					}
				}
			});
			
			return lookup;
		}
        
        ////////////////////////////////////////////////////////////////
		// Post execute
        
        public void postExecute()
		{
        	if (!debuggerEnabled)
        	{
        		log("Debugger disabled");
        		return;
        	}

        	if (remoteMonitorEnabled)
        	{
        		connectRemoteMonitor();
        	}
		}

        ////////////////////////////////////////////////////////////////
		// Remote monitor
        
		private void connectRemoteMonitor()
		{
			if (remoteMonitorHost != null && remoteMonitorPort != 0)
			{
				Debug.connect(remoteMonitorHost, remoteMonitorPort);
			}
			else
			{
				throw new RuntimeException("Missing host or port settings"); // TODO: custom exception class
			}
		}
		
    	////////////////////////////////////////////////////////////////
		// Thread block

		public void waitForThreadBlocker()
        {
            synchronized (mutext)
            {
                waitFlag = true;
                do
                {
                    try
                    {
                        mutext.wait();
                    }
                    catch (InterruptedException e)
                    {
                        break;
                    }
                }
                while (waitFlag);
            }
        }
        
        public void releaseThreadBlocker()
        {
            synchronized (mutext)
            {
                waitFlag = false;
                mutext.notifyAll();
            }
        }
        
        ////////////////////////////////////////////////////////////////
        // Getters/Setters
        
        public Context getContext()
        {
            return contextRef.get();
        }
    }
    
    private static interface OnPreferenceChangeListener
    {
    	void onPreferenceChanged(String key, Object value);
    }
}
