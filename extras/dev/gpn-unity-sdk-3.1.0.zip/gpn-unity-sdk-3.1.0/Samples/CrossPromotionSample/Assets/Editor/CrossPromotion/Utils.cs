﻿using UnityEngine;
using UnityEditor;

using System;
using System.Collections.Generic;
using System.Reflection;

namespace GPN
{
    struct DialogButton
    {
        public readonly string title;
        public readonly Action<string> action;
        
        public DialogButton(string title, Action action)
        {
            this.title = title;
            this.action = action != null ? (Action<string>)(delegate(string obj) { action(); }) : null;
        }
        
        public DialogButton(string title, Action<string> action = null)
        {
            this.title = title;
            this.action = action;
        }
        
        internal void PerformAction()
        {
            try
            {
                if (action != null)
                {
                    action(title);
                }
            }
            catch (Exception e)
            {
                Debug.LogException(e);
            }
        }
    }

    static class Utils
    {
        #region Reflection
        
        public static string GetStringField(object obj, string name)
        {
            Type type = obj.GetType();
            FieldInfo field = type.GetField(name, BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance);
            return field != null ? field.GetValue(obj) as string : null;
        }
        
        public static void SetStringField(object obj, string name, string value)
        {
            Type type = obj.GetType();
            FieldInfo field = type.GetField(name, BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.Instance);
            if (field != null)
            {
                field.SetValue(obj, value);
            }
        }

        public static Type TypeForName(string typeName)
        {
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                foreach (Type type in assembly.GetTypes())
                {
                    if (type.FullName == typeName)
                    {
                        return type;
                    }
                }
            }
            
            return null;
        }
        
        #endregion

        #region Dialogs
        
        internal static bool ShowDialog(string title, string message)
        {
            return EditorUtility.DisplayDialog(title, message, "Ok", "Cancel");
        }
        
        internal static void ShowDialog(string title, string message, DialogButton buttonOk)
        {
            if (EditorUtility.DisplayDialog(title, message, buttonOk.title))
            {
                buttonOk.PerformAction();
            }
        }
        
        internal static void ShowDialog(string title, string message, DialogButton buttonOk, DialogButton buttonCancel)
        {
            if (EditorUtility.DisplayDialog(title, message, buttonOk.title, buttonCancel.title))
            {
                buttonOk.PerformAction();
            }
            else
            {
                buttonCancel.PerformAction();
            }
        }
        
        internal static void ShowDialog(string title, string message, DialogButton buttonOk, DialogButton buttonCancel, DialogButton buttonAlt)
        {
            int choice = EditorUtility.DisplayDialogComplex(title, message, buttonOk.title, buttonCancel.title, buttonAlt.title);
            switch (choice)
            {
                case 0:
                    buttonOk.PerformAction();
                    break;
                case 1:
                    buttonCancel.PerformAction();
                    break;
                case 2:
                    buttonAlt.PerformAction();
                    break;
            }
        }
        
        internal static void ShowMessageDialog(string title, string message)
        {
            EditorUtility.DisplayDialog(title, message, "OK");
        }
        
        #endregion

        #region Dispatcher
        
        private static Queue<Action> s_dispatchQueue = new Queue<Action>();
        
        public static void DispatchOnMainThread(Action action)
        {
            lock (s_dispatchQueue)
            {
                s_dispatchQueue.Enqueue(action);
                if (s_dispatchQueue.Count == 1)
                {
                    EditorApplication.update += RunDispatch;
                }
            }
        }
        
        private static void RunDispatch()
        {
            lock (s_dispatchQueue)
            {
                while (s_dispatchQueue.Count > 0)
                {
                    Action action = s_dispatchQueue.Dequeue();
                    action();
                }
                
                EditorApplication.update -= RunDispatch;
            }
        }
        
        #endregion

        public static void LogError(string format, params object[] args)
        {
            // Debug.LogError(kErrorMessage + ": " + string.Format(format, args));
            throw new NotImplementedException();
        }
    }

    #region Helpers

    public static class PlayerPrefsHelper
    {
        public static bool GetBool(string key, bool defaultValue = false)
        {
            int value = PlayerPrefs.GetInt(key, defaultValue ? 1 : 0);
            return value != 0;
        }

        public static void SetBool(string key, bool value)
        {
            PlayerPrefs.SetInt(key, value ? 1 : 0);
        }
    }

    #endregion

    #region Log
    
    static class Log
    {
        [System.Diagnostics.Conditional("GPN_DEVELOPMENT")]
        public static void d(string format, params object[] args)
        {
            Debug.Log(string.Format(format, args));
        }
        
        [System.Diagnostics.Conditional("GPN_DEVELOPMENT")]
        public static void w(string format, params object[] args)
        {
            Debug.LogWarning(string.Format(format, args));
        }
        
        [System.Diagnostics.Conditional("GPN_DEVELOPMENT")]
        public static void e(string format, params object[] args)
        {
            Debug.LogError(string.Format(format, args));
        }
        
        [System.Diagnostics.Conditional("GPN_DEVELOPMENT")]
        public static void e(Exception e, string format, params object[] args)
        {
            Debug.LogError(string.Format(format, args));
            Debug.LogException(e);
        }
    }

    #endregion
}
