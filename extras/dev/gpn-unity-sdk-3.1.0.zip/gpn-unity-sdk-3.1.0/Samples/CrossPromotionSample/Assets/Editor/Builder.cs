//  Builder.cs
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;
 
namespace GPN
{
    static partial class Builder
    {
        private delegate bool FilenameFilter(string path);

        private static readonly string BuildsDir = "Build";

        private static string GetProjectName()
        {
            string[] s = Application.dataPath.Split('/');
            return s[s.Length - 2];
        }
        
        private static string[] GetScenePaths()
        {
            string[] scenes = new string[EditorBuildSettings.scenes.Length];
            
            for(int i = 0; i < scenes.Length; i++)
            {
                scenes[i] = EditorBuildSettings.scenes[i].path;
            }
            
            return scenes;
        }
        
        private static void Cleanup(string dir)
        {
            if (Directory.Exists(dir))
            {
                Directory.Delete(dir, true);
            }
            Directory.CreateDirectory(dir);
        }
        
        private static T[] ConcatArrays<T>(params T[][] arrays) 
        {
            int length = 0;
            foreach (T[] array in arrays) {
                length += array.Length;
            }
            
            T[] result = new T[length];
            int pos = 0;
            foreach (T[] array in arrays) {
                System.Array.Copy(array, 0, result, pos, array.Length);
                pos += array.Length;
            }
            
            return result;
        }
        
        private static string[] ListFiles(string directory, FilenameFilter filter) 
        {
            List<string> list = new List<string>();
            ListFiles(list, directory, filter);
            return list.ToArray();
        }
        
        private static void ListFiles(List<string> list, string directory, FilenameFilter filter) 
        {
            if (filter(directory)) 
            {
                list.Add(directory);

                string[] directories = Directory.GetDirectories(directory);
                foreach (string child in directories)
                {
                    ListFiles(list, child, filter);
                }

                string[] files = Directory.GetFiles(directory);
                foreach (string file in files)
                {
                    if (filter(file))
                    {
                        list.Add(file);
                    }
                }
            }
        }
        
        private static bool IsDirectory(string path) 
        {
            FileAttributes attrs = File.GetAttributes(path);
            return (attrs & FileAttributes.Directory) == FileAttributes.Directory;
        }
    }
}
