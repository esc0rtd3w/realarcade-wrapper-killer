//  Builder.ExportApps.cs
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

using UnityEngine;
using UnityEditor;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace GPN
{
    public static partial class Builder
    {
        [MenuItem("File/AutoBuilder/iOS")]
        static void PerformiOSBuild()
        {
            string outDir = BuildsDir + "/iOS";
            Cleanup(outDir);

            #if UNITY_4_6
            BuildTarget target = BuildTarget.iPhone;
            #else
            BuildTarget target = BuildTarget.iOS;
            #endif

            EditorUserBuildSettings.SwitchActiveBuildTarget(target);
            BuildPipeline.BuildPlayer(GetScenePaths(), outDir, target, BuildOptions.None);
        }

        [MenuItem("File/AutoBuilder/Android")]
        static void PerformAndroidBuild()
        {
            string outDir = BuildsDir + "/Android";
            Cleanup(outDir);

            string productName = PlayerSettings.productName;

            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTarget.Android);
            BuildPipeline.BuildPlayer(GetScenePaths(), outDir + "/" + productName + ".apk", BuildTarget.Android, BuildOptions.None);
        }

    }
}
