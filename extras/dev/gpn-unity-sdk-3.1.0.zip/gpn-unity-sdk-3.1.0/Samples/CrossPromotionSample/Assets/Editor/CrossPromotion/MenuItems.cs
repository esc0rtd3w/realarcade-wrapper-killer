﻿using UnityEngine;
using UnityEditor;

using System;
using System.Collections;

namespace GPN
{
    public static class MenuItems
    {
        [MenuItem("Window/GameHouse Cross Promotion/Android setup...")]
        public static void RunAndroidSetup()
        {
            AndroidSetup.RunAndroidSetup();
        }

        [MenuItem("Window/GameHouse Cross Promotion/")]
        public static void Delimiter()
        {
        }

        [MenuItem("Window/GameHouse Cross Promotion/Register app...")]
        public static void RegisterApp()
        {
            Application.OpenURL("http://partners.gamehouse.com/gpn/");
        }

        [MenuItem("Window/GameHouse Cross Promotion/Help")]
        public static void Help()
        {
            Application.OpenURL("http://gpn.gamehouse.com/sdks/unity/readme");
        }
    }
}
