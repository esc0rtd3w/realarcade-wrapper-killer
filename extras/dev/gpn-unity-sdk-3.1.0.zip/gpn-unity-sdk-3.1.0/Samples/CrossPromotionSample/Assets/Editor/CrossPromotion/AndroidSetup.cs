﻿using UnityEngine;
using UnityEditor;

using System.IO;
using System.Collections;

namespace GPN
{
    static class AndroidSetup
    {
        internal static void RunAndroidSetup()
        {
            string sdkPath = GetAndroidSdkPath();
            string libProjPath = sdkPath + FixSlashes("/extras/google/google_play_services/libproject/google-play-services_lib");
            
            string libProjAM = libProjPath + FixSlashes("/AndroidManifest.xml");
            string libProjDestDir = FixSlashes("Assets/Plugins/Android/google-play-services_lib");
            
            string libSupportPath = sdkPath + FixSlashes("/extras/android/support/v4/android-support-v4.jar");
            string libSupportDest = FixSlashes("Assets/Plugins/Android/google-play-services_lib/libs/android-support-v4.jar");
            
            // check that Android SDK is there
            if (!HasAndroidSdk())
            {
                Debug.LogError("Android SDK not found.");
                EditorUtility.DisplayDialog(Strings.SdkNotFound, Strings.SdkNotFoundBlurb, "OK");
                return;
            }
            
            // check that the Google Play Services lib project is there
            if (!System.IO.Directory.Exists(libProjPath) || !System.IO.File.Exists(libProjAM))
            {
                Debug.LogError("Google Play Services lib project not found at: " + libProjPath);
                EditorUtility.DisplayDialog(Strings.LibProjNotFound, Strings.LibProjNotFoundBlurb, "OK");
                return;
            }
            
            // check android support library path
            if (!System.IO.File.Exists(libSupportPath))
            {
                Debug.LogError("Android support library not found at: " + libSupportPath);
                EditorUtility.DisplayDialog(Strings.LibSupportNotFound, Strings.LibSupportNotFoundBlurb, "OK");
                return;
            }
            
            // create needed directories
            EnsureDirExists("Assets/Plugins");
            EnsureDirExists("Assets/Plugins/Android");
            
            // clear out the destination library project
            DeleteDirIfExists(libProjDestDir);
            
            // Copy Google Play Services library
            FileUtil.CopyFileOrDirectory(libProjPath, libProjDestDir);
            
            // Copy Android Support Library
            File.Copy(libSupportPath, libSupportDest, true);
            
            // Fix android manifest
            string manifestFile = "Assets/Plugins/Android/CrossPromotion/AndroidManifest.xml";
            string manifestText = ReadFile(manifestFile);
            string newManifestText = manifestText.Replace("<!--${google.play.services.meta}-->", 
                                                          "<meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
            WriteFile(manifestFile, newManifestText);
            
            // refresh assets, and we're done
            AssetDatabase.Refresh();
            EditorUtility.DisplayDialog("Success", Strings.SetupComplete, "OK");
        }

        private static void EnsureDirExists(string dir)
        {
            dir = dir.Replace("/", System.IO.Path.DirectorySeparatorChar.ToString());
            if (!System.IO.Directory.Exists(dir))
            {
                System.IO.Directory.CreateDirectory(dir);
            }
        }
        
        private static void DeleteDirIfExists(string dir)
        {
            if (System.IO.Directory.Exists(dir))
            {
                System.IO.Directory.Delete(dir, true);
            }
        }

        #region Android SDK helpers
        
        private static string GetAndroidSdkPath()
        {
            string sdkPath = EditorPrefs.GetString("AndroidSdkRoot");
            if (sdkPath != null && (sdkPath.EndsWith("/") || sdkPath.EndsWith("\\")))
            {
                sdkPath = sdkPath.Substring(0, sdkPath.Length - 1);
            }
            return sdkPath;
        }
        
        private static bool HasAndroidSdk()
        {
            string sdkPath = GetAndroidSdkPath();
            return sdkPath != null && sdkPath.Trim() != "" && System.IO.Directory.Exists(sdkPath);
        }
        
        #endregion

        #region Helpers
        
        private static string FixSlashes(string path)
        {
            return path.Replace("/", System.IO.Path.DirectorySeparatorChar.ToString());
        }
        
        private static string ReadFile(string filePath)
        {
            filePath = FixSlashes(filePath);
            if (!File.Exists(filePath))
            {
                Alert("Plugin error: file not found: " + filePath);
                return null;
            }
            StreamReader sr = new StreamReader(filePath);
            string body = sr.ReadToEnd();
            sr.Close();
            return body;
        }
        
        private static void WriteFile(string file, string body)
        {
            file = FixSlashes(file);
            StreamWriter wr = new StreamWriter(file, false);
            wr.Write(body);
            wr.Close();
        }
        
        private static void Alert(string s)
        {
            Alert("Error", s);
        }
        
        private static void Alert(string title, string s)
        {
            EditorUtility.DisplayDialog(title, s, "OK");
        }
        
        #endregion

        #region Strings
        
        static class Strings
        {
            public const string Title = "Google Advertising Identifier - Android Configuration";
            public const string Blurb = "To configure Google Play Services SDK in this project click on the Setup button.";
            public const string SdkNotFound = "Android SDK Not found";
            public const string SdkNotFoundBlurb = "The Android SDK path was not found. " +
                "Please configure it in the Unity preferences window (under External Tools).";
            public const string LibProjNotFound = "Google Play Services Library Project Not Found";
            public const string LibProjNotFoundBlurb = "Google Play Services library project " +
                "could not be found your SDK installation. Make sure it is installed (open " +
                    "the SDK manager and go to Extras, and select Google Play Services).";
            public const string LibSupportNotFound = "Android Support Library Not Found";
            public const string LibSupportNotFoundBlurb = "Android Support Library " +
                "could not be found your SDK installation. Make sure it is installed (open " +
                    "the SDK manager and go to Extras, and select Android Support Library).";
            public const string LibProjVerNotFound = "The version of your copy of the Google Play " +
                "Services Library Project could not be determined. Please make sure it is " +
                    "at least version {0}. Continue?";
            public const string LibProjVerTooOld = "Your copy of the Google Play " +
                "Services Library Project is out of date. Please launch the Android SDK manager " +
                    "and upgrade your Google Play Services bundle to the latest version (your version: " +
                    "{0}; required version: {1}). Proceeding may cause problems. Proceed anyway?";
            public const string SetupComplete = "Google Advertising Identifier configured successfully.";
        }
        
        #endregion
    }
}
