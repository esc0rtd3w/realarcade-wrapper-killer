using UnityEngine;
using UnityEditor;
using UnityEditor.Callbacks;

using System.IO;
using System.Collections;
using System.Collections.Generic;

using GPN.PlistCS;

namespace GPN
{
    public class BuildPostprocessor
    {
        [PostProcessBuild]
        public static void OnPostprocessBuild(BuildTarget target, string pathToBuiltProject)
        {
            string targetName = target.ToString();
            if (targetName == "iOS" || targetName == "iPhone")
            {
                OnPostprocessIOSBuild(pathToBuiltProject);
            }
        }

        internal static void OnPostprocessIOSBuild(string pathToBuiltProject)
        {
            string plistPath = Path.Combine(pathToBuiltProject, "Info.plist");
            if (!File.Exists(plistPath))
            {
                Debug.LogWarning("Can't resolve property list path: " + plistPath + ". GPN SDK might not work correctly on iOS 9 devices");
                return;
            }

            IDictionary<string, object> plist = Plist.readPlist(plistPath) as IDictionary<string, object>;
            if (plist == null)
            {
                Debug.LogWarning("Can't read property list: " + plistPath + ". GPN SDK might not work correctly on iOS 9 devices");
                return;
            }

            AddSecurityExceptionEntries(plist);

            File.Copy(plistPath, plistPath + ".bak");
            Plist.writeXml(plist, plistPath);
        }

        static void AddSecurityExceptionEntries(IDictionary<string, object> plist)
        {
            string xml = @"
                <plist version=""1.0"">
                    <dict>
                        <key>NSExceptionDomains</key>
                        <dict>
                            <key>gamehouse.com</key>
                            <dict>
                                <key>NSIncludesSubdomains</key>
                                <true/>
                                <key>NSTemporaryExceptionAllowsInsecureHTTPLoads</key>
                                <true/>
                                <key>NSTemporaryExceptionMinimumTLSVersion</key>
                                <string>TLSv1.1</string>
                            </dict>
                        </dict>
                    </dict>
                </plist>";

            plist.Add("NSAppTransportSecurity", Plist.readPlistSource(xml));
        }
    }
}
