//  Builder.ExportApps.cs
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

using UnityEngine;
using UnityEditor;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace GPN
{
    public static partial class Builder
    {
        private static readonly string ScenePath = "Assets/Scene.unity";

        [MenuItem("File/Integrate")]
        static void IntegratePlugin()
        {
            OpenScene();
            RemoveOldObjects();
            AddPluginObjects();
            SaveScene();
        }

        static void OpenScene()
        {
            EditorApplication.OpenScene(ScenePath);
        }

        static void RemoveOldObjects()
        {
            // list old objects
            IList<GameObject> oldObjects = ListGameObjects(delegate(GameObject obj)
            {
                return obj.name.Contains("CrossPromotionPlugin");
            });

            foreach (GameObject obj in oldObjects)
            {
                GameObject.DestroyImmediate(obj);
            }
        }

        static void AddPluginObjects()
        {
            // instantiate plugin
            GameObject pluginPrefab = AssetDatabase.LoadAssetAtPath("Assets/Plugins/CrossPromotion/CrossPromotionPlugin.prefab", typeof(GameObject)) as GameObject;
            GameObject pluginObject = PrefabUtility.InstantiatePrefab(pluginPrefab) as GameObject;
            pluginObject.name = "CrossPromotionPlugin";

            // add sample script
            Type sampleScriptType = FindSampleScriptType();
            if (sampleScriptType == null)
            {
                throw new Exception("Can't find sample type script");
            }

            pluginObject.AddComponent(sampleScriptType);

            // set debug mode
            Type crossPromotionPluginType = TypeForName("CrossPromotionPlugin");
            if (crossPromotionPluginType == null)
            {
                throw new Exception("Can't resolve plugin type");
            }

            Component crossPromotionPluginComponent = pluginObject.GetComponent(crossPromotionPluginType);
            crossPromotionPluginType.GetField("debugMode").SetValue(crossPromotionPluginComponent, true);
        }

        static void SaveScene()
        {
            EditorApplication.SaveScene(ScenePath);
        }

        #region Helpers

        delegate bool GameObjectsFilter(GameObject obj);

        static IList<GameObject> ListGameObjects(GameObjectsFilter filter)
        {
            IList<GameObject> result = new List<GameObject>();

            GameObject[] objects = GameObject.FindObjectsOfType<GameObject>();
            foreach (GameObject obj in objects)
            {
                if (filter(obj))
                {
                    result.Add(obj);
                }
            }

            return result;
        }

        static Type FindSampleScriptType()
        {
            string[] ScriptsLookup = {
                "SampleDebug",
                "Sample",
                "GoogleMobileAdsDemoScript"
            };

            foreach (string scriptName in ScriptsLookup)
            {
                Type scriptType = TypeForName(scriptName);
                if (scriptType != null)
                {
                    return scriptType;
                }
            }

            return null;
        }

        static Type TypeForName(string name)
        {
            foreach (Assembly assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                foreach (Type type in assembly.GetTypes())
                {
                    if (type.Name == name)
                    {
                        return type;
                    }
                }
            }

            return null;
        }

        #endregion
    }
}
