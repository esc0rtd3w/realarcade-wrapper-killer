//  Sample.cs
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

using UnityEngine;
using System.Collections;

namespace GPN
{
    public class Sample : MonoBehaviour, ICrossPromotionPluginDelegate
    {
        private string statusMessage = "...";
        private GUIStyle statusStyle;

        void Start()
        {
            Plugin.Delegate = this;

            statusStyle = new GUIStyle();
            statusStyle.alignment = TextAnchor.UpperCenter;
            statusStyle.normal.textColor = Color.white;
        }

        void OnGUI()
        {
            int btnWidth = 150;
            int btnHeight = 40;
            int indent = 10;

            int btnX = (Screen.width - 2 * btnWidth - indent) / 2;
            int btnY = (Screen.height - btnHeight) / 2;

            if (GUI.Button(new Rect(btnX, btnY, btnWidth, btnHeight), "Request Interstitial"))
            {
                statusMessage = "Requesting...";
                Plugin.StartRequestingInterstitials();
            }

            btnX += btnWidth + indent;

            if (GUI.Button(new Rect(btnX, btnY, btnWidth, btnHeight), "Present Interstitial"))
            {
                statusMessage = "Presenting...";
                CrossPromotionResult result = Plugin.PresentInterstitial();
                if (result != CrossPromotionResult.Presented)
                {
                    statusMessage = "Not presented";
                }
            }

            int labelWidth = 200;
            int labelHeight = 30;
            int labelX = (Screen.width - labelWidth) / 2;
            int labelY = btnY + btnHeight + indent;
            GUI.Label(new Rect(labelX, labelY, labelWidth, labelHeight), statusMessage, statusStyle);
        }

        #region ICrossPromotionPluginDelegate

        public void OnInterstitialReceived(CrossPromotionPlugin plugin)
        {
            statusMessage = "Received";
        }

        public void OnInterstitialFailed(CrossPromotionPlugin plugin)
        {
            statusMessage = "Failed";
        }

        public void OnInterstitialOpened(CrossPromotionPlugin plugin)
        {
            statusMessage = "...";
        }

        public void OnInterstitialClosed(CrossPromotionPlugin plugin)
        {
            statusMessage = "...";
        }

        #endregion

        #region Properties

        public CrossPromotionPlugin Plugin
        {
            get { return CrossPromotionPlugin.Instance; }
        }

        #endregion
    }
}
