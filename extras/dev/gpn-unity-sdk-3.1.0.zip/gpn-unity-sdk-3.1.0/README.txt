# GameHouse Promotion Network SDK for Unity

The GameHouse Promotion Network lets you drive app installs with intelligence and control. You can participate in GPN by integrating this open source SDK into your Unity apps. At the moment only iOS and Android platforms are supported.
 
## Simple Steps

1. Signup for the GameHouse Promotion Network at http://partners.gamehouse.com/gpn/.
2. Register your apps to obtain a GPN App ID for each.
3. Upload a few marketing assets to enable your app to be promoted in other GPN apps.
4. Integrate this SDK into your app to start showing ads for other GPN apps.

## Android App Store Support

GPN currently supports the Google Play and Amazon Appstore. When you register your app to obtain a GPN Android App ID, you must select which store you will distribute in to ensure that only apps from the same app store are promoted. If you distribute your app in both stores, you will need to register it as two separate apps and obtain two separate GPN Android App IDs. We recommend generating separate Google and Amazon builds with the appropriate GPN Android App ID in each.

## Google Advertising ID

Beginning August 1, 2014, all Android apps submitted to the Google Play Store must use the new Google Advertising ID, in lieu of any other device identifiers, for any advertising purposes. GameHouse Promotion Network fully supports this and conforms with Google’s policies concerning collection and usage of this ID. Using Google Advertising ID requires using the Google Play services SDK 4.0+, so this is now a dependency for using GPN in your Android app distributed via Google Play. Note that it is NOT required for apps distributed via the Amazon Appstore. If you distribute in both, you need to do separate builds anyway.

## Important changes in version 3.0.0

*Some important changes have been made in version 3.0.0*  
* Plugin uses a prefab object instead of camera component. The main benefit of this switch is the ability to controll CrossPromotion lifecycle across different scenes in your project.  
* The 'CrossPromotionPlugin' script became a singleton. You don't need to request Main Camera component to access plugin behaviour.  
   ```
   CrossPromotionPlugin plugin = Camera.main.gameObject.GetComponent<CrossPromotionPlugin>();
   ```  
   becomes  
   ```
   CrossPromotionPlugin plugin = CrossPromotionPlugin.Instance;
   ```  
* Added an auto update feature. Now you can automatically stay up to date to the latest changes in the SDK.

## Integration Instructions

1. Unpack the SDK package zip archive.
2. Import CrossPromotion/crosspromotion.unitypackage into your project (Assets > Import Package > Custom Package...).  
3. Drag&Drop `Assets/Plugins/CrossPromotion/CrossPromotionPlugin.prefab` into your startup scene's object hierarchy.  
4. Select `CrossPromotionPlugin` game object and set your iOS/Android App Ids you received after signing up for the GameHouse Promotion Network, or “0” to see the test promotions.
   * *Android only*: Setup Google Play Services:
     * Install Google Play Services SDK: http://developer.android.com/google/play-services/setup.html#Install
     * Use Editor menu: Window ▶ GameHouse Cross Promotion ▶ Android setup... 
     * *Important*: if you use any other native plugins with Google Play Services SDK support - you may experience build time conflicts. To resolve the issue try to remove Assets->Plugins->Android->google-play-services_lib from you project and rebuild.
5. Create a new C# Script and add it to the `CrossPromotionPlugin` game object:
  
        using UnityEngine;
        using System.Collections;
        using CrossPromotion;
        
        public class Test : MonoBehaviour, ICrossPromotionPluginDelegate {
          ... 
          void Start () {
            Plugin.Delegate = this;
          }
          ...
          #region ICrossPromotionPluginDelegate
          
          // Interstitial ad is received: it’s safe to present it now
          public void OnInterstitialReceived(CrossPromotionPlugin plugin) {
            Debug.Log("Interstitial received");
          }
          
          // Interstitial ad failed to receive
          public void OnInterstitialFailed(CrossPromotionPlugin plugin) {
            Debug.LogError("Interstitial failed");
          }
          
          // Interstitial ad presented a modal view: you can pause your game here
          public void OnInterstitialOpened(CrossPromotionPlugin plugin) {
            Debug.Log("Interstitial opened");
          }
          
          // Interstitial ad closed a modal view: you can resume your game here
          public void OnInterstitialClosed(CrossPromotionPlugin plugin) {
            Debug.Log("Interstitial closed");
          }
          
          #endregion
          ...
          #region CrossPromotion helper
          
          public void StartRequestingInterstitials() {
            Plugin.StartRequestingInterstitials();
          }
          
          public void PresentInterstitial() {
            CrossPromotionResult result = Plugin.PresentInterstitial();
            if (result != CrossPromotionResult.Presented) {
              Debug.Log("Interstitial not presented");
            }
          }
          
          private CrossPromotionPlugin Plugin {
            get { return CrossPromotionPlugin.Instance; }
          }
          
          #endregion
          ...
        }
  
6. Call StartRequestingInterstitials method to start requesting interstitial ads.  
   **Note**: you should call StartRequestingInterstitials only once. The interstitial rotation is handled automatically by the SDK. Each time a new interstitial is received the ICrossPromotionPluginDelegate’s OnInterstitialReceived is called. You only need to call StartRequestingInterstitials if an error occurred and OnInterstitialFailed was called.

7. Once ICrossPromotionPluginDelegate’s OnInterstitialReceived method is called it’s safe to present an interstitial ad with PresentInterstitial method.

## GoogleAdMob Instructions

Unity does not support Google AdMob Mediation out of the box. So you need to integrate a 3rd party plugin in order to serve ads into your application. One of the possible solutions is "Google Mobile Ads SDK Plugins" project: https://github.com/googleads/googleads-mobile-plugins

1. Follow the Integration Instructions steps 1-4 (before adding a custom script)
2. Use the AdMob site to setup your iOS mediation placement (if any).
3. Add a Custom Event with the following params:  
   Label: GPN Custom Event  
   Class Name: CPCustomEventInterstitial
4. Use the AdMob site to setup your Android mediation placement (if any).
5. Add a Custom Event with the following params:  
   Label: GPN Custom Event  
   Class Name: com.gamehouse.crosspromotion.admob.GPNEventInterstitial

## Ad Positions
If you want to define different ad behavior for different points in your game, you can include an optional params dictionary when calling "present" method to pass a "position" param. For example:
    
      IDictionary<string, string> paramsDict = new Dictionary<string, string>();
      paramsDict["position"] = "<position_here>";
      CrossPromotionResult result = Plugin.PresentInterstitial(paramsDict);
      if (result != CrossPromotionResult.Presented) {
        ...
      }

Currently, we recognize only three position values:

* startup
* interstitial
* trial-end

Contact us if you want to define additional positions.

## iOS-specific Instructions

1. Link the following frameworks with your generated project:

        UIKit
        Foundation
        CoreGraphics
        SystemConfiguration
        CFNetwork
        Security
        CoreTelephony: set to "Optional" for pre iOS 4.0 targets
        StoreKit: set to "Optional" for pre iOS 6.0 targets
        AdSupport: set to "Optional" for pre iOS 6.0 targets
        WebKit: set to "Optional" for pre iOS 8.0 targets

2. Set “iOS Deployment Target” to 5.0 or later.

## Sample Apps
The SDK includes a sample app at /Samples/CrossPromotionSample and AdMob sample at /Samples/CrossPromotionAdMobSample

## More info
For more info on the platform specific features check native SDKs for iOS and Android.

# Thanks for using the GameHouse Promotion Network! Contact us if you have any questions or feedback.
