# GameHouse Promotion Network Native Extension for Adobe AIR

The GameHouse Promotion Network lets you drive app installs with intelligence and control. You can participate in GPN by integrating this Native Extension into your Adobe AIR Apps for iOS and Android.

## Simple Steps

1. Signup for the GameHouse Promotion Network at http://partners.gamehouse.com/gpn/.
2. Register your apps to obtain a GPN App ID for each target platform.
3. Upload a few marketing assets to enable your app to be promoted in other GPN apps.
4. Integrate this SDK into your app to start showing ads for other GPN apps.

## Google Advertising ID

Beginning August 1, 2014, all Android apps submitted to the Google Play Store must use the new Google Advertising ID, in lieu of any other device identifiers, for any advertising purposes. GameHouse Promotion Network fully supports this and conforms with Google’s policies concerning collection and usage of this ID. Using Google Advertising ID requires using the Google Play services SDK 4.0+, so this is now a dependency for using GPN in your Android app distributed via Google Play. Note that it is NOT required for apps distributed via the Amazon Appstore. If you distribute in both, you need to do separate builds anyway.

## Integration Instructions

### Preface

This extension requires Adobe AIR 4.0 or higher, available from [here](http://www.adobe.com/devnet/air/air-sdk-download.html).

Before you begin, include the `com.gamehouse.extensions.GameHouse.ane` Library in your project:

**Debug and Release**

GPN sdk package contains four extension folders:
* extension_debug
* extension_release  
* extension_debug_no_google_play
* extension_release_no_google_play

It's recommended to include ANE file from the 'release' folder in your final project. However you may use a 'debug' version while developing your project to be able to see more console output from GPN.

**Flash Professional:**

1. Create a new AIR mobile project.
2. Select File > Publish Settings.
3. Select the ActionScript Settings icon.
4. Select the Library Path tab.
5. Press the Browse for Native Extension (ANE) File button and select the `com.gamehouse.extensions.GameHouse.ane` file.
6. Tick the box for 'Manually manage permissions and manifest additions for this app.' 

**Flash Builder:**

1. Go to Project Properties.
2. Select ActionScript Build Path.
3.  Select the Native Extensions tab.
3. Click Add ANE... and navigate to the `com.gamehouse.extensions.GameHouse.ane` file.
4. Select ActionScript Build Packaging > Google Android (or iOS, if Using the iOS Version)
5. Select the Native Extensions tab, and click the Package checkbox next to the extension

### Integration

1. Update your application descriptor (required for Android targets only):

		<android>
		<manifestAdditions><![CDATA[
			<manifest android:installLocation="auto">
				<uses-permission android:name="android.permission.INTERNET"/>
				<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
				<uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
				<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
				<uses-permission android:name="android.permission.GET_TASKS"/>
				<application>
					<!-- For Google Play Services -->
					<meta-data
						android:name="com.google.android.gms.version"
						android:value="@integer/google_play_services_version" />
					<activity
						android:name="com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialActivity"
						android:configChanges="orientation|screenSize"
						android:theme="@android:style/Theme.Translucent.NoTitleBar.Fullscreen" />	
				</application>
			</manifest>			
		]]></manifestAdditions>
		</android>

2. Update your application descriptor (required for iOS targets only):

		<iPhone>
		    <InfoAdditions> 
		        <![CDATA[ 
		          <key>NSAppTransportSecurity</key>
		          <dict>
		              <key>NSExceptionDomains</key>
		              <dict>
		                  <key>gamehouse.com</key>
		                  <dict>
		                      <key>NSIncludesSubdomains</key>
		                      <true/>
		                      <key>NSTemporaryExceptionAllowsInsecureHTTPLoads</key>
		                      <true/>
		                      <key>NSTemporaryExceptionMinimumTLSVersion</key>
		                      <string>TLSv1.1</string>
		                  </dict>
		              </dict>
		          </dict>
		     ]]>
		    </InfoAdditions>
		</iPhone>

3. Import the API Classes:

		import com.gamehouse.extensions*;
		import com.gamehouse.extensions.events.*;

4. At the start of your application, initialize the extension by calling `GameHouse.create()` with your app ID.  If you are targeting both iOS and Android from the same code, enter your iOS id first, followed by your Android id. You can use the `GameHouse.isSupported()` function to check if the current platform supports the extension (iOS or Android.):

		if(GameHouse.isSupported())
		{
			GameHouse.create("your_ios_id","your_android_id");
		}
		else
		{
			trace("supported on on iOS And Android only.");
		}

5. Add event listeners:

		/** Interstitial Ad is received: it's safe to present it now. */
		GameHouse.ads.addEventListener(GameHouseEvent.AD_RECEIVED, onAdEvent);

		/** An Interstitial Ad is failed to receive. */
		GameHouse.ads.addEventListener(GameHouseEvent.AD_FAILED, onAdEvent);

		/** Interstitial Ad presented full screen modal view. You can pause your game here. */
		GameHouse.ads.addEventListener(GameHouseEvent.AD_OPENED, onAdEvent);

		/** Interstitial Ad hid full screen modal view. You can resume your game here. */
		GameHouse.ads.addEventListener(GameHouseEvent.AD_CLOSED, onAdEvent);
		
		/** iOS only: Dispatched when an ad has been kill on a low memory warning. By default
		the ad serving stops and resumes when more free memory is available. */
		GameHouse.ads.addEventListener(GameHouseEvent.AD_DESTROYED_LOW_MEMORY, adDestoryedLowMemoryCallback);

		/** Android only: Interstitial Ad will leave the application. */
		GameHouse.ads.addEventListener(GameHouseEvent.LEAVE_APPLICATION, onAdEvent);

6. Start requesting interstitial ad loads.  After this request, ads will begin loading on a regular cycle, and `GameHouseEvent.AD_RECEIVED` or `GameHouseEvent.AD_FAILED` will be dispatched on each ad's response. :

		GameHouse.ads.beginRequestingInterstitialAds();

7. Present an interstitial ad.

	GameHouse currently supports three `GameHousePosition` values, to pass as the first parameter representing the position of the ad's appearence: `GameHousePosition.STARTUP`, `GameHousePosition.INTERSTITIAL`, or `GameHousePosition.TRIAL_END`.

	  The return value will be one of `GameHouseAdResult.PRESENTED, GameHouseAdResult.NOT_PRESENTED`,  `GameHouseAdResult.NOT_PRESENTED_FORBIDS_POSITION` or `GameHouseAdResult.FAILED`, depending on the result.  

		If the value is any other than `GameHouseAdResult.PRESENTED`, no ad will be displayed at this time and no further events will be dispatched.  Otherwise, the ad will be shown, and `GameHouseEvent.AD_OPENED` or `GameHouseEvent.AD_CLOSED` will be dispatched when the ad is shown and dismissed, respectively. :

			var adResult:String=GameHouse.ads.presentInterstitialAd(GameHousePosition.INTERSTITIAL);
			if (adResult==GameHouseAdResult.PRESENTED)
			{
				trace("Ad displayed!");
			}
			else
			{
				trace("Ad not shown: "+adResult);
			}

8. To stop new ads from being loaded, call `cancelInterstitialRequest()`:

		GameHouse.ads.cancelInterstitialRequest();

## Android Google Play Services SDK confilicts
You may experience build time errors if your app uses any other extension with Google Play Services SDK included. To solve the issue link extension from "extension_*_no_google_play" folder.

## Facebook SDK support
If you use Facebook SDK 4.x in your app you can also benefit from Facebook's [Custom Audiences for Mobile Apps](https://developers.facebook.com/docs/ads-for-apps/custom-audiences-for-mobile-apps). The GPN SDK detects Facebook SDK integration and requests an app user ID automatically. No additional steps needed.

## Sample App

A sample Document Class (CrossPromotionSample.as) and application descriptor (CrossPromotionSample-app.xml) can be found in the example subdirectory.

## Answer to Common Questions

**“How do I use the GameHouseExample.as Document Class in Flash Professional?”**

1.	First, create the application and add the extension by following the Preface.
2.	Copy and paste `GameHouseExample.as` into the same folder as your .fla.  Do not copy and paste its contents on to the timeline.  That will not work.  
3.	Change the app ID inside `GameHouseExample.as` to your own app ID.
4.	In Flash properties, under 'Document Class', type `GameHouseExample`
5.	Build and install the application.

**“How do I install a newer version of the AIR SDK (3.5 or higher) in Flash Professional?”**

 You can download the latest AIR SDK from [here](http://www.adobe.com/devnet/air/air-sdk-download.html).  If you have already installed AIR 3.5 or higher, you may skip this step.  Otherwise, follow the instructions below:

1.	Unzip the AIR 3.5 or later SDK package to a location on your hard drive.
2.	Launch Flash Professional.
3.	Select Help > Manage AIR SDK...
4.	Press the Plus (+) Button and navigate to the location of the unzipped AIR SDK
5.	Press OK
6.	Select File > Publish Settings
7.	Select the latest AIR SDK for iOS from the 'Target' Dropdown menu

**“How do I install a newer version of the AIR SDK (3.5 or higher) in Flash Builder?”**

You can download the latest AIR SDK from [here](http://www.adobe.com/devnet/air/air-sdk-download.html).  If you have already installed AIR 3.5 or higher, you may skip this step.  You can find Adobe's latest instructions for updating Flash Builder AIR SDKs at this [link](http://helpx.adobe.com/flash-builder/kb/overlay-air-sdk-flash-builder.html). 

**"Why do ads reappear after being closed?"**

You are attempting to display the ad inside the `GameHouseEvent.AD_RECEIVED` event listener.  However, this listener will fire repeatedly as ads are loaded in the background after your first call to `beginRequestingInterstitialAds()`.  Instead of calling `GameHouse.ads.presentInterstitialAd()` inside the callback, execute it at the moment you are ready to present an ad.

To stop ads from reloading in the background, call `GameHouse.ads.cancelInterstitialRequest()`.


# Thanks for using the GameHouse Promotion Network! Contact us if you have any questions or feedback.

