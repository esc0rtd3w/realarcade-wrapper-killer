** INSTRUCTIONS **

There are two documents, one for domestic ACH payments (for those partners in the U.S.) and one for foreign wire payments (for those partners outside of the U.S.).  Please complete the appropriate form based on your company's location and submit the form to your RealGames producer or portfolio manager.

We deduct international wire transfer fees from royalty statements. This fee is typically $20-25 USD per transfer.
