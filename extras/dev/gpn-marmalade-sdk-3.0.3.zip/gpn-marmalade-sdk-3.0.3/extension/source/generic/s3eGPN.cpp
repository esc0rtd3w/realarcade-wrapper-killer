/*
Generic implementation of the s3eGPN extension.
This file should perform any platform-indepedentent functionality
(e.g. error checking) before calling platform-dependent implementations.
*/

/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */

#include "s3eGPN_internal.h"

static const char * const kCPWrapperVersion = "3.0.3";

s3eResult s3eGPNInit()
{
    //Add any generic initialisation code here
    return s3eGPNInit_platform();
}

void s3eGPNTerminate()
{
    //Add any generic termination code here
    s3eGPNTerminate_platform();
}

s3eResult cpInitialize(const char** appIDs, s3eBool debugMode)
{
	return cpInitialize_platform(kCPWrapperVersion, appIDs, debugMode);
}

s3eResult cpStartRequestingInterstitials()
{
	return cpStartRequestingInterstitials_platform();
}

int cpPresentInterstitial(const char* argString, int* outResult)
{
	return cpPresentInterstitial_platform(argString, outResult);
}

int cpStopRequestingInterstitials()
{
	return cpStopRequestingInterstitials_platform();
}

s3eResult cpInterstitialDestroy()
{
	return cpInterstitialDestroy_platform();
}

s3eResult cpSetShouldKillOnLowMemory(s3eBool flag)
{
	return cpSetShouldKillOnLowMemory_platform(flag);
}

s3eResult cpDebugGetAppId(char* buffer)
{
	return cpDebugGetAppId_platform(buffer);
}

s3eResult cpDebugGetBaseURL(char* buffer)
{
	return cpDebugGetBaseURL_platform(buffer);
}

s3eResult cpDebugSetAppId(const char* appId)
{
	return cpDebugSetAppId_platform(appId);
}

s3eResult cpDebugSetBaseURL(const char* baseURL)
{
	return cpDebugSetBaseURL_platform(baseURL);
}
