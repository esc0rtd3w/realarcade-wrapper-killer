//
//  gpn_helper.cpp
//  CrossPromotionAppDebug
//
//  Created by Alex Lementuev on 3/12/14.
//
//

#include <string.h>

#include "gpn_helper.h"

//-----------------------------------------------------------------------------

static int32 gpnReceivedCallback(void* systemData, void* userData)
{
    gpnOnReceived();
    return S3E_RESULT_SUCCESS;
}

static int32 gpnFailedCallback(void* systemData, void* userData)
{
    gpnOnFailed();
    return S3E_RESULT_SUCCESS;
}

static int32 gpnOpenedCallback(void* systemData, void* userData)
{
    gpnOnOpened();
    return S3E_RESULT_SUCCESS;
}

static int32 gpnClosedCallback(void* systemData, void* userData)
{
    gpnOnClosed();
    return S3E_RESULT_SUCCESS;
}

static int32 gpnKilledLowMemCallback(void* systemData, void* userData)
{
    gpnOnKilledLowMemory();
    return S3E_RESULT_SUCCESS;
}

//-----------------------------------------------------------------------------

s3eBool gpnHelperInit(const char **appIDs, s3eBool debugMode)
{
    if (s3eGPNAvailable())
    {
        cpInitialize(appIDs, debugMode);
        
        s3eGPNRegister(S3E_GPN_CALLBACK_RECEIVED,          gpnReceivedCallback,     NULL);
        s3eGPNRegister(S3E_GPN_CALLBACK_FAILED,            gpnFailedCallback,       NULL);
        s3eGPNRegister(S3E_GPN_CALLBACK_OPENED,            gpnOpenedCallback,       NULL);
        s3eGPNRegister(S3E_GPN_CALLBACK_CLOSED,            gpnClosedCallback,       NULL);
        s3eGPNRegister(S3E_GPN_CALLBACK_KILLED_ON_LOW_MEM, gpnKilledLowMemCallback, NULL);
        
        return S3E_TRUE;
    }
    
    return S3E_FALSE;
}

s3eBool gpnHelperStartRequest()
{
    return S3E_RESULT_SUCCESS == cpStartRequestingInterstitials();
}

s3eBool gpnHelperCancelRequest()
{
    return S3E_RESULT_SUCCESS == cpStopRequestingInterstitials();
}

s3eGPNInterstitialResult gpnHelperPresent(const char *params)
{
    if (s3eGPNAvailable())
    {
        const char* paramsStr = params && strlen(params) > 0 ? params : NULL;
        int interstitialResult;
        if (S3E_RESULT_SUCCESS == cpPresentInterstitial(paramsStr, &interstitialResult))
        {
            return (s3eGPNInterstitialResult)interstitialResult;
        }
        return S3E_GPN_INTERSTITIAL_RESULT_NOT_PRESENTED;
    }
    
    return S3E_GPN_INTERSTITIAL_RESULT_PLATFORM_NOT_SUPPORTED;
}

s3eBool gpnHelperDestroy()
{
    if (s3eGPNAvailable())
    {
        s3eGPNUnRegister(S3E_GPN_CALLBACK_RECEIVED,          gpnReceivedCallback);
        s3eGPNUnRegister(S3E_GPN_CALLBACK_FAILED,            gpnFailedCallback);
        s3eGPNUnRegister(S3E_GPN_CALLBACK_OPENED,            gpnOpenedCallback);
        s3eGPNUnRegister(S3E_GPN_CALLBACK_CLOSED,            gpnClosedCallback);
        s3eGPNUnRegister(S3E_GPN_CALLBACK_KILLED_ON_LOW_MEM, gpnKilledLowMemCallback);
        
        cpInterstitialDestroy();
        
        return S3E_TRUE;
    }
    
    return S3E_FALSE;
}