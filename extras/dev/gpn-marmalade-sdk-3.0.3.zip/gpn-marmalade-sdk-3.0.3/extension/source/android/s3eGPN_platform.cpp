//
//  s3eGPN_platform.cpp
//  s3eGPN_platform
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */
#include "s3eGPN_internal.h"

#include "s3eEdk.h"
#include "s3eEdk_android.h"
#include <jni.h>
#include "IwDebug.h"

static void gpn_NotifyInterstitialAdReceive(JNIEnv *, jobject);
static void gpn_NotifyInterstitialAdFail(JNIEnv *, jobject, jstring);
static void gpn_NotifyInterstitialAdOpen(JNIEnv *, jobject);
static void gpn_NotifyInterstitialAdClose(JNIEnv *, jobject);
static void gpn_NotifyInterstitialAdLeaveApplication(JNIEnv *, jobject);

static int gpn_DevicePauseCallback(void* systemData, void* userData);
static int gpn_DeviceResumeCallback(void* systemData, void* userData);

static jobject g_Obj;
static jmethodID g_cpInitialize;
static jmethodID g_cpStartRequestingInterstitials;
static jmethodID g_cpPresentInterstitial;
static jmethodID g_cpStopRequestingInterstitials;
static jmethodID g_cpInterstitialDestroy;
static jmethodID g_cpDebugGetAppId;
static jmethodID g_cpDebugGetBaseURL;
static jmethodID g_cpDebugSetAppId;
static jmethodID g_cpDebugSetBaseURL;
static jmethodID g_cpOnPause;
static jmethodID g_cpOnResume;

static const int kAppIdBufferSize = 128;
static const int kBaseUrlBufferSize = 512;

s3eResult s3eGPNInit_platform()
{
    // Get the environment from the pointer
    JNIEnv* env = s3eEdkJNIGetEnv();
    jobject obj = NULL;
    jmethodID cons = NULL;
    
    const JNINativeMethod nativeMethodDefs[] =
    {
        { "notifyInterstitialAdReceive", "()V", (void *)&gpn_NotifyInterstitialAdReceive },
        { "notifyInterstitialAdFail", "(Ljava/lang/String;)V", (void *)&gpn_NotifyInterstitialAdFail },
        { "notifyInterstitialAdOpen", "()V", (void *)&gpn_NotifyInterstitialAdOpen },
        { "notifyInterstitialAdClose", "()V", (void *)&gpn_NotifyInterstitialAdClose },
        { "notifyInterstitialAdLeaveApplication", "()V", (void *)&gpn_NotifyInterstitialAdLeaveApplication },
    };
    
    // Get the extension class
    jclass cls = s3eEdkAndroidFindClass("s3eGPN");
    if (!cls)
        goto fail;

    // Get its constructor
    cons = env->GetMethodID(cls, "<init>", "()V");
    if (!cons)
        goto fail;

    // Construct the java class
    obj = env->NewObject(cls, cons);
    if (!obj)
        goto fail;

    // Get all the extension methods
    g_cpInitialize = env->GetMethodID(cls, "cpInitialize", "(Ljava/lang/String;Ljava/lang/String;Z)I");
    if (!g_cpInitialize)
        goto fail;

    g_cpStartRequestingInterstitials = env->GetMethodID(cls, "cpStartRequestingInterstitials", "()I");
    if (!g_cpStartRequestingInterstitials)
        goto fail;

    g_cpPresentInterstitial = env->GetMethodID(cls, "cpPresentInterstitial", "(Ljava/lang/String;[I)I"); // we send int[] instead of int*
    if (!g_cpPresentInterstitial)
        goto fail;

    g_cpStopRequestingInterstitials = env->GetMethodID(cls, "cpStopRequestingInterstitials", "()I");
    if (!g_cpStopRequestingInterstitials)
        goto fail;

    g_cpInterstitialDestroy = env->GetMethodID(cls, "cpInterstitialDestroy", "()I");
    if (!g_cpInterstitialDestroy)
        goto fail;

    g_cpDebugGetAppId = env->GetMethodID(cls, "cpDebugGetAppId", "([B)I"); // passing byte array to hold the return string
    if (!g_cpDebugGetAppId)
        goto fail;

    g_cpDebugGetBaseURL = env->GetMethodID(cls, "cpDebugGetBaseURL", "([B)I"); // passing byte array to hold the return string
    if (!g_cpDebugGetBaseURL)
        goto fail;

    g_cpDebugSetAppId = env->GetMethodID(cls, "cpDebugSetAppId", "(Ljava/lang/String;)I");
    if (!g_cpDebugSetAppId)
        goto fail;

    g_cpDebugSetBaseURL = env->GetMethodID(cls, "cpDebugSetBaseURL", "(Ljava/lang/String;)I");
    if (!g_cpDebugSetBaseURL)
        goto fail;
        
    env->RegisterNatives(cls, nativeMethodDefs, sizeof(nativeMethodDefs)/sizeof(nativeMethodDefs[0]));
    

    IwTrace(GPN, ("GPN init success"));
    g_Obj = env->NewGlobalRef(obj);
    env->DeleteLocalRef(obj);
    env->DeleteGlobalRef(cls);

    // Add any platform-specific initialisation code here
    return S3E_RESULT_SUCCESS;

fail:
    jthrowable exc = env->ExceptionOccurred();
    if (exc)
    {
        env->ExceptionDescribe();
        env->ExceptionClear();
        IwTrace(gpn, ("One or more java methods could not be found"));
    }
    return S3E_RESULT_ERROR;

}

void s3eGPNTerminate_platform()
{
    // Unregister suspend/resume callbacks
    s3eDeviceUnRegister(S3E_DEVICE_PAUSE, gpn_DevicePauseCallback);
    s3eDeviceUnRegister(S3E_DEVICE_UNPAUSE, gpn_DeviceResumeCallback);
}

s3eResult cpInitialize_platform(const char* version, const char** appIDs, s3eBool debugMode)
{
    const char* appId = appIDs[S3E_GPN_APP_ID_INDEX_ANDROID]; // not safe!
    if (appId == NULL)
    {
        IwTrace(gpn, ("Please, provide Android app ID"));
        return S3E_RESULT_ERROR;
    }
    
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring version_jstr = env->NewStringUTF(version);
    jstring appID_jstr = env->NewStringUTF(appId);
    return (s3eResult)env->CallIntMethod(g_Obj, g_cpInitialize, version_jstr, appID_jstr, debugMode);
}

s3eResult cpStartRequestingInterstitials_platform()
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    return (s3eResult)env->CallIntMethod(g_Obj, g_cpStartRequestingInterstitials);
}

int cpPresentInterstitial_platform(const char* argString, int* outResult)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring argString_jstr = env->NewStringUTF(argString);
    // we can't pass int pointer to the java code, so we'll create a local int array (size=0) and set the result there
    jintArray outArray = env->NewIntArray(1);
    int result = (int)env->CallIntMethod(g_Obj, g_cpPresentInterstitial, argString_jstr, outArray);
    if (result == S3E_RESULT_SUCCESS)
    {
        jint* data = env->GetIntArrayElements(outArray, 0);
        *outResult = *data;
        env->ReleaseIntArrayElements(outArray, data, 0);
    }
    
    return result;
}

int cpStopRequestingInterstitials_platform()
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    return (int)env->CallIntMethod(g_Obj, g_cpStopRequestingInterstitials);
}

s3eResult cpInterstitialDestroy_platform()
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    return (s3eResult)env->CallIntMethod(g_Obj, g_cpInterstitialDestroy);
}

s3eResult cpSetShouldKillOnLowMemory_platform(s3eBool flag)
{
    IwTrace(gpn, ("'cpSetShouldKillOnLowMemory' is not supported on Android"));
    return S3E_RESULT_ERROR;
}

s3eResult cpDebugGetAppId_platform(char* buffer)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    
    jbyteArray outArray = env->NewByteArray(kAppIdBufferSize);
    s3eResult result = (s3eResult)env->CallIntMethod(g_Obj, g_cpDebugGetAppId, outArray);
    if (result == S3E_RESULT_SUCCESS)
    {
        jbyte* data = env->GetByteArrayElements(outArray, 0);
        char *p = (char *)data;
        while (*buffer++ = *p++);
        env->ReleaseByteArrayElements(outArray, data, 0);
    }
    
    return result;
}

s3eResult cpDebugGetBaseURL_platform(char* buffer)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    
    jbyteArray outArray = env->NewByteArray(kBaseUrlBufferSize);
    s3eResult result = (s3eResult)env->CallIntMethod(g_Obj, g_cpDebugGetBaseURL, outArray);
    if (result == S3E_RESULT_SUCCESS)
    {
        jbyte* data = env->GetByteArrayElements(outArray, 0);
        char *p = (char *)data;
        while (*buffer++ = *p++);
        env->ReleaseByteArrayElements(outArray, data, 0);
    }
    
    return result;
}

s3eResult cpDebugSetAppId_platform(const char* appId)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring appId_jstr = env->NewStringUTF(appId);
    return (s3eResult)env->CallIntMethod(g_Obj, g_cpDebugSetAppId, appId_jstr);
}

s3eResult cpDebugSetBaseURL_platform(const char* baseURL)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    jstring baseURL_jstr = env->NewStringUTF(baseURL);
    return (s3eResult)env->CallIntMethod(g_Obj, g_cpDebugSetBaseURL, baseURL_jstr);
}

//---------------------------------------------------------------------------------

void gpn_NotifyInterstitialAdReceive(JNIEnv *evn, jobject obj)
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_RECEIVED);
}

void gpn_NotifyInterstitialAdFail(JNIEnv *evn, jobject obj, jstring message)
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_FAILED); // TODO: pass message
}

void gpn_NotifyInterstitialAdOpen(JNIEnv *evn, jobject obj)
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_OPENED);
}

void gpn_NotifyInterstitialAdClose(JNIEnv *evn, jobject obj)
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_CLOSED);
}

void gpn_NotifyInterstitialAdLeaveApplication(JNIEnv *evn, jobject obj)
{
    // TODO
}

int gpn_DevicePauseCallback(void* systemData, void* userData)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    return (int)env->CallIntMethod(g_Obj, g_cpOnPause);
}

int gpn_DeviceResumeCallback(void* systemData, void* userData)
{
    JNIEnv* env = s3eEdkJNIGetEnv();
    return (int)env->CallIntMethod(g_Obj, g_cpOnResume);
}

