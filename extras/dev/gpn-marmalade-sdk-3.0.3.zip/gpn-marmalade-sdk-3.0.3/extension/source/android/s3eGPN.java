//
//  s3eGPN.java
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */

import com.gamehouse.crosspromotion.CrossPromotion;
import com.gamehouse.crosspromotion.Global;
import com.gamehouse.crosspromotion.implementation.CrossPromotionImpl;
import com.gamehouse.crosspromotion.implementation.ServerApi;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdView.InterstitialResult;
import com.gamehouse.crosspromotion.implementation.ads.interstitial.InterstitialAdViewListener;
import com.gamehouse.crosspromotion.implementation.utils.Debug;
import com.ideaworks3d.marmalade.LoaderActivity;
import com.ideaworks3d.marmalade.LoaderActivitySlave;

import java.util.HashMap;
import java.util.Map;


class s3eGPN extends LoaderActivitySlave implements InterstitialAdViewListener
{
    private static final int S3E_RESULT_SUCCESS = 0; // The operation completed successfully
    private static final int S3E_RESULT_ERROR = 1;   // An error occurred during the operation

    private static final int PRESENT_RESULT_PRESENTED = 0;
    private static final int PRESENT_RESULT_NOT_PRESENTED = 1;
    private static final int PRESENT_RESULT_FAILED = 2;

    private Map<String, Object> initParams;

    public int cpInitialize(String version, String appID, boolean debugMode)
    {
        try
        {
            if (debugMode)
            {
                Debug.init(LoaderActivity.m_Activity);
            }

            ServerApi.wrapperName = "marmalade";
            ServerApi.wrapperVersion = version;

            CrossPromotion.initialize(LoaderActivity.m_Activity, appID);

            CrossPromotion.instance().onResume(); // This is a hack: normally this call should be made from Activity.onResume()

            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }

        return S3E_RESULT_ERROR;
    }

    public int cpStartRequestingInterstitials()
    {
        try
        {
            CrossPromotion.instance().startRequestingInterstitials(this);
            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }

        return S3E_RESULT_ERROR;
    }

    public int cpPresentInterstitial(String args, int[] out)
    {
        try
        {
            InterstitialResult result = CrossPromotion.instance().present(LoaderActivity.m_Activity, createMap(args));
            out[0] = result2Int(result);
            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }

        return S3E_RESULT_ERROR;
    }

    public int cpStopRequestingInterstitials()
    {
        try
        {
            CrossPromotion.instance().stopRequestingInterstitials();
            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }

        return S3E_RESULT_ERROR;
    }

    public int cpInterstitialDestroy()
    {
        try
        {
            CrossPromotion.destroy();
            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }

        return S3E_RESULT_ERROR;
    }

    public int cpDebugGetAppId(byte[] outArray)
    {
        try
        {
            copyBytes(Global.getAppId(), outArray);
            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }
        return S3E_RESULT_ERROR;
    }

    public int cpDebugGetBaseURL(byte[] outArray)
    {
        try
        {
            copyBytes(Global.getBaseURL(), outArray);
            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }
        return S3E_RESULT_ERROR;
    }

    public int cpDebugSetAppId(String appId)
    {
        try
        {
            Global.setAppId(appId);
            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }

        return S3E_RESULT_ERROR;
    }

    public int cpDebugSetBaseURL(String baseURL)
    {
        try
        {
            CrossPromotionImpl.setOverridenServerURL(baseURL);
            Global.setBaseURL(baseURL);
            return S3E_RESULT_SUCCESS;
        }
        catch (Exception e)
        {
            e.printStackTrace(); // TODO: better error handling
        }

        return S3E_RESULT_ERROR;
    }

    ////////////////////////////////////////////////////////////////
    // LoaderActivitySlave

    @Override
    protected void onPause()
    {
        CrossPromotion.instance().onPause();
    }

    @Override
    protected void onResume()
    {
        CrossPromotion.instance().onResume();
    }

    @Override
    protected void onDestroy()
    {
        CrossPromotion.destroy();
    }

    ////////////////////////////////////////////////////////////////
    // InterstitialAdViewListener

    @Override
    public void onInterstitialAdReceive(InterstitialAdView adView)
    {
        notifyInterstitialAdReceive();
    }

    @Override
    public void onInterstitialAdFail(InterstitialAdView adView, int code, String reason)
    {
        notifyInterstitialAdFail(reason);
    }

    @Override
    public void onInterstitialAdOpen(InterstitialAdView adView)
    {
        notifyInterstitialAdOpen();
    }

    @Override
    public void onInterstitialAdClose(InterstitialAdView adView)
    {
        notifyInterstitialAdClose();
    }

    @Override
    public void onInterstitialAdLeaveApplication(InterstitialAdView adView)
    {
        notifyInterstitialAdLeaveApplication();
    }

    @Override
    public Map<String, Object> createInterstitialAdParams()
    {
        return null;
    }

    private Map<String, Object> createMap(String args)
    {
        if (args != null)
        {
            Map<String, Object> map = new HashMap<String, Object>();

            String[] pairs = args.split("&");
            for (String pair : pairs)
            {
                String[] values = pair.split("=");
                Debug.assertion(values.length == 2);
                if (values.length == 2)
                {
                    String key = values[0];
                    String value = values[1];
                    map.put(key, value);
                }
            }

            return map;
        }

        return null;
    }

    ////////////////////////////////////////////////////////////////
    // Native interface

    public native void notifyInterstitialAdReceive();
    public native void notifyInterstitialAdFail(String message);
    public native void notifyInterstitialAdOpen();
    public native void notifyInterstitialAdClose();
    public native void notifyInterstitialAdLeaveApplication();

    ////////////////////////////////////////////////////////////////
    // Helpers

    private int result2Int(InterstitialResult result)
    {
        switch (result)
        {
            case Presented:
                return PRESENT_RESULT_PRESENTED;
            case NotPresented:
                return PRESENT_RESULT_NOT_PRESENTED;
            case Failed:
                return PRESENT_RESULT_FAILED;
        }

        return PRESENT_RESULT_FAILED;
    }

    private void copyBytes(String str, byte[] arr)
    {
        if (str == null)
            throw new IllegalArgumentException("'str' is null");

        if (arr == null)
            throw new IllegalArgumentException("'arr' is null");

        if (arr.length < str.length() + 1)
            throw new IllegalArgumentException("Array size (" + arr.length + ") is not enough to hold string bytes: '" + str + "'");

        int i;
        for (i = 0; i < str.length(); ++i)
        {
            arr[i] = (byte) str.charAt(i);
        }
        arr[i] = 0;
    }
}
