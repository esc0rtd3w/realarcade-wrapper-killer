//
//  gpn_helper.h
//  CrossPromotionAppDebug
//
//  Created by Alex Lementuev on 3/12/14.
//
//

#ifndef _gpn_helper__
#define _gpn_helper__

#include "s3eTypes.h"
#include "s3eGPN.h"

// \cond HIDDEN_DEFINES
S3E_BEGIN_C_DECL
// \endcond

// Interstitial ad is received: it’s safe to present it now.
extern void gpnOnReceived(void);

// Interstitial ad is failed to receive.
// NOTE: you should restart your request here after some timeout
extern void gpnOnFailed(void);

// Interstitial ad did present full screen modal view. You can pause your game here.
extern void gpnOnOpened(void);

// Interstitial ad did hide full screen modal view. You can resume your game here.
extern void gpnOnClosed(void);

// Interstitial ad was destroyed after receiving low memory warning.
// NOTE: you should restart your request here after some timeout
extern void gpnOnKilledLowMemory(void);

//-----------------------------------------------------------------------------

// Call this method when application starts. Returns S3E_TRUE if call succeed
// and gpn is initialized.
//
// You can set your app ids the following way:
//
//      const char* appIds[GPN_APP_ID_INDEX_MAX] = { NULL };
//      appIds[GPN_APP_ID_INDEX_IOS]       = "your_ios_app_id";
//      appIds[GPN_APP_ID_INDEX_ANDROID]   = "your_android_app_id";
//
// NOTE: if you target only one platform - set only one app id. For example,
// if you target iOS only:
//
//      const char* appIds[GPN_APP_ID_INDEX_MAX] = { NULL };
//      appIds[GPN_APP_ID_INDEX_IOS] = "your_ios_app_id";
//
// IMPORTANT: don't forget to set 'debugMode' to S3E_FALSE in release build.
s3eBool gpnHelperInit(const char **appIds, s3eBool debugMode);

// Starts requesting interstitial ads from the server. Returns S3E_TRUE if call succeed
// and request is started.
//
// Note: you should call gpnHelperStartRequest() only once.
// The interstitial rotation is handled automatically by the SDK. Each time a new
// interstitial is received the gpnOnReceived() is called.
// You only need to call gpnHelperStartRequest() if the SDK received a memory
// warning (and freed the memory occupied by interstitial) or if an error occurred
// and gpnOnFailed() was called.
s3eBool gpnHelperStartRequest(void);

// Cancels requesting interstitial ads. Returns S3E_TRUE if call succeed.
s3eBool gpnHelperCancelRequest(void);

// Call the "present" method whenever it's appropriate to present an interstitial ad
// (e.g. during a level break). The ad will display only if it is fully preloaded.
// It’s safe to present an interstitial gpnOnReceived() is called
s3eGPNInterstitialResult gpnHelperPresent(const char *params);

// Destroys gpn instance
// NOTE: call this method when your app is about to quit
s3eBool gpnHelperDestroy(void);

S3E_END_C_DECL

#endif // _gpn_helper__
