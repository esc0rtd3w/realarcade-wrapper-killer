/*
 * Internal header for the s3eGPN extension.
 *
 * This file should be used for any common function definitions etc that need to
 * be shared between the platform-dependent and platform-indepdendent parts of
 * this extension.
 */

/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */


#ifndef S3EGPN_INTERNAL_H
#define S3EGPN_INTERNAL_H

#include "s3eTypes.h"
#include "s3eGPN.h"
#include "s3eGPN_autodefs.h"


/**
 * Initialise the extension.  This is called once then the extension is first
 * accessed by s3eregister.  If this function returns S3E_RESULT_ERROR the
 * extension will be reported as not-existing on the device.
 */
s3eResult s3eGPNInit();

/**
 * Platform-specific initialisation, implemented on each platform
 */
s3eResult s3eGPNInit_platform();

/**
 * Terminate the extension.  This is called once on shutdown, but only if the
 * extension was loader and Init() was successful.
 */
void s3eGPNTerminate();

/**
 * Platform-specific termination, implemented on each platform
 */
void s3eGPNTerminate_platform();

//Version argument manually added. s4e does not have it
s3eResult cpInitialize_platform(const char* version, const char** appIDs, s3eBool debugMode);

s3eResult cpStartRequestingInterstitials_platform();

int cpPresentInterstitial_platform(const char* argString, int* outResult);

int cpStopRequestingInterstitials_platform();

s3eResult cpInterstitialDestroy_platform();

s3eResult cpSetShouldKillOnLowMemory_platform(s3eBool flag);

s3eResult cpDebugGetAppId_platform(char* buffer);

s3eResult cpDebugGetBaseURL_platform(char* buffer);

s3eResult cpDebugSetAppId_platform(const char* appId);

s3eResult cpDebugSetBaseURL_platform(const char* baseURL);


#endif /* !S3EGPN_INTERNAL_H */