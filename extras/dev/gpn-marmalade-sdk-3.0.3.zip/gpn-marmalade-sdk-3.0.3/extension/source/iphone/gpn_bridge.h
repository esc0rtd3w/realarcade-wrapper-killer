//
//  gpn_bridge.h
//  gpn_bridge
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

#import <Foundation/Foundation.h>

#import "CrossPromotion.h"

typedef void (*CPInterstitialReceivedCallback)(void);
typedef void (*CPInterstitialFailedCallback)(NSString* message);
typedef void (*CPInterstitialOpenedCallback)(void);
typedef void (*CPinterstitialClosedCallback)(void);
typedef void (*CPinterstitialKilledOnLowMemoryCallback)(void);

@interface CPMarmaladeBridge : NSObject<CPInterstitialAdViewDelegate>
{
@private
    CPInterstitialReceivedCallback          _receivedCallback;
    CPInterstitialFailedCallback            _failedCallback;
    CPInterstitialOpenedCallback            _openedCallback;
    CPinterstitialClosedCallback            _closedCallback;
    CPinterstitialKilledOnLowMemoryCallback _killedOnLowMemoryCallback;
    
    BOOL       _shouldKillOnLowMemory;
}

@property (nonatomic, assign) BOOL shouldKillOnLowMemory;

- (id)initVersion:(NSString *)version appId:(NSString *)appId debugMode:(BOOL)debugMode;

- (void)startRequestingInterstitials;
- (CPInterstitialResult)presentInterstitialWithParams:(NSDictionary *)params;
- (void)stopRequestingInterstitials;

- (NSString *)appId;
- (NSString *)baseURL;
- (void)setAppId:(NSString *)appId;
- (void)setBaseURL:(NSString *)baseURL;

- (void)setInterstitialReceivedCallback:(CPInterstitialReceivedCallback)cb;
- (void)setInterstitialFailedCallback:(CPInterstitialFailedCallback)cb;
- (void)setInterstitialOpenedCallback:(CPInterstitialOpenedCallback)cb;
- (void)setInterstitialClosedCallback:(CPinterstitialClosedCallback)cb;
- (void)setInterstitialKilledOnLowMemoryCallback:(CPinterstitialKilledOnLowMemoryCallback)cb;

@end
