//
//  s3eGPN_platform.mm
//  s3eGPN_platform
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

/*
 * iphone-specific implementation of the s3eGPN extension.
 * Add any platform-specific functionality here.
 */
/*
 * NOTE: This file was originally written by the extension builder, but will not
 * be overwritten (unless --force is specified) and is intended to be modified.
 */
#include "s3eGPN_internal.h"

#include "IwDebug.h"
#include "s3eEdk.h"

#import "gpn_bridge.h"

static CPMarmaladeBridge* s_bridge;

static NSString      * _CPCreateNSString(const char* cStr);
static NSDictionary  * _CPCreateNSDictionary(const char* cStr);

static void cbInterstitialReceived(void);
static void cbInterstitialFailed(NSString *message);
static void cbInterstitialOpened(void);
static void cbInterstitialClosed(void);
static void cbInterstitialKilledOnLowMemory(void);

s3eResult s3eGPNInit_platform()
{
    // Add any platform-specific initialisation code here
    return S3E_RESULT_SUCCESS;
}

void s3eGPNTerminate_platform()
{
    [s_bridge release];
    s_bridge = nil;
}

s3eResult cpInitialize_platform(const char* versionStr, const char** appIDs, s3eBool debugMode)
{
    if (s_bridge == nil)
    {
        const char* appIDStr = appIDs[S3E_GPN_APP_ID_INDEX_IOS]; // not safe!
        if (appIDStr == NULL)
        {
            IwTrace(gpn, ("Please, provide iOS app ID"));
            return S3E_RESULT_ERROR;
        }
        
        NSString *version = _CPCreateNSString(versionStr);
        NSString *appID   = _CPCreateNSString(appIDStr);
        
        s_bridge = [[CPMarmaladeBridge alloc] initVersion:version appId:appID debugMode:debugMode];
        [s_bridge setInterstitialReceivedCallback:cbInterstitialReceived];
        [s_bridge setInterstitialFailedCallback:cbInterstitialFailed];
        [s_bridge setInterstitialOpenedCallback:cbInterstitialOpened];
        [s_bridge setInterstitialClosedCallback:cbInterstitialClosed];
        [s_bridge setInterstitialKilledOnLowMemoryCallback:cbInterstitialKilledOnLowMemory];
        
        return S3E_RESULT_SUCCESS;
    }
    return S3E_RESULT_ERROR;
}

s3eResult cpStartRequestingInterstitials_platform()
{
    if (s_bridge != nil)
    {
        [s_bridge startRequestingInterstitials];
        return S3E_RESULT_SUCCESS;
    }
    
    return S3E_RESULT_ERROR;
}

int cpPresentInterstitial_platform(const char* cStr, int* outResult)
{
    if (s_bridge != nil)
    {
        NSDictionary *args = _CPCreateNSDictionary(cStr);
        int result = [s_bridge presentInterstitialWithParams:args];
        if (outResult != NULL)
        {
            *outResult = result;
        }
        
        return S3E_RESULT_SUCCESS;
    }
    
    return S3E_RESULT_ERROR;
}

int cpStopRequestingInterstitials_platform()
{
    if (s_bridge != nil)
    {
        [s_bridge stopRequestingInterstitials];
        return S3E_RESULT_SUCCESS;
    }
    
    return S3E_RESULT_ERROR;
}

s3eResult cpInterstitialDestroy_platform()
{
    if (s_bridge != nil)
    {
        [s_bridge release];
        s_bridge = nil;
        return S3E_RESULT_SUCCESS;
    }
    
    return S3E_RESULT_ERROR;
}

s3eResult cpSetShouldKillOnLowMemory_platform(s3eBool flag)
{
    if (s_bridge != nil)
    {
        s_bridge.shouldKillOnLowMemory = flag;
        return S3E_RESULT_SUCCESS;
    }
    
    return S3E_RESULT_ERROR;
}

s3eResult cpDebugGetAppId_platform(char* buffer)
{
    if (s_bridge != nil)
    {
        strcpy(buffer, [s_bridge appId].UTF8String);
        return S3E_RESULT_SUCCESS;
    }
    return S3E_RESULT_ERROR;
}

s3eResult cpDebugGetBaseURL_platform(char* buffer)
{
    if (s_bridge != nil)
    {
        strcpy(buffer, [s_bridge baseURL].UTF8String);
        return S3E_RESULT_SUCCESS;
    }
    return S3E_RESULT_ERROR;
}

s3eResult cpDebugSetAppId_platform(const char* cStr)
{
    if (s_bridge != nil)
    {
        NSString *appId = _CPCreateNSString(cStr);
        if (appId != nil)
        {
            [s_bridge setAppId:appId];
        }
    }
    return S3E_RESULT_ERROR;
}

s3eResult cpDebugSetBaseURL_platform(const char* cStr)
{
    if (s_bridge != nil)
    {
        NSString *baseURL = _CPCreateNSString(cStr);
        if (baseURL != nil)
        {
            [s_bridge setBaseURL:baseURL];
        }
    }
    return S3E_RESULT_ERROR;
}

#pragma mark -
#pragma mark Callbacks

void cbInterstitialReceived()
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_RECEIVED);
}

void cbInterstitialFailed(NSString *message)
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_FAILED); // TODO: pass message
}

void cbInterstitialOpened()
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_OPENED);
}

void cbInterstitialClosed()
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_CLOSED);
}

void cbInterstitialKilledOnLowMemory()
{
    s3eEdkCallbacksEnqueue(S3E_EXT_GPN_HASH, S3E_GPN_CALLBACK_KILLED_ON_LOW_MEM);
}

#pragma mark -
#pragma mark Helpers

NSString * _CPCreateNSString(const char* cStr)
{
    if (cStr != NULL)
    {
        return [NSString stringWithUTF8String:cStr];
    }
    return nil;
}

NSDictionary * _CPCreateNSDictionary(const char* cStr)
{
    if (cStr != NULL)
    {
        NSString *str = _CPCreateNSString(cStr);
        
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        NSArray *pairArray = [str componentsSeparatedByString:@"&"];
        for (NSString *pairStr in pairArray) {
            NSArray *tokens = [pairStr componentsSeparatedByString:@"="];
            if (tokens.count == 2)
            {
                NSString *key = [tokens objectAtIndex:0];
                if (key != nil)
                {
                    NSString *value = [tokens objectAtIndex:1];
                    if (value != nil)
                    {
                        [dict setObject:value forKey:key];
                    }
                    else
                    {
                        NSLog(@"Value is nil for key: %@", key);
                    }
                }
                else
                {
                    NSLog(@"Wrong pair token: %@", pairStr);
                }
            }
            else
            {
                NSLog(@"Wrong pair token: %@", pairStr);
            }
        }
        
        return dict;
    }
    return nil;
}
