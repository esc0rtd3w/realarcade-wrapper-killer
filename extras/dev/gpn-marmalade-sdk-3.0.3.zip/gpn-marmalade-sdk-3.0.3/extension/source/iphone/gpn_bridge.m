//
//  gpn_bridge.m
//  gpn_bridge
//
//  Copyright 2015 GameHouse, a division of RealNetworks, Inc.
// 
//  The GameHouse Promotion Network SDK is licensed under the Apache License, 
//  Version 2.0 (the "License"); you may not use this file except in compliance 
//  with the License. You may obtain a copy of the License at
// 
//     http://www.apache.org/licenses/LICENSE-2.0
// 
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.
//

#include <s3e.h>

#import "gpn_bridge.h"

#import "CrossPromotion_Debug.h"

@interface CrossPromotion (Private)

- (void)setWrapperName:(NSString *)name;
- (void)setWrapperVersion:(NSString *)version;

+ (void)setConfigNeedsTransformForViewInWindow:(BOOL)flag;
    
@end

@implementation CPMarmaladeBridge

@synthesize shouldKillOnLowMemory = _shouldKillOnLowMemory;

- (id)initVersion:(NSString *)version appId:(NSString *)appId debugMode:(BOOL)debugMode
{
    self = [super init];
    if (self) {
        CPLogSetDebugEnabled(debugMode);
        
        [CrossPromotion setWrapperName:@"marmalade"];
        [CrossPromotion setWrapperVersion:version];

        [CrossPromotion initializeWithAppId:appId];
        
        if (S3E_VERSION_MINOR <= 39)
        {
            // this is an old orientation bug which was fixed in later release
            [CrossPromotion setConfigNeedsTransformForViewInWindow:YES];
        }
    }
    return self;
}

- (void)dealloc
{
    [CrossPromotion destroy];
    [super dealloc];
}

#pragma mark -
#pragma mark Interstitial

- (void)startRequestingInterstitials
{
    [[CrossPromotion sharedInstance] startRequestingInterstitialsWithDelegate:self];
}

- (CPInterstitialResult)presentInterstitialWithParams:(NSDictionary *)params
{
    return [[CrossPromotion sharedInstance] presentWithParams:params];
}

- (void)stopRequestingInterstitials
{
    [[CrossPromotion sharedInstance] stopRequestingInterstitials];
}

#pragma mark -
#pragma mark Debug

- (NSString *)appId
{
    return [CrossPromotion sharedInstance].appId;
}

- (NSString *)baseURL
{
    return [CrossPromotion sharedInstance].baseURL;
}

- (void)setAppId:(NSString *)appId
{
    [[CrossPromotion sharedInstance] setAppId:appId];
}

- (void)setBaseURL:(NSString *)baseURL
{
    [[CrossPromotion sharedInstance] setBaseURL:baseURL];
}

#pragma mark -
#pragma mark Callbacks

- (void)setInterstitialReceivedCallback:(CPInterstitialReceivedCallback)cb
{
    _receivedCallback = cb;
}

- (void)setInterstitialFailedCallback:(CPInterstitialFailedCallback)cb
{
    _failedCallback = cb;
}

- (void)setInterstitialOpenedCallback:(CPInterstitialOpenedCallback)cb
{
    _openedCallback = cb;
}

- (void)setInterstitialClosedCallback:(CPinterstitialClosedCallback)cb
{
    _closedCallback = cb;
}

- (void)setInterstitialKilledOnLowMemoryCallback:(CPinterstitialKilledOnLowMemoryCallback)cb
{
    _killedOnLowMemoryCallback = cb;
}

#pragma mark -
#pragma mark CPInterstitialAdViewDelegate

// View controller used for presenting an external ad browser.
- (UIViewController *)viewControllerForPresenting
{
    return [UIApplication sharedApplication].keyWindow.rootViewController;
}

// Interstitial ad is received: it’s safe to present it now.
- (void)interstitialAdDidReceive:(CPInterstitialAdView *)adView
{
   if (_receivedCallback)
       _receivedCallback();
}

//  Interstitial ad is failed to receive.
- (void)interstitialAdDidFail:(CPInterstitialAdView *)adView withError:(NSError *)error
{
    if (_failedCallback)
        _failedCallback(error.description);
}

// Interstitial ad presented full screen modal view. You can pause your game here.
- (void)interstitialAdDidOpen:(CPInterstitialAdView *)adView
{
    if (_openedCallback)
        _openedCallback();
}

// Interstitial ad hided full screen modal view. You can resume your game here.
- (void)interstitialAdDidClose:(CPInterstitialAdView *)adView
{
    if (_closedCallback)
        _closedCallback();
}

// Return YES if ad should be destroyed on a low memory warning.
- (BOOL)interstitialAdShouldDestroyOnLowMemory
{
    return _shouldKillOnLowMemory;
}

// Interstitial ad was destroyed after receiving low memory warning.
- (void)interstitialAdLowMemoryDidDestroy
{
    if (_killedOnLowMemoryCallback)
        _killedOnLowMemoryCallback();
}

@end
