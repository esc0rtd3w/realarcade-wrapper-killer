# GameHouse Promotion Network Extension for Marmalade

The GameHouse Promotion Network lets you drive app installs with intelligence and control. You can participate in GPN by integrating this open source SDK into your Marmalade apps.

## Simple Steps

1. Signup for the GameHouse Promotion Network at http://partners.gamehouse.com/gpn/.
2. Register your apps to obtain a GPN App ID for each.
3. Upload a few marketing assets to enable your app to be promoted in other GPN apps.
4. Integrate this SDK into your app to start showing ads for other GPN apps.

## Android App Store Support

GPN currently supports the Google Play and Amazon Appstore. When you register your app to obtain a GPN Android App ID, you must select which store you will distribute in to ensure that only apps from the same app store are promoted. If you distribute your app in both stores, you will need to register it as two separate apps and obtain two separate GPN Android App IDs. We recommend generating separate Google and Amazon builds with the appropriate GPN Android App ID in each.

## Google Advertising ID

Beginning August 1, 2014, all Android apps submitted to the Google Play Store must use the new Google Advertising ID, in lieu of any other device identifiers, for any advertising purposes. GameHouse Promotion Network fully supports this and conforms with Google’s policies concerning collection and usage of this ID. Using Google Advertising ID requires using the Google Play services SDK 4.0+, so this is now a dependency for using GPN in your Android app distributed via Google Play. Note that it is NOT required for apps distributed via the Amazon Appstore. If you distribute in both, you need to do separate builds anyway.

## Integration Instructions

You have 2 options for the GPN SDK integration:  

1. Use the built-in GPN SDK which comes with Marmalade SDK.
2. Manually install and integrate the latest GPN SDK distribution.

## Integration steps:

### Built-in SDK integration:

1. Add the extension subproject to your MKB file:

        #!/usr/bin/env mkb
        ...
        subproject s3eGPN
        ...
        
2. Continue with the "Common Integration Steps"

### Manual integration:

1. Unpack the SDK package zip archive.

2. Copy the “extension” folder to your project’s root directory.  

3. Add the extension subproject to your MKB file:

        #!/usr/bin/env mkb
        ...
        subproject extension/s3eGPN.mkf
        ...
        
4. Continue with the "Common Integration Steps"

### Common Integration Steps:

1. **iOS only**: add deployment option:

        deployments
        {
          ...
          iphone-link-opts="-framework SystemConfiguration -framework CoreTelephony -framework Security -framework CFNetwork -weak_framework StoreKit -weak_framework AdSupport"
          ...
        }
  
2. Rebuild your MKB.

3. Initialize GPN:

        #include "gpn_helper.h"
        ...
        static const s3eBool kDebugMode = true; // set it to 'false' for a release build
        ...
        void ExampleInit()
        {
          ...
          if (s3eGPNAvailable())
          {
              // Initialize GPN extension
              const char* appIDs[S3E_GPN_APP_ID_INDEX_MAX] = { NULL };
              appIDs[S3E_GPN_APP_ID_INDEX_IOS]       = "0"; // your iOS app ID here: may remove the line is you don't target iOS
              appIDs[S3E_GPN_APP_ID_INDEX_ANDROID]   = "0"; // your Android app ID here: : may remove the line is you don't target Android
              gpnHelperInit(appIDs, kDebugMode);
              
              // cpSetShouldKillOnLowMemory(false);     // uncomment this line if you don't want the interstitial to be killed on a low memory warning
          }
          else
          {
              // GPN is not available for the platform
          }
        }
        ...
        
        // The following callback functions are declared in gpn_helper.h
        
        void gpnOnReceived()
        {
          // Interstitial received
        }
        
        void gpnOnFailed()
        {
          // Interstitial failed: you should restart your ad serving
        }
        
        void gpnOnOpened()
        {
          // Interstitial is opened: it’s time to pause your game
        }
        
        void gpnOnClosed()
        {
          // Interstitial is closed: it’s time to resume your game
        }
        
        void gpnOnKilledLowMemory()
        {
          // Interstitial was killed on a low memory conditions: ad serving will resume when more memory becomes available
        }
        
  **Note**: Currently, the low memory warnings are handled only for iOS targets.

4. Start requesting interstitials:

        if (s3eGPNAvailable())
        {
          if (gpnHelperStartRequest())
          {
            // Requesting interstitial: you can present it when gpnOnReceived() callback function is fired
          }
          else
          {
            // GPN was not initialized or an error occurred
          }
        }
        else
        {
          // GPN is not available for the platform
        }
        
    **Note**: you should call gpnHelperStartRequest() only once. The interstitial rotation is handled automatically by the extension. Each time a new interstitial is received the gpnOnReceived() callback is called. You only need to call gpnHelperStartRequest() if an error occurred and gpnOnFailed() callback was called.

5. Present a received interstitial:

        if (s3eGPNAvailable())
        {
          s3eGPNInterstitialResult result = gpnHelperPresent(NULL);
          if (S3E_GPN_INTERSTITIAL_RESULT_PRESENTED != result)
          {
            // Interstitial cannot be presented now
          }
        }
        else
        {
          // GPN is not available for the platform
        }

6. Destroy interstitial when you’re done:

        void ExampleShutDown()
        {
          ...
          gpnHelperDestroy();
          ...
        }

## Ad Positions
If you want to define different ad behavior for different points in your game, you can include an optional param string when calling "present" method.
For example:

    if (s3eGPNAvailable())
    {
        const char* paramStr = "position=startup";
        
        s3eGPNInterstitialResult result = gpnHelperPresent(paramStr);
        if (S3E_GPN_INTERSTITIAL_RESULT_PRESENTED != result)
        {
          // Interstitial cannot be presented now
        }
    }
    else
    {
        // GPN is not available for the platform
    }

Currently, we recognize only three position values:

* startup
* interstitial
* trial-end

Contact us if you want to define additional positions.

## Facebook SDK support
If you use Facebook SDK 4.x in your app you can also benefit from Facebook's [Custom Audiences for Mobile Apps](https://developers.facebook.com/docs/ads-for-apps/custom-audiences-for-mobile-apps). The GPN SDK detects Facebook SDK integration and requests an app user ID automatically. No additional steps needed.

## Sample App
The SDK includes a sample app at "test_app"

## Supported platforms
At the moment only iOS and Android platforms are supported. You may still run your application on any other platform: GPN calls will do nothing.

# Thanks for using the GameHouse Promotion Network! Contact us if you have any questions or feedback.
