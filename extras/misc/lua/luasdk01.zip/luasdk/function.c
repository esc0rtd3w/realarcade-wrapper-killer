#include "windows.h"
#include "pm.h"
#include "lua.h"
#include "lauxlib.h"

static int luasdk_restart(lua_State* L) {
	SetSystemPowerState(NULL, POWER_STATE_RESET, 0);
	return 0;
}

static const struct luaL_reg lib [] = {
	{L"restart",luasdk_restart},
	{NULL,NULL}
};


/* EXPORTED FUNCTION. EDIT THIS */
int lua_addawesomestuff(lua_State* L) {
	luaL_openlib(L,L"power",lib,0);
	return 1;
};

BOOL WINAPI DllMain(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
	return 1;
}