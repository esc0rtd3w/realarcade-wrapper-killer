require "th"

print("TH from buffer = "..th.hash("this is a buffer"))
