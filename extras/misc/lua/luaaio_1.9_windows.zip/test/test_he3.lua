require("he3")

local buffer = "Put a real HE3 buffer to be decoded here"

print("Buffer to decode = "..buffer.." (length = "..string.len(buffer)..")")
buffer = he3.decode(buffer)
if buffer then
    print("Decoded buffer is = "..buffer)
else
    print("Not able to decode HE3 buffer")
end
