require("udps")

sid={}

function UDPReceive(port,msg)
    print("UDP message (port="..port..") received : "..msg)
end

print("Starting servers udp ports from 1000 to 1003")
sid[1000]=udps.open(1000)
sid[1001]=udps.open(1001)
sid[1002]=udps.open(1002)
sid[1003]=udps.open(1003)

i=0
while (i<10)do
    i=i+1
    ThreadWait(1000)
end

print("Stopping servers udp port from 1001 to 1003")
udps.close(sid[1001])
udps.close(sid[1002])
udps.close(sid[1003])

i=0
while (i<10)do
    i=i+1
    ThreadWait(1000)
end

print("Stopping servers udp port 1000")
udps.close(sid[1000])
