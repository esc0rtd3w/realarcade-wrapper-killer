require "geoip"

local ok, err = geoip.open("GeoIP.dat")

if ok then print("geoip file loaded") else print("failed to load geoip file : "..err) print("Download a geoIP.dat file from http://www.maxmind.com/app/geoip_country !!!") end

print("geoip.code = "..geoip.code("193.145.165.33"))
print("geoip.name = "..geoip.name("193.145.165.33"))

geoip.delete()

