require("dc")

local lock="this is my lock buffer"
print("LOCK = "..lock)

local key = dc.computeAccessKey(lock)
print("KEY = "..key)

local ind="this is my lock buffer"
print("IN = "..ind)

local outd = dc.EncodetoBase32(ind)
print("dc.EncodetoBase32 = "..outd)

local outd2 = dc.EncodefromBase32(outd)
print("dc.EncodefromBase32 = "..outd2)

local outd2 = dc.hashpid(ind)
print("dc.hashpid = "..outd2)

local outd2 = dc.hashpas("password","salt")
print("dc.hashpas = "..outd2)

local outd2 = dc.hashpasos("password","salt",ind)
print("dc.hashpasos = "..outd2)

