require("tcps")

sid={}

function TCPConnect(port,soc)
    print("User ("..port..","..soc.."): Connected ("..tcps.getIP(sid[port],soc)..")")
    tcps.send(sid[port],soc,"$Hello")
    tcps.connect(sid[port],soc)
end

function TCPReceive(port,soc,msg)
    print("User ("..port..","..soc.."): Receive "..msg)
    if string.sub(msg,1,4)=="$Who" then
        tcps.send(sid[port],soc,"$Me")
    elseif string.sub(msg,1,3)=="$Id" then
        tcps.send(sid[port],-soc,msg)
    elseif string.sub(msg,1,4)=="$All" then
        tcps.send(sid[port],0,msg)
    end
end

function TCPDisconnect(port,soc)
    print("User ("..port..","..soc.."): Disconnected ("..tcps.getIP(sid[port],soc)..")")
end

print("Starting servers tcp port 1000 & 1001")
sid[1001]=tcps.open(1001)
sid[1000]=tcps.open(1000)

i=0
while (i<15)do
    i=i+1
    ThreadWait(1000)
end

print("Stopping servers tcp port 1000")
tcps.close(sid[1000])

i=0
while (i<10)do
    i=i+1
    ThreadWait(1000)
end

print("Stopping servers tcp port 1001")
tcps.close(sid[1001])
