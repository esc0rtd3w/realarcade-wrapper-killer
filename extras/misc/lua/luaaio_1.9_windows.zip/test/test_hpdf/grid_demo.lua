require "hpdf"
require "./utils/grid_sheet"

local pdf = hpdf.New()
if pdf then
  local page = hpdf.AddPage(pdf)
  hpdf.print_grid(pdf, page)
  hpdf.SaveToFile(pdf, "./output/grid_demo.pdf")
  hpdf.Free(pdf)
else
  io.write("Error creating PDF object\n")
end -- if
