require "iup"
require "cd"
dofile("./utils/canvas.lua")
dofile("./utils/plot.lua")
dofile("./utils/math.lua")

---------------- Function Definition Section -------------------

function sin2pi(x)
  return math.sin(x2pi * x)
end


function gauss2(x)
  return gauss(x, 1/2)
end


function convolve_discrete(f, N, h, M)
  local g = {}
  local NM = N+M-1

  local n = 0
  while (n < NM) do

    local gn = 0
    local k = 0

    if (n < M) then
      while (k < n) do
        gn = gn + f[k+1] * h[M-1-n+k+1]
        k = k + 1
      end
    elseif (n < N) then
      while (k < M) do
        gn = gn + f[n-(M-1)+k+1] * h[k+1]
        k = k + 1
      end
    else
      while (k < NM-1-n) do
        gn = gn + f[n-(M-1)+k+1] * h[k+1]
        k = k + 1
      end
    end

    g[n+1] = gn
    n = n + 1
  end

  return g, NM
end



---------------- Plot Section -------------------

cnv = canvas.new(600, 400)
cnv:Activate()

function DrawSamples()
  plot.axis(4, 0.8, 1/2, 1/2)

  dt = 1/16

  h, Nh = sample(gauss2, dt, -2, 2)
  f, Nf = sample(sin2pi, dt, 0, 4)

  plot.discrete(h, Nh, dt, 255, 0, 0)
  plot.discrete(f, Nf, dt, 0, 255, 0)

  g, Ng = convolve_discrete(f, Nf, h, Nh)

  plot.discrete(g, Ng, dt, 0, 0, 255)
end

DrawSamples()

iup.MainLoop()