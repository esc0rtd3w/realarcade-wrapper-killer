require "iup"
require "cd"

dofile("./utils/canvas.lua")

function DrawTextBox(x, y, text)
  cd.Mark(x, y)
  cd.Text(x, y, text)
  w, h = cd.TextSize(text)
  xmin = x - w/2
  ymin = y - h/2
  xmax = x + w/2
  ymax = y + h/2
  cd.Line(xmin, ymin, xmax, ymin)
  cd.Line(xmin, ymin, xmin, ymax)
  cd.Line(xmin, ymax, xmax, ymax)
  cd.Line(xmax, ymin, xmax, ymax)
end

function DrawSamples()
  cd.Clear()

  cd.TextAlignment(cd.CENTER)
  cd.MarkSize(40)

  cd.Font(cd.COURIER, cd.PLAIN, 12)
  local aa = cd.GetAttribute("ANTIALIAS")
  if (aa == "1") then
    DrawTextBox(130, 30, "ANTIALIAS=1")
  else
    DrawTextBox(130, 30, "ANTIALIAS=0")
  end

  cd.Font(cd.COURIER, cd.ITALIC, 34)
  DrawTextBox(130, 160, "xxxxxppx")

  cd.Font(cd.TIMES_ROMAN, cd.PLAIN, 12)
  DrawTextBox(130, 290, "taaaa")

  cd.Font(cd.TIMES_ROMAN, cd.BOLD, 14)
  DrawTextBox(130, 370, "gggggggg")
end

cd.UseContextPlus(1)
cnv = canvas.new(600, 400)
cnv:Activate()
cd.SetAttribute("ANTIALIAS", "1")

--tmpCanvas = cd.CreateCanvas(cd.PS, "cdtext.ps")
--cd.Activate(tmpCanvas)
--DrawSamples()
--cd.KillCanvas(tmpCanvas)

iup.MainLoop()