require "iup"
require "cd"
dofile("./utils/canvas.lua")
dofile("./utils/plot.lua")
dofile("./utils/math.lua")

---------------- Function Definition Section -------------------

function gauss2(x)
  return gauss(x, 1/2)
end


---------------- Plot Section -------------------

cnv = canvas.new(600, 400)
cnv:Activate()

function DrawSamples()
  plot.axis(4, 0.8, 1/2, 1/2)
  plot.continuous(gauss2, 255, 0, 0)
end

DrawSamples()

iup.MainLoop()