---------------- Constants Definition Section -------------------

pi = 3.14159265359
x2pi = 2*pi
x4pi = 4*pi
rad2grau = 360/x2pi
sqrt_x2pi = math.sqrt(x2pi)

---------------- Function Definition Section -------------------


function sinc(x)
  if (x == 0) then
    return 1
  else
    return math.sin(x) / x
  end
end


function gauss(x, sigma)
  return math.exp((-x*x)/(2*sigma*sigma))/(sigma*sqrt_x2pi)
end


function pulse(x, a)
  if (x < -a) then
    return 0
  elseif (x <= a) then
    return 1
  else
    return 0
  end
end


function sample(func, dt, t1, t2)
  local f = {}
  local n = 0

  local tk = t1
  while (tk < t2) do
    f[n+1] = func(tk)
    tk = tk + dt
    n = n + 1
  end

  return f, n
end


complex = {real=0, imag=0}


function complex:create(r, i)
  local new_complex = {parent=self}

  if r ~= nil then new_complex.real = r end
  if i ~= nil then new_complex.imag = i end

  return new_complex
end

function complex:mul(c)
  local real = self.real
	self.real = self.real * c.real - self.imag * c.imag;
	self.imag = self.imag * c.real + real * c.imag;
end

function complex:mul_cte(k)
	self.real = self.real * k;
	self.imag = self.imag * k;
end

function complex:add(c)
	self.real = self.real + c.real;
	self.imag = self.imag + c.imag;
end

function complex:mag()
  return math.sqrt(self.real * self.real + self.imag * self.imag)
end


