-- CD/IUP Test Canvas Dialog (Create, Kill and Activate)


canvas = {}
canvas.count = 0

local function repaint(self)
  local old_canvas = cd.ActiveCanvas()
  cd.Activate(self.cd_canvas)
  if (DrawSamples) then
    DrawSamples()
  else
    cd.Clear()
  end
  cd.Activate(old_canvas)
end


local function create(w, h, t)
  local new_canvas = {}

  new_canvas.iup_canvas = iup.canvas { bgcolor="255 255 255", rastersize=w.."x"..h }
  new_canvas.iup_dialog = iup.dialog { new_canvas.iup_canvas; title=t }

  new_canvas.iup_dialog:show()

  new_canvas.cd_canvas = cd.CreateCanvas(cd.IUP, new_canvas.iup_canvas)
  cd.Activate(new_canvas.cd_canvas)

  new_canvas.iup_canvas.action = repaint
  new_canvas.iup_canvas.cd_canvas = new_canvas.cd_canvas

  repaint(new_canvas.iup_canvas)

  return new_canvas
end


local function activate(self)
  cd.Activate(self.cd_canvas)
end


local function kill(self)
  self.iup_dialog:destroy()
  print("Killing canvas")
  cd.KillCanvas(self.cd_canvas)
end


-- Function to easy create a new canvas

function canvas.new (w, h)
  w = w or 300
  h = h or 200
  local name = "canvas_"..(canvas.count+1)
  local cnv = create (w, h, name)
  cnv.repaint = repaint
  cnv.Activate = activate
  cnv.Kill = kill

  canvas.count = canvas.count + 1
  return cnv
end
