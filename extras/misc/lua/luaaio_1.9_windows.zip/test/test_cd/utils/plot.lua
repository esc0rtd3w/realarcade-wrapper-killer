
-- Plot functions

plot = {}

plot.tick_size = 5
plot.sw = 1
plot.sh = 1

function plot.ticks(w_2, h_2, tx, ty)
  cd.Foreground(cd.BLACK)

  local ty1 = h_2 - plot.tick_size
  local ty2 = h_2 + plot.tick_size
  local x = tx
  while (x < w_2) do
    cd.Line(x+w_2,ty1,x+w_2,ty2)
    cd.Line(-x+w_2,ty1,-x+w_2,ty2)
    x = x + tx
  end

  local tx1 = w_2 - plot.tick_size
  local tx2 = w_2 + plot.tick_size
  local y = ty
  while (y < h_2) do
    cd.Line(tx1,y+h_2,tx2,y+h_2)
    cd.Line(tx1,-y+h_2,tx2,-y+h_2)
    y = y + ty
  end
end

function plot.axis(sw, sh, tx, ty)
  cd.Clear()
  cd.Foreground(cd.BLACK)

  local w, h = cd.GetCanvasSize()
  cd.Line(0, h/2, w, h/2)
  cd.Line(w/2, 0, w/2, h)

  local w_2 = w/2
  local h_2 = h/2
  local fh = sh*h_2
  local fw = sw/w_2

  tx = tx / fw
  ty = ty * fh

  plot.ticks(w_2, h_2, tx, ty)

  plot.sw = sw
  plot.sh = sh
end


function plot.continuous(func, r, g, b)
  local w, h = cd.GetCanvasSize()

  local w_2 = w/2
  local h_2 = h/2
  local fh = plot.sh*h_2
  local fw = plot.sw/w_2

  local c = cd.EncodeColor(r, g, b)
  cd.Foreground(c)

  cd.Begin(cd.OPEN_LINES)
  local x = -w_2
  while (x < w_2) do
    local y = fh*func(x*fw)
    cd.Vertex(x+w_2,y+h_2)
    x = x + 1
  end
  cd.End()
end


function plot.sampled(func, dt, r, g, b)
  local w, h = cd.GetCanvasSize()

  local w_2 = w/2
  local h_2 = h/2
  local fh = plot.sh*h_2
  local fw = plot.sw/w_2
  dt = dt / fw

  local c = cd.EncodeColor(r, g, b)
  cd.Foreground(c)

  local x2 = dt * math.floor(w_2/dt)
  local x = -x2
  while (x <= x2) do
    local y = fh*func(x*fw)
    cd.Mark(x+w_2,y+h_2)
    x = x + dt
  end
end


function plot.discrete(f, N, dt, r, g, b)
  local w, h = cd.GetCanvasSize()

  local w_2 = w/2
  local h_2 = h/2
  local fh = plot.sh*h_2
  local fw = plot.sw/w_2
  dt = dt / fw

  local xs = w_2 - dt*(N/2)

  local c = cd.EncodeColor(r, g, b)
  cd.Foreground(c)

  local k = 0
  local x = 0
  while (k < N) do
    local y = fh*f[k+1]
    cd.Mark(x+xs,y+h_2)
    k = k + 1
    x = x + dt
  end

end


