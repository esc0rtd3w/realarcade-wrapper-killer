require "iup"
require "cd"

dofile("./utils/canvas.lua")

w = 100
h = 100

init_rgb = 0
if init_rgb == 0 then
  image_rgb = cd.CreateImageRGB(w,h)

  size = w * h
  i = 0
  while i < size do

    if i < size/2 then
      image_rgb.r[i] = 255
      image_rgb.g[i] = 0
      image_rgb.b[i] = 0
    else
      image_rgb.r[i] = 0
      image_rgb.g[i] = 0
      image_rgb.b[i] = 255
    end

    i = i + 1
  end

  init_rgb = 1
end

cnv = canvas.new(w, h)
cnv:Activate()

cd.PutImageRectRGB(image_rgb, 0, 0, w, h,0,0,0,0)

iup.MainLoop()