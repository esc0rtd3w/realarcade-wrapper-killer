require "iup"
require "cd"
dofile("./utils/canvas.lua")
dofile("./utils/plot.lua")
dofile("./utils/math.lua")

---------------- Function Definition Section -------------------


function f(x)
  return math.exp(-math.abs(x))*math.cos(pi * x)
end


function F(s)
  local c1 = 4 * pi * pi
  local c2 = pi + 1
  local s2 = s * s

  local A = c1 * (s2 - s) + c2
  local B = c1 * (s2 + s) + c2

  return 1/A + 1/B
end

---------------- Plot Section -------------------

cnv = canvas.new(600, 400)
cnv:Activate()

function DrawSamples()
  plot.axis(4, 0.8, 1/2, 1/2)
  plot.continuous(f, 255, 0, 0)
  plot.continuous(F, 0, 255, 0)
end

DrawSamples()

iup.MainLoop()