require "iup"
require "cd"

dofile("./utils/canvas.lua")

function DrawText(x, y, text, align)
  cd.TextAlignment(align)
  cd.Mark(x, y)
  cd.Text(x, y, text)
  xmin, xmax, ymin, ymax = cd.TextBox(x, y, text)
  cd.Rect(xmin, xmax, ymin, ymax)
end

text_aligment = {
 cd.NORTH,
 cd.SOUTH,
 cd.EAST,
 cd.WEST,
 cd.NORTH_EAST,
 cd.NORTH_WEST,
 cd.SOUTH_EAST,
 cd.SOUTH_WEST,
 cd.CENTER,
 cd.BASE_LEFT,
 cd.BASE_CENTER,
 cd.BASE_RIGHT
}

text_aligment_str = {
 "NORTH",
 "SOUTH",
 "EAST",
 "WEST",
 "NORTH EAST",
 "NORTH WEST",
 "SOUTH EAST",
 "SOUTH WEST",
 "CENTER",
 "BASE LEFT",
 "BASE CENTER",
 "BASE RIGHT"
}


function DrawSamples()
  cd.MarkSize(40)
  cd.Font(cd.COURIER, cd.PLAIN, 12)

  i = 1
  while (i <= 12) do
    DrawText(100, 35*i + 30, text_aligment_str[i], text_aligment[i])
    i = i + 1
  end
end

cnv = canvas.new(600, 400)
cnv:Activate()

--tmpCanvas = cd.CreateCanvas(cd.PS, "cdalign.ps")
--cd.Activate(tmpCanvas)
DrawSamples()
--cd.KillCanvas(tmpCanvas)

iup.MainLoop()