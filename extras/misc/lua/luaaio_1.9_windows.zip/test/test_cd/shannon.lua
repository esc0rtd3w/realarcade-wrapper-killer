require "iup"
require "cd"
dofile("./utils/canvas.lua")
dofile("./utils/plot.lua")
dofile("./utils/math.lua")

---------------- Function Definition Section -------------------

function sin4pi(x)
  return math.sin(x4pi * x)
end


function recon_shannon(omega, dt, func, t, t1, t2)
  local result = 0

  local c1 = 2 * omega * dt
  local c2 = x2pi * omega

  t1 = dt * math.floor(t1/dt)
  t2 = dt * math.floor(t2/dt)

  local tk = t1
  while (tk < t2) do
    result = result + func(tk) * sinc(c2 * (t - tk))
    tk = tk + dt
  end

  return result * c1
end


function recon_sin4pi(x)
  return recon_shannon(2, 1/8, sin4pi, x, -7, 7)
end


---------------- Plot Section -------------------


cnv = canvas.new(600, 400)
cnv:Activate()

function DrawSamples()
  plot.axis(2.5, 0.8, 1/8, 1/2)
  plot.continuous(sin4pi, 255, 0, 0)
  plot.sampled(sin4pi, 1/8, 0, 0, 255)
  plot.continuous(recon_sin4pi, 0, 255, 0)
end

DrawSamples()

iup.MainLoop()