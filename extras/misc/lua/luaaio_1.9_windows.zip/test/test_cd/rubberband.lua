require "iup"
require "cd"

dofile("./utils/canvas.lua")

function myButton (canvas, b,e,x,y,r)
--  if b == IUP_BUTTON1 and e == 1 then
  if b ==49 and e == 1 then

     -- inicia o drag

     y = cd.UpdateYAxis(y)

     xstart = x
     ystart = y

     drag = 1
     first = 1

  else
     
     if (drag == 1) then
       drag = 0
       cd.Rect(xstart,xend,ystart,yend)
     end

  end
end


function myMotion (canvas,x,y,r)

  if (drag == 1) then 

    y = cd.UpdateYAxis(y)

    if (first == 1) then 
      first = 0
    else
      cd.Rect (xstart,xend,ystart,yend)
    end

    cd.Rect (xstart,x,ystart,y)

    xend = x
    yend = y

  end
end

xstart,xend,ystart,yend = 250,350,150,250

cnv = canvas.new(600, 400)
cnv:Activate()

cd.Clear()

cd.Foreground (cd.WHITE)
cd.WriteMode (cd.XOR)

--cd.Foreground (cd.RED)
--cd.WriteMode (cd.REPLACE)

first = 1
drag = 0

cnv.iup_canvas.button_cb = myButton
cnv.iup_canvas.motion_cb = myMotion

iup.MainLoop()