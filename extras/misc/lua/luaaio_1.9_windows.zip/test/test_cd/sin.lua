require "iup"
require "cd"
dofile("./utils/canvas.lua")
dofile("./utils/plot.lua")
dofile("./utils/math.lua")

---------------- Function Definition Section -------------------

function sin4pi(x)
  return math.sin(x4pi * x)
end


---------------- Plot Section -------------------

cnv = canvas.new(600, 400)
cnv:Activate()

function DrawSamples()
  plot.axis(1.6, 0.4, 1/8, 1/2)
  plot.continuous(sin4pi, 255, 0, 0)
end

DrawSamples()

iup.MainLoop()