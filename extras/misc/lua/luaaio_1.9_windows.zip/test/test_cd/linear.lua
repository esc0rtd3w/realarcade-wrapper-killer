require "iup"
require "cd"
dofile("./utils/canvas.lua")
dofile("./utils/plot.lua")
dofile("./utils/math.lua")

---------------- Function Definition Section -------------------

function linear(x,a)
  if (x < -a) then return 0 end
  if (x > a) then return 0 end
  if (x <= 0) then return  (1/a)*x + 1 end
  if (x > 0) then return (-1/a)*x + 1 end
  return 0
end

function linear2(x)
  return linear(x, 1/2)
end

---------------- Plot Section -------------------

cnv = canvas.new(600, 400)
cnv:Activate()

function DrawSamples()
  plot.axis(1.9, 0.7, 1/2, 1/2)
  plot.continuous(linear2, 255, 0, 0)
end

DrawSamples()

iup.MainLoop()