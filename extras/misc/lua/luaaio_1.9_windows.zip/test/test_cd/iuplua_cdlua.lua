require "iup"
require "cd"

-- Example using IUPLUA/CDLUA

function cbClose()
  cd.KillCanvas(cnv)
  iup.Destroy(main)
--  return iup.CLOSE
end

function cbVersion ()
  local aux
  aux = "CD Version:" .. cd.Version() .. "\nIUP Version:" .. iup.Version() .. "\nLua Version:" .. _VERSION
  print (aux)
end

function cdRepaint (self, posx, posy)
  local aux
  aux = "Repaint: PosX="..tostring(posx).." PosY="..tostring(posy)
  print (aux)
  
  cd.Activate(cnv)
  cd.Clear()
  cd.Foreground (cd.RED)
  cd.Box (10, 55, 10, 55) 
  cd.Foreground (cd.EncodeColor(255, 32, 140))
  cd.Line(0, 0, 300, 100)
end

function cbButton (self, b, e, x, y, r) 
  print ("Button: " .. "Button="..tostring(b).." State="..tostring(e).." X="..tostring(x).." Y="..tostring(y) )
end

function cbResize (self, w, h)
  local aux
  aux = "Resize: Width="..tostring(w).." Height="..tostring(h)
  print (aux)
end

function cbScroll (self, op, posx, posy)
  local aux
  aux = "Scroll: Op="..tostring(op).." PosX="..tostring(posx).." PosY="..tostring(posy)
  print (aux)
end

c = iup.canvas { size = "200x100", 
		xmin =0.0,
		xmax=10.0,
		ymin=0.0,
		ymax=10.0,
		dx=3.0,
		dy=3.0,
		posx=0.0,
		posy=0.0,
		scrollbar = "YES",
		action=cdRepaint,
		button_cb=cbButton,
		resize_cb=cbResize,
    scroll_cb=cbScroll
	      }

tb = iup.hbox {
		iup.button { title="Version", action=cbVersion }
		  }

v1 = iup.vbox{       
       iup.fill{},
       tb,
       iup.fill{},
       c,
       iup.fill{},
       iup.button { title="Close", action=cbClose },
       iup.fill{}
     }

main = iup.dialog{v1; title="Example IUPLUA/CDLUA"}

-- Must map the dialog before creating the canvas
-- or construct the CD canvas in the IUP canvas Map callback
iup.Map(main)         
cnv = cd.CreateCanvas(cd.IUP, c)
cd.Activate(cnv)

main:showxy(150,340)

iup.MainLoop()