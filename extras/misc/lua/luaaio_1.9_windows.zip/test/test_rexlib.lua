require("rexlib")

print("-------------------------------------------------------------------------------")
print("-- set rex pcre lib")
print("-------------------------------------------------------------------------------")
rex = rex_pcre
-- show version
print("rex.version()",rex.version())
print("rex._VERSION",rex._VERSION)
-- match (1)
match = rex.match('abc foo def', 'fo+')
print('Result match (1): ', match)
-- match (2)
r = rex_pcre.new ("(?P<who>.+) goes (?P<where>.+)")
a, b = r:match ("john goes east")
print ('Result: match (2): ',a, b)
-- match (3)
a, b, match = rex.find('abc foo def', '(fo+)')
print ('Result: match (3): ',a, b, match)
-- gmatch
matches = rex.gmatch('a 11 b 12 c 13', [[\d+]])
for str in matches do
    print('Result: gmatch : ',str)
end
-- gsub (1)
print("rex.flags().CASELESS",rex.flags().CASELESS)
str = 'Foooooooo'
str = rex.gsub(str, 'O+', 'oo', nil, 1)
print('Result: gsub (1) : ',str)
-- gsub (2)
function mod (...)
    return '-' .. arg[1] .. '-'
end
str = rex.gsub('Foo', '.', mod)
print('Result: gsub (2) : ',str)
-- gsub (3)
function mod (a, b)
    return '[' .. a .. '|' .. b .. ']'
end
str = rex.gsub('foo', '(.)(.)$', mod)
print('Result: gsub (3) : ',str)
-- gsub (4)
a = {f = 'h', o = 'm'}
str = rex.gsub('foo', '.', a)
print('Result: gsub (4) : ',str)
-- gsub (5)
rex.gsub ("john goes east", "([[:word:]]+)",
           function (m, t)  print ("Result: gsub (5) : ", m) end)
-- split
letters = rex.split('a.b,c;d', '[.,;]')
for letter in letters do
    print('Result: split : ',letter)
end
-- tfind
r = rex.new("(.+) (.+)")
a, b, data = r:tfind("Felipe 18")
print('Result: tfind : ',a,b,data)
table.foreach(data, print)
-- dfa_exec
r = rex.new([[fo+]], 1)
i, data, n = r:dfa_exec('fooooo')
print('Result: dfa_exec : ',i,n,data)
table.foreach(data, print)
-- plainfind
a, b = rex.plainfind('pera uva abacaxi', 'uva')
print('Result: plainfind : ',a,b)

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

print("-------------------------------------------------------------------------------")
print("-- set rex posix lib")
print("-------------------------------------------------------------------------------")
rex = rex_posix
-- show version
print("rex._VERSION",rex._VERSION)
-- 

-- gsub
-- rex.gsub ("john goes east", "([[:word:]]+)", function (m, t)  print ("Result: gsub : ", m) end)
-- gmatch
-- matches = rex.gmatch("john goes east", "([[:word:]]+)")
-- for str in matches do
--     print('Result: gmatch : ',str)
-- end

