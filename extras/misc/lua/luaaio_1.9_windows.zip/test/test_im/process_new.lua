require "im"

function save_histogram (hist, filename, format)
	local height = 200 -- altura da imagem
	local max = math.max(unpack(hist)) -- pega o maior valor do histograma
	local n = table.getn(hist) + 1 -- zero-based
	local image = im.ImageCreate(n, height, im.GRAY, im.BYTE) -- cria a imagem
	local white = 255
	local black = 0

	local render = function (x, y, d, param)
		local v = hist[x] / max
		local h = v * height
		if y <= h then return black end
		return white
	end

	im.ProcessRenderOp(image, render, "histogram", {}, 0)
	image:Save(filename, format)
end

print(im)

local filename = "lena.jpg"

local image = im.FileImageLoad(filename)

save_histogram(im.CalcHistogram(image, 0, 0), "./output/histogram0_1.gif", "GIF")
save_histogram(im.CalcHistogram(image, 1, 0), "./output/histogram1_1.gif", "GIF")
save_histogram(im.CalcHistogram(image, 2, 0), "./output/histogram2_1.gif", "GIF")
save_histogram(im.CalcGrayHistogram(image, 0), "./output/histogram_gray_1.gif", "GIF")

local r, g, b = im.ProcessSplitComponentsNew(image)
r:Save("./output/r_1.jpg", "JPEG")
g:Save("./output/g_1.jpg", "JPEG")
b:Save("./output/b_1.jpg", "JPEG")

local rgb = im.ProcessMergeComponentsNew({r, g, b})
rgb:Save("./output/rgb_1.jpg", "JPEG")

local replace = im.ProcessReplaceColorNew(image, { 146, 93, 145 }, { 255, 0, 255 })
replace:Save("./output/replace_1.jpg", "JPEG")

local bitmask = im.ProcessBitMaskNew(image, "01111010", im.BIT_XOR)
replace:Save("./output/bitmask_1.jpg", "JPEG")
