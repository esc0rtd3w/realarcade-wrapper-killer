require "im"

local filename = "lena.jpg"
local image = im.FileImageLoad(filename)
local image2 = im.ImageCreate(image:Width(), image:Height(), im.GRAY, im.USHORT)

im.ConvertDataType(image, image2, im.CPX_REAL, im.GAMMA_LINEAR, 0, im.CAST_MINMAX)
im.ConvertColorSpace(image, image2, im.CPX_REAL, im.GAMMA_LINEAR, 0, im.CAST_MINMAX)
