require "im"

local image = im.ImageCreate(500, 500, im.RGB, im.BYTE)

im.ProcessRenderRandomNoise(image)
image:Save("./output/noise.bmp", "BMP")

im.ProcessRenderConstant(image, { 128.0, 0.0, 255.0 })
image:Save("./output/constant.bmp", "BMP")

im.ProcessRenderWheel(image, 100, 200)
image:Save("./output/wheel.bmp", "BMP")

im.ProcessRenderTent(image, 300, 200)
image:Save("./output/tent.bmp", "BMP")

im.ProcessRenderRamp(image, 0, 500, 0)
image:Save("./output/ramp.bmp", "BMP")

im.ProcessRenderBox(image, 200, 200)
image:Save("./output/box.bmp", "BMP")

im.ProcessRenderSinc(image, 100.0, 100.0)
image:Save("./output/sinc.bmp", "BMP")

im.ProcessRenderGaussian(image, 100.0)
image:Save("./output/gaussian.bmp", "BMP")

im.ProcessRenderLapOfGaussian(image, 100.0)
image:Save("./output/lapofgaussian.bmp", "BMP")

im.ProcessRenderCosine(image, 100.0, 100.0)
image:Save("./output/cosine.bmp", "BMP")

im.ProcessRenderGrid(image, 100.0, 100.0)
image:Save("./output/grid.bmp", "BMP")

im.ProcessRenderChessboard(image, 100.0, 100.0)
image:Save("./output/chess.bmp", "BMP")

im.ProcessRenderCone(image, 200)
image:Save("./output/cone.bmp", "BMP")

local render = function (x, y, d, param)
	return math.mod(x + y, 256)
end

im.ProcessRenderOp(image, render, "test", {}, 0)
image:Save("./output/render.bmp", "BMP")
