require "im"

local filename = "lena.jpg"
local image = im.FileImageLoad(filename)

local complex = im.ImageCreate(image:Width(), image:Height(), image:ColorSpace(), im.CFLOAT)
im.ProcessFFT(image, complex)

local c = complex[0][10][10]
print(c[1], c[2])

complex[0][10][10] = { 2*c[1], c[2]/2 }

local c = complex[0][10][10]
print(c[1], c[2])
