require "im"

local impal = im.PaletteHotIron()
print(impal)
print(impal[1])
