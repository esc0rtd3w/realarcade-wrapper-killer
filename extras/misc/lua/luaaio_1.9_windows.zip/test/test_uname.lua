require "uname"

print("uname.sysname => "..uname("sysname"))
print("uname.nodename => "..uname("nodename"))
print("uname.release => "..uname("release"))
print("uname.version => "..uname("version"))
print("uname.machine => "..uname("machine"))
