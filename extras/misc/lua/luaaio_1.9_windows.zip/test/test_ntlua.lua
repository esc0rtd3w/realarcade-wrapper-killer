require("ntlua")

ntlua.echo("")
ntlua.echo("Simple Test")
ntlua.echo("")

ntlua.echo("-----------------------------")
ntlua.echo("  User Name: "..ntlua.username()..".")
ntlua.echo("")
ntlua.echo("  You are using computer: "..ntlua.computername()..".")
ntlua.echo("-----------------------------")
ntlua.echo("")

ntlua.echo("System Information:")
ntlua.echo("  "..ntlua.version())
ntlua.echo("")

ntlua.setenv("TEST",  "SIMPLE")

os_ver = ntlua.os()
ntlua.setenv("SYSVERSION", os_ver.major)
ntlua.setenv("SYSMINOR",   os_ver.minor)
ntlua.setenv("SYSRELEASE", os_ver.major ..".".. os_ver.minor)
ntlua.setenv("SYSARCH",  os_ver.system)

ntlua.echo("Done.")

