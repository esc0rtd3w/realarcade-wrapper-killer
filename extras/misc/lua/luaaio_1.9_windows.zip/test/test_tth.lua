require "tth"

print("TTH from buffer = "..tth.buffer("this is a buffer"))
print("TTH from file = "..tth.file("test_tth.lua"))