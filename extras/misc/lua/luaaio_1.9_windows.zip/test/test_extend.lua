require("extend")

local buffer="this is my <%word%> to <%parse%>"
print("Original buffer = "..buffer)
if extend.strFind(buffer,"<%word%>")==true then 
    print("Searching '<%word%>' word = found")
else 
    print("Searching '<%word%>' word = not found")
end
buffer = extend.strReplace(buffer,"<%word%>","dog")
buffer = extend.strReplace(buffer,"<%parse%>","search")
print("Replaced buffer = "..buffer)
if extend.strFind(buffer,"<%word%>")==true then 
    print("Searching '<%word%>' word = found")
else 
    print("Searching '<%word%>' word = not found")
end

