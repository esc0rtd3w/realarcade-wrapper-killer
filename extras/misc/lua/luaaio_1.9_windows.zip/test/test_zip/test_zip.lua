require "zip"

local zfile, err = zip.open('luazip.zip')

assert(zfile, err)

print("File list begin")
for file in zfile:files() do
print(file.filename)
end
print("File list ended OK!")
print()

print("Testing zfile:open('README')")
local f1, err = zfile:open('README')
assert(f1, err)

print("Reading compressed file 'README'")
print(f1:read("*a"))
