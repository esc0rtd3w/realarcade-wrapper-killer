require("socket")
require("ssl") -- TLS/SSL server parameters

local params = {
   mode = "server",
   protocol = "sslv23",
   key = "./certs/A-server.pem",
   certificate = "./certs/A-server.pem",
   cafile = "./certs/CA.pem",
--   verify = {"peer", "fail_if_no_peer_cert"},
   options = {"all", "no_sslv2"},
}

print("open an internet browser at https://127.0.0.1:8888/")
local server = socket.tcp()
server:bind("127.0.0.1", 8888)
server:listen()
local conn,err = server:accept()
-- TLS/SSL initialization
conn = ssl.wrap(conn, params)
conn:dohandshake()
--print(conn:receive("*l"))
ret,err = conn:send("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: 38\r\n\r\n<body><html>Hello World</html></body>")
print("ret",ret,err)
ThreadWait(2000)
conn:close()
