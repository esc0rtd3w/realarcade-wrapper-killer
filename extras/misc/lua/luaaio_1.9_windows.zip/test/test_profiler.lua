require"profiler"

function loop(k)
j=0
for i=1,k do
    j=j+1
end
end

profiler.start("test_profiler.out")
loop(1000000)
loop(5000000)
profiler.stop()

