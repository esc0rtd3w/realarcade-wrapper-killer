require "bz2"

local buffer = "This is the buffer to encode"

print("Buffer to encode = "..buffer.." (length = "..string.len(buffer)..")")
buffer = bz2.encode(buffer,string.len(buffer))
print("Encoded buffer (length = "..string.len(buffer)..") is = "..buffer)
buffer = bz2.decode(buffer,string.len(buffer))
print("Decoded buffer (length = "..string.len(buffer)..") is = "..buffer)


print("")
local filename = "test_bz2_file.bz2"
print("Buffer to encode = "..buffer.." (length = "..string.len(buffer)..") into file "..filename)
buffer = bz2.encode(buffer,string.len(buffer))
local file = io.open(filename,"wb")
file:write(buffer)
file:close()
