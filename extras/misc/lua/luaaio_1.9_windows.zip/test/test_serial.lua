require("serial")

com1 = serial.open( 1, 9600, "8N1", 0 )
if (com1) then
    print("com1 is opened")
else
    print("com1 is not opened")
end
if serial.send(com1, "serial message to send")==true then
    print("message is sent")
    rcv = serial.receive(com1,"\0")
    print("message received is ",rcv)
else
    print("message is not sent")
end
print("closing port com1")
serial.close(com1)

