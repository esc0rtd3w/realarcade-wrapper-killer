print(' socket ================================================')
require("socket")
    local tcp = socket.tcp
    local sock, err = socket.tcp()
    if not sock then 
        print("socket.tcp() : "..err)
    else
        local res, err = sock:connect("127.0.0.1", 8080)
        if not res then 
           print("sock:connect() : "..err)
        else
            local nb, err = sock:send("hello\r\n")
            print(nb.." characters sent")
            sock:close()
        end
    end
print(' socket ================================================')

print(' mime ==================================================')
require"socket"
print((mime.b64("diego:password")))
print((string.gsub(mime.dot(2, ".\r\nStuffing the message.\r\n.\r\n."), "\r\n", "\\n")))
print((mime.qp("ma��")))
print((mime.unb64("ZGllZ286cGFzc3dvcmQ=")))
print((mime.unqp("ma=E7=E3=")))
print(' mime ==================================================')

print(' modules.socket ==========================================')
require"modules.socket"
local con,err = socket.connect("somewhere", 42)
print (con,err)
if con then
    con:send("hello there?\r\n")
    local answer = con:receive()
    con:send("good bye\r\n")
    con:close()
end
print(' modules.socket ==========================================')

print(' modules.http ============================================')
require"modules.http"
a,b,c = http.request{ 
    url = "http://www.cs.princeton.edu/~diego/professional/luasocket/http.html", 
    sink = ltn12.sink.null()
}
print("http.request(http://www.cs.princeton.edu/~diego/professional/luasocket/http.html)\n",a,b,c)
a,b,c = http.request("http://www.example.com/private/index.html")
print("http.request(http://www.example.com/private/index.html)\n",a,b,c)
a,b,c = http.request("http://wrong.host/")
print("http.request(http://wrong.host/)\n",a,b,c)
a,b,c = http.request {
  method = "HEAD",
  url = "http://www.tecgraf.puc-rio.br/~diego"
}
print("http.request(http://www.tecgraf.puc-rio.br/~diego)\n",a,b,c)
a,b,c = http.request("http://fulano:silva@www.example.com/private/index.html")
print("http.request(http://fulano:silva@www.example.com/private/index.html)\n",a,b,c)
a,b,c = http.request {
  url = "http://www.example.com/private/index.html",
  headers = { authentication = "Basic " .. (mime.b64("fulano:silva")) }
}
print("http.request(http://www.example.com/private/index.html)\n",a,b,c)
print(' modules.http ============================================')

print(' modules.ftp =============================================')
require"modules.ftp"
a,b,c = ftp.get("ftp://ftp.tecgraf.puc-rio.br/pub/lua/lua.tar.gz;type=i")
print("ftp.get(ftp://ftp.tecgraf.puc-rio.br/pub/lua/lua.tar.gz;type=i)\n",a,b,c)
a,b,c = ftp.put("ftp://fulano:silva@ftp.example.com/README", 
    "wrong password, of course")
print("ftp.put('ftp://fulano:silva@ftp.example.com/README', 'wrong password, of course')\n",a,b,c)
a,b,c = ftp.put{
  host = "ftp.example.com", 
  user = "fulano",
  password = "silva",
  command = "appe",
  argument = "LOG",
  source = ltn12.source.file(io.open("LOCAL-LOG", "r"))
}
print("ftp.put{...}\n",a,b,c)
print(' modules.ftp =============================================')

print(' modules.smtp ===========================================')
require"modules.smtp"
from = "<luasocket@example.com>"
rcpt = {
  "<fulano@example.com>",
  "<beltrano@example.com>",
  "<sicrano@example.com>"
}
mesgt = {
  headers = {
    to = "Fulano da Silva <fulano@example.com>",
    cc = '"Beltrano F. Nunes" <beltrano@example.com>',
    subject = "My first message"
  },
  body = "I hope this works. If it does, I can send you another 1000 copies."
}
a,b,c = smtp.send{
  from = from,
  rcpt = rcpt, 
  source = smtp.message(mesgt)
}
print("smtp.send{...}\n",a,b,c)
source = smtp.message{
  headers = {
     from = "Sicrano de Oliveira <sicrano@example.com>",
     to = "Fulano da Silva <fulano@example.com>",
     subject = "Here is a message with attachments"
  },
  body = {
    preamble = "If your client doesn't understand attachments, \r\n" ..
               "it will still display the preamble and the epilogue.\r\n" ..
               "Preamble will probably appear even in a MIME enabled client.",
    [1] = { 
      body = mime.eol(0, [[
        Lines in a message body should always end with CRLF. 
        The smtp module will *NOT* perform translation. However, the 
        send function *DOES* perform SMTP stuffing, whereas the message
        function does *NOT*.
      ]])
    },
    [2] = { 
      headers = {
        ["content-type"] = 'image/png; name="image.png"',
        ["content-disposition"] = 'attachment; filename="image.png"',
        ["content-description"] = 'a beautiful image',
        ["content-transfer-encoding"] = "BASE64"
      },
      body = ltn12.source.chain(
        ltn12.source.file(io.open("image.png", "rb")),
        ltn12.filter.chain(
          mime.encode("base64"),
          mime.wrap()
        )
      )
    },
    epilogue = "This might also show up, but after the attachments"
  }
}
a,b,c = smtp.send{
    from = "<sicrano@example.com>",
    rcpt = "<fulano@example.com>",
    source = source,
}
print("smtp.send{...}\n",a,b,c)
print(' modules.smtp ===========================================')

print(' modules.mime ===========================================')
require"modules.mime"
base64 = ltn12.filter.chain(
  mime.encode("base64"),
  mime.wrap("base64")
)
print(base64("test1"))
base64 = ltn12.filter.chain(
  mime.normalize(),
  mime.encode("base64"),
  mime.wrap("base64")
)
print(base64("test2"))
print((mime.b64("diego:password")))
print((string.gsub(mime.dot(2, ".\r\nStuffing the message.\r\n.\r\n."), "\r\n", "\\n")))
print((mime.qp("ma��")))
print((mime.unb64("ZGllZ286cGFzc3dvcmQ=")))
print((mime.unqp("ma=E7=E3=")))
print(' modules.mime ===========================================')

print(' modules.url =============================================')
require"modules.url"
code = url.escape("/#?;")
print(code)
print(' modules.url =============================================')

print(' modules.ltn12 ===========================================')
require"modules.mime"
require"modules.ltn12"
id = ltn12.filter.chain(
  mime.encode("quoted-printable"),
  mime.encode("base64"),
  mime.decode("base64"),
  mime.decode("quoted-printable")
)
print(id("test"))
ltn12.pump.all(
  ltn12.source.file(io.open("original.png")),
  ltn12.sink.file(io.open("copy.png"))
)
print(' modules.ltn12 ===========================================')
