require "xml"

xmltable = xml.parse("test.xml")

function xmldump(child,nb)
    for i = 1,nb do
        if child[i].name then
            print("+ Child tag = "..child[i].name)
        end
        if child[i].n then
            xmldump(child[i],child[i].n)
        end
        if (child[i][1] and type(child[i][1])=="string") then
            print("\t value = "..child[i][1])
        end
        if (child[i].attr and child[i].attr["name"]) then
            print("\t attribute[name] = "..child[i].attr["name"])
        end
    end
end

print("+ Root tag = "..xmltable[1].name)
xmldump(xmltable[1],xmltable[1].n)
