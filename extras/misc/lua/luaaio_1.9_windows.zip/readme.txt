Lua AIO Introduction
--------------------

Lua All In One Distribution is a fast and easy lua distribution which provides OS integrated functionnalities and uses external libraries and modules.

A small editor is provided with this distribution included into the file lua.lua. Moreover examples are available into the test directory.

The compiled HTML Help file (ie. CHM) and Software Development Kit (ie. SDK) are available separately at LuaForge.

Please report bugs and make suggestions to the LuaForge trackers.

Lua AIO Quick Installation for Windows
--------------------------------------

Simply extract the package in the directory of your choice, no other installation process is needed. No file will be introduced into your system directories.
Recommanded directory is C:/Program Files/luaaio/.

Lua AIO Quick Installation for Linux
------------------------------------

Simply extract the package into the recommanded directory "/usr/share/luaaio".
Follow the following installation steps as root user.
# su
# cd /usr/share
# mkdir luaaio
# cd luaaio
# tar zxvf luaaio_x.x_linux.tgz .
# ln -s /usr/share/luaaio/lua /usr/bin/lua

Lua AIO Specific Distribution
-----------------------------

The "lua.exe or lua" executable and "lua.lua" script files can be renamed to anything you want, eg. "myprog.exe or myprog" and "myprog.lua".
For Windows platform only, it is possible to :
  - run the debugging/console interface (-d), fast restart performed with [F1] function key
  - install your program as a windows service (-i)
  - uninstall your program from windows services (-u)
In addition for all platforms, other command line options are available to :
  - test some lua code into the test console (-t)
  - compile some lua files with the lua compiler (-c <file.lua>)
  - execute any specific lua files (<file.lua>)

Everything is configurable through the main "lua.lua" script file, located in the same directory than the executable "lua.exe or lua".

Note for Linux Distribution
---------------------------

It is necessary to start the "lua" executable from the directory where it's located
otherwise the error message "error while loading shared libraries : lua.so" will occur and executable won't start.

Moreover, the "libstdc++5" package shall be manually installed for some Linux distribution (via its package installer)
otherwise the error message "error while loading shared libraries : libstdc++.so.5" will occur and executable won't start.
