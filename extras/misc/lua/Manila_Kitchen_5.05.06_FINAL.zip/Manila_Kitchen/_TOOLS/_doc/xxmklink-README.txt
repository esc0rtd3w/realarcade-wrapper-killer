XXMKLINK README

Kan Yabumoto (tech@xxcopy.com)
2005-03-31


Introduction:

    The Shortcut (a.k.a. Shell Link) is a convenient object in
    Windows' environments that makes everyone's life easier.

    It is trivial to create one.  Most Windows users know how.
    Here are just a few common ways:

    1.  Inside Windows Explorer, highlight an object (file or
        directory) and then Menu > File > Create Shortcut,
        and Bingo!!!   Or, once you have an object highlighted,
        clicking the right mouse button will give you a floating
        menu that has the "Create Shortcut" option.

    2.  Windows Explorer also offers the Menu > File > New > Shortcut
        that opens the "Create Shortcut" wizard which will assist
        you from there.  Alternatively, you may place the mouse
        cursor where you want a new shortcut and obtain the floating
        menu by right mouse click for the New > Shortcut sequence.
 
    Once you create a shortcut, you can further customize the
    appearance and behavior of the shortcut via the property sheet.


From a script (batch file):

    Now, the batch file is a useful way to automate a lot of things.
    Naturally, it would be useful to automate the process of making
    a shortcut using a batch file.  But, we have not seen such
    a tool that can be invoked from a batch file.  In my estimation,
    this is due to the fact that there is no straightforward method
    in the Win32 API.  

    Since creating a shortcut is not an everyday thing, and also
    the ordinary method of making one is so easy that I don't
    expect most peole find this tool very useful.  But, if you
    are an IT professional whose job is to setup a compter
    environment for novice users, you may find this tool useful.
    Because automation is a key to their work efficiency, a
    utility that can be easily incorporated into a batch file
    may find some audience.


Enter XXMKLINK:

    With XXMKLINK, you can write a batch file for software
    installation which has been done by specialized instllation
    programs.  Basically, XXMKLINK is to gather the information
    from a command line and package it into a shortcut.

  Command syntax of XXMKLINK:

    xxmklink spath opath [ arg [ wdir [ desc [ mode [ icon[:n] ]]]]]

    where 
    
      spath     path of the shortcut (.lnk added as needed)
      opath     path of the object represented by the shortcut
      arg       argument string (use quotes with space, see below)
      wdir      path of the working directory (for "Start in")
      desc      description string (shown in Shosrtcut's Properties)
      mode      display mode (1:Normal [default], 3:Maximized, 7:Minimized)
      icon[:n]  icon file [with optional icon index value n]
 
      In addition to the above, the following switches are supported
      which can be placed in any position in the command line.

      /p        prompts before action
      /q        no output when successful (quiet)
      /e        checks error condition strictly

    Note:
 
      Switches (whose first character is always slash) can be placed in
      any position of the command argument.  A string that starts with
      a slash as a non-switch argument must be surrounded by a pair of
      double-quotes (").  It is recommended that the XXMKLINK's switches
      be placed before or after the non-switch arguments for clarity.

      Make sure that each element is surrounded by a pair of
      double-quotes (") if embedded space is present.

      The third field (arg) is for the argument string for the object
      (typically a program that requires command arguments) that must
      be entered as one string here, even if it has many parts that are
      separated by spaces and possibly with double-quote characters.

      When double-quoted string has an embedded double-quote,
      add a backslash in front of each embedded double-qoute.

      Use an empty string (two consecutive double-quotes) as a
      place holder since this command syntax is sensitive to the
      order of the field, optional switches cannot alter the
      predetermined order as defined by the program.

      When an invalid display mode is specified (not 1, 3 nor 7),
      the default (Normal Window) value will be used.

      When the icon specifier does not point to an existing file,
      the icon field will be ignored.

      When the /e switch is present, any error condition will
      result in a failure in creating the shortcut.  The default
      behavior (without /e) which forgives minor error conditions
      (e.g., missing icon file or invalid icon index) is probably
      the preferred outcome in most cases.

      Special cares must be taken when the % character is embedded
      in the path specifier because it has special meaning to the
      command processor (CMD.EXE) --- See below for examples.


  Examples of XXMKLINK command line:
  
      xxmklink "c:\Program Files\mydir\My Shortcut.lnk" c:\boot.ini

         At least two arguments are always needed.


      xxmklink c:\myauto c:\autoexec.bat "/q" . "I say \"Hello.\""

         When the shortcut path is specified without the ".lnk"
         extension, it will be automatically supplied since
         all shortcuts must be so named.  Note that the third
         rgument string, "/q" is entered as a quoted string.  If
         it were without the quotation marks, it would be treated
         as the xxmklink switch, /q, not the argument string for
         the object program.


      xxmklink myshortcut %systemroot%\explorer.exe "" c:\

         When this command is run either directly from the command
         line or from a batch file, the %systemroot% part will be
         replaced by the command line processor (CMD.EXE) immediately
         (before XXMKLINK.EXE has chance to see it) to something
         like C:\WINDOWS which is supplied by the environment variable.

         
      xxmklink myshortcut %%systemroot%%\explorer.exe "" c:\

         When you want the literal string, %systemroot% to be kept
         in the shortcut setting, this command line should be run
         from a batch file where the "escape sequence" (%%) will
         protect the %systemroot% string from the Environment variable
         substitution mechanism.  Note that this command line is
         still subject to the substition when run directly from the
         command line resulting in an undesired outcome.  


Download XXMKLINK:

     XXMKLINK is available for personal use without charge.

     http://www.xxcopy.com/download/xxmklink.zip


