
MTEE v2.0 Win32 Commandline Standard Stream Splitter for NT4/2000/XP/2003.
Copyright (c) 2001-2003 Ritchie Lawrence, http://www.commandline.co.uk.

  MTEE [/A | /U] [/C] [/D] [/T] [[/+] file] [...]

  /A    Convert output to ANSI. Default output is same as input.
  /C    Continue if errors occur opening/writing to file (advanced users only).
  /D    Prefix each line of output with local date in YYYY-MM-DD format.
  /T    Prefix each line of output with local time in HH:MM:SS.MSS format.
  /U    Convert output to UNICODE. Default output is same as input.
  /+    Append to existing file. If omitted, existing file is overwritten.
  file  File to receive the output. File is overwritten if /+ not specified.
  ...   Any number of additional files. Use /+ before each file to append.

  Example usage:-

  1) script.cmd | mtee result.txt
  2) ftp -n -s:ftp.scr | mtee local.log /+ \\server\logs$\remote.log
  3) update.cmd 2>&1 | mtee/d/t/+ log.txt

  1) Sends the output of script.cmd to the console and to result.log. If
     result.txt already exists, it will be overwritten.
  2) Sends output of automated ftp session to the console and two log files,
     local.log is overwritten if it already exists, remote.log is appended to.
  3) Redirects stdout and stderr from update.cmd to console and appends to
     log.txt. Each line is prefixed with local date and time.
