/*
 * OemList.java
 *
 * Created on January 11, 2005, 1:29 PM
 */

/**
 *
 * @author  mbeasley
 */

import java.util.*;

public class StatsList {
/***    
    private HashMap	mapOem;
    
    OemList() {
        mapOem = new HashMap();
	mapOem.put ("default", new OemInfo("oem_default", false, false, "OEM", "OEM"));
    }
    
    public OemInfo GetOemInfo(String strOem) {
	OemInfo info = (OemInfo)mapOem.get(strOem);
	if (info == null) {
	    info = (OemInfo)mapOem.get("default");
	}
	return (info);
    }
***/
}
