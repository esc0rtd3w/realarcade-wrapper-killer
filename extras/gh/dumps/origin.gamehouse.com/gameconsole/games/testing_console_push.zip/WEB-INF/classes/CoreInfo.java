/*
* Copyright 2004  RealNetworks, Inc.
* Author:  Fletch Holmquist
*/

/* $Id: CoreInfo.java,v 1.1.1.1 2005/09/29 00:48:57 mbeasley Exp $
 */

import java.io.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Read the CoreInfo files, substituting tags with data from the query string.
 *
 * @author Fletch Holmquist
 */

public class CoreInfo extends HttpServlet {

    public static final long serialVersionUID = 2005011403L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();
           
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
	TpsList tpsList = null;
        TpsInfo tpsInfo = null;
	GameList gameList = null;
        GameInfo gameInfo = null;
	
        try {
            ResourceBundle rb = ResourceBundle.getBundle("LocalStrings",request.getLocale());
            response.setContentType("text/ascii");
            PrintWriter out = response.getWriter();
    
            String strBundle = request.getParameter("bundle");
            String strTps = request.getParameter("tps");
            String strExistingTps = request.getParameter("existingtps");

	    if (strExistingTps == null) {
		strExistingTps = "null_";
	    }

	    // Append "gtb=..." to install ping if GoogleToolbar is requested
            String strGoogle = "&gtb=none";
	    try {
                String strGoogleToolbar = request.getParameter("gtb");
	        if (strGoogleToolbar != null) {
	            if (strGoogleToolbar.length() < 12) {
		        strGoogle = "&gtb=" + strGoogleToolbar;
	            } else {
                        bundleLogger.logWarning("CoreInfo: Invalid GTB value: " + strGoogleToolbar);
	    		if (tpsInfo != null) {
	        	    tpsInfo.IncWarningCount();
	    		}
		    }
	        }
	    }
            catch (Exception e) {
                bundleLogger.logError("CoreInfo Exception when setting Google toolbar string [" + e.toString() + "]");
	    }	    

	    tpsList = new TpsList();
            tpsInfo = tpsList.GetTpsInfo(strTps);
            strTps = tpsInfo.GetTps();	// in case the TPS was changed

            String strDistCode = tpsInfo.GetDistCode();
            String strTemplate = tpsInfo.GetBundleTemplate();
            String strLang = tpsInfo.GetLang();
            String strCountry = tpsInfo.GetCountry();
    
            // Country Number matches RealPlayer's values, and is shared
            String strCountryNum = "9";
            if (strCountry == "FR") { strCountryNum = "9"; }
            if (strCountry == "DE") { strCountryNum = "9"; }
            if (strCountry == "JP") { strCountryNum = "9"; }
            if (strCountry == "ES") { strCountryNum = "27"; }
            if (strCountry == "MX") { strCountryNum = "18"; }
    
            // If a very short game name is given, give a RAC-only bundle
            if (strBundle == null || strBundle.length() < 2) {
                strBundle = "realarcade";
            }
    
            String strPath = getServletContext().getRealPath("/");
            File fileTemplate = new File(strPath + "WEB-INF/Templates/CoreInfo/" + strTemplate + ".cfg");
            if (fileTemplate == null || fileTemplate.exists() == false || fileTemplate.canRead() == false) {
                // Log the substitution of the default template
                bundleLogger.logWarning("Failed to open CoreInfo.cfg template for " + strTemplate);
	    	if (tpsInfo != null) {
	       	    tpsInfo.IncWarningCount();
	    	}
                // Try to open a default template
                strTemplate = "None";
                fileTemplate = new File(strPath + "WEB-INF/Templates/CoreInfo/" + strTemplate + ".cfg");
                if (fileTemplate == null || fileTemplate.exists() == false || fileTemplate.canRead() == false) {
                    // Log the failure of the substitution of the default template
                    bundleLogger.logError("Failed to open default CoreInfo.cfg template: " + strTemplate);
	    	    if (tpsInfo != null) {
	       	        tpsInfo.IncErrorCount();
	    	    }
                    // Forward to error page
                    // Go to RealArcade.com
                    response.sendRedirect("http://realarcade.com/?badcoreinfo=none");
                }
            }
            if (strTps == null || strTps.endsWith("_") == false) {
                strTps = "bundle_";
            }
            if (strDistCode == null || strDistCode.length() != 4) {
                strDistCode = "WZZZ";
            }
            if (strLang == null || strLang.length() != 2) {
                strLang = "EN";
            }
            if (strCountry == null || strCountry.length() < 2) {
                strCountry = "US";
            }
            if (strCountryNum == null || strCountryNum.length() < 1) {
                strCountryNum = "9";
            }
    
            String strDebug = "NoDebugInfo";
    
            FileInputStream fileStream = new FileInputStream(fileTemplate);
            InputStreamReader inStream = new InputStreamReader(fileStream);
            BufferedReader in = new BufferedReader(inStream);
            String line;
            boolean isPrevLineComment = true;
    
            // Redirect to a HTML file if load testing
            String strIsLoadTest = request.getParameter("loadtest");
            if (strIsLoadTest != null && strIsLoadTest.equals("true")) {
                response.setContentType("text/html");
                response.sendRedirect("http://games-dl.real.com/gameconsole/BundleFiles/Support/StubForTest.html");
        	return;
            }

            // Cookie
            String strCookieName = "RealArcadeInstall";
            String strCookieValue = "";
            Cookie cookie = null;
            Cookie[] cookies = request.getCookies();
            if ((cookies != null) && (cookies.length > 0)) {
                for (int i = 0; i < cookies.length; i++) {
                    cookie = cookies[i];
                    if (strCookieName.equals(cookie.getName())) {
    	                strCookieValue = cookie.getValue();

                        if (strCookieValue.startsWith("&origTPS=") == false) {
                            strCookieValue = "&badcookie=1";
                        }
    		    }
                }
            }

            String strSrc = "nocookie";
	    if (cookie != null) {
		strSrc = "blank";
	        if (strCookieValue.indexOf("&src=") != -1) {
	            strSrc = strCookieValue.replaceFirst("^.*\\&src=", "");
	            strSrc = strSrc.replaceFirst("\\&.*$", "");
	        }
	    }
	    if (strSrc == null || strSrc == "") {
	        strSrc = "cookie-error";
	    }
	    // Make sure SRC string is OK
	    if (strSrc.length() > 128) {
		strSrc = strSrc.substring(0, 127);
	    }

            // This can be made into a single-pass algorithm, but works well as is
            while ((line = in.readLine()) != null) {
                if (line.length() > 0) {
                    if (line.charAt(0) == '#') {
                        if (line.charAt(1) == '#' && isPrevLineComment == false) {
                            out.println("");
                        }
                        isPrevLineComment = true;
                    } else {
                        isPrevLineComment = false;
                    }
                    if (line.charAt(0) == '[') {
                        out.println("");
                    }
                    line = line.replaceAll("\\$\\{BUNDLE\\}", strBundle);
                    line = line.replaceAll("\\$\\{TPS\\}", strTps);
                    line = line.replaceAll("\\$\\{DISTCODE\\}", strDistCode);
                    line = line.replaceAll("\\$\\{LANG\\}", strLang);
                    line = line.replaceAll("\\$\\{TEMPLATE\\}", strTemplate);
                    line = line.replaceAll("\\$\\{COUNTRY\\}", strCountry);
                    line = line.replaceAll("\\$\\{COUNTRYNUM\\}", strCountryNum);
                    line = line.replaceAll("\\$\\{DEBUG\\}", strDebug);
                    line = line.replaceAll("\\$\\{COOKIE\\}", strCookieValue);
                    line = line.replaceAll("\\$\\{SRC\\}", strSrc);
                    line = line.replaceAll("\\$\\{GTB\\}", strGoogle);
                    line = line.replaceAll("\\$\\{EXISTINGTPS\\}", strExistingTps);
    
                    out.println(line);
		}
            }
	    // Increment the count for this TPS 
 	    if (tpsInfo != null) {
	        tpsInfo.IncCoreInfoCount();
            }
	    // Increment the count of games served
	    if (strBundle != null && strBundle.length() > 1) {
                try {
	            gameList = new GameList();
                    gameInfo = gameList.GetGameInfo(strBundle);
	            gameInfo.IncCoreInfoCount();
		}
	        catch (Exception e) {
                    bundleLogger.logWarning("CoreInfo: (TRACKING): Cannot increment game count: " + strBundle);
	        }
	    }
        }
        catch (IOException e) {
	    if (tpsInfo != null) {
	        tpsInfo.IncErrorCount();
	    }
            bundleLogger.logError("CoreInfo IOException [" + e.toString() + "]: TPS=" + request.getParameter("tps"));
            response.sendError(404);
        }
        catch (Exception e) {
	    if (tpsInfo != null) {
	        tpsInfo.IncErrorCount();
	    }
            bundleLogger.logError("CoreInfo Exception [" + e.toString() + "]: TPS=" + request.getParameter("tps"));
            response.sendError(404);
        }
    }
}

