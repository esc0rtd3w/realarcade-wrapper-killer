/*
* Copyright 2004  RealNetworks, Inc.
* Author:  Fletch Holmquist
*/

/* $Id: InstallNotes.java,v 1.1.1.1 2005/09/29 00:48:57 mbeasley Exp $
 */

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.Format;
import java.text.DateFormat;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Return the text used for Arcade Install Notes.
 *
 * @author Fletch Holmquist
 */

public class InstallNotes extends HttpServlet {

    public static final long serialVersionUID = 200506091L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();
    private static DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss");

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        response.setContentType("text/ascii");
        PrintWriter out = response.getWriter();
	
	TpsList tpsList = new TpsList();
        GameList gameList = new GameList();
	TpsInfo tpsInfo = null;
	GameInfo gameInfo = null;
	    
	String strQueryString = request.getQueryString();
	if (strQueryString == null) {
	    strQueryString = "";
	}

        try {
            // Cookie
            String strCookieName = "RealArcadeInstall";
            String strCookieValue = "";
            Cookie cookie = null;
            int count = 0;
            Cookie[] cookies = request.getCookies();
            if ((cookies != null) && (cookies.length > 0)) {
                for (int i = 0; i < cookies.length; i++) {
                    cookie = cookies[i];
                    if (strCookieName.equals(cookie.getName())) {
            	        strCookieValue = cookie.getValue();
            	    }
                }
            }
            cookie = new Cookie(strCookieName, strCookieValue);
            if (strCookieValue.length() < 4) {
		// Do not create cookie, as RealArcade does not send it properly
		if (false) {
                    Date now = new Date();
                    String strArcadeInstalled;
                    strCookieValue = "&arcadeinstalled=0&installping=" + dateFormat.format(now);
                    bundleLogger.logWarning("Install Notes (Cookie): Created Cookie: " + strCookieValue + ", QS=" + strQueryString);
		}
	    }
	    else if (strCookieValue.indexOf("arcadeinstalled=") == -1) {
                strCookieValue = strCookieValue + "&arcadeinstalled=0";
                bundleLogger.logWarning("Install Notes (Cookie): Appended to deficient Cookie: " + strCookieValue);
            } else {
                String strCount = strCookieValue.replaceFirst("^.*arcadeinstalled=", "");
		strCount = strCount.replaceFirst("&.*$", "");
                try {
                    count = Integer.parseInt(strCount);
                } catch (NumberFormatException nfe) {
                    count = 20000;
                }
                strCookieValue = strCookieValue.replaceFirst("arcadeinstalled=[0-9]*", "arcadeinstalled=" + String.valueOf(count + 1));
                cookie.setValue(strCookieValue);

		// Also update the query string
		if (count == 0) {
		    strQueryString = strQueryString.replaceFirst("arcadeinstalled=0", "arcadeinstalled=0");
		} else if (count == 1) {
		    strQueryString = strQueryString.replaceFirst("arcadeinstalled=0", "arcadeinstalled=1");
		} else if (count > 1 && count < 1000) {
		    strQueryString = strQueryString.replaceFirst("arcadeinstalled=[0-9]*", "arcadeinstalled=1+");
		} else {
		    strQueryString = strQueryString.replaceFirst("arcadeinstalled=0", "arcadeinstalled=unknown");
		}

                bundleLogger.logWarning("Install Notes (Cookie): Updated cookie: " + strCookieValue);
            }
	    if (strCookieValue != null && strCookieValue.length() > 2) {
                cookie.setMaxAge(30 * 24 * 60 * 60);
                cookie.setValue(strCookieValue);
                response.addCookie(cookie);
	    }

       	    // Increment the count of games served
            String strBundle = request.getParameter("bundle");
	    if (strBundle != null && strBundle.length() > 1) {
                try {
	            gameList = new GameList();
                    gameInfo = gameList.GetGameInfo(strBundle);
		    if (count > 0) {
	                gameInfo.IncOverInstalledCount();
		    } else {
	                gameInfo.IncInstalledCount();
		    }
		}
	        catch (Exception e) {
                    bundleLogger.logWarning("Install Notes: Cannot increment game count: " + strBundle);
	        }
	    }
            String strTps = request.getParameter("tps");
	    if (strTps != null && strTps.length() > 1) {
                try {
	            tpsList = new TpsList();
                    tpsInfo = tpsList.GetTpsInfo(strTps);
		    if (count > 0) {
	                tpsInfo.IncOverInstalledCount();	// Broken out by TPS
			tpsList.IncOverInstalledTps();		// Total for all TPSs
		    } else {
	                tpsInfo.IncInstalledCount();
			tpsList.IncInstalledTps();
		    }
		}
	        catch (Exception e) {
                    bundleLogger.logWarning("Install Notes: Cannot increment tps count: " + strBundle);
	        }
	    }
        }
        catch (Exception e) {
            bundleLogger.logError("InstallNotes Exception [" + e.toString() + "]");
        }

	if (strQueryString == null || strQueryString.indexOf("online/install") == -1) {
	    strQueryString = "file=online/install/LOST";
	}
       	response.sendRedirect("http://switchboard.real.com/arcade/download.html?" + strQueryString);
    }
}
