/*
* Copyright 2004  RealNetworks, Inc.
* Author:  Fletch Holmquist
*/

/* $Id: BundlePayload.java,v 1.2 2005/11/02 19:59:30 mbeasley Exp $
 */

import java.io.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Read the CoreInfo files, substituting tags with data from the query string.
 *
 * @author Fletch Holmquist
 */

public class BundlePayload extends HttpServlet {

    private static BundleLogger bundleLogger = BundleLogger.getInstance();
    public static final long serialVersionUID = 2005011402L;
    
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        ResourceBundle rb = ResourceBundle.getBundle("LocalStrings",request.getLocale());
        response.setContentType("text/xml");
        PrintWriter out = response.getWriter();

        try {
            String strBundle = request.getParameter("bundle");
            String strTps = request.getParameter("tps");
            String strDistCode = request.getParameter("distcode");
            String strLang = request.getParameter("lang");
            String strCountry = request.getParameter("country");
            String strTemplate = request.getParameter("template");
            String strExistingTps = request.getParameter("existingtps");
	    
            TpsList tpsList = new TpsList();
            TpsInfo tpsInfo = tpsList.GetTpsInfo(strTps);
            strTps = tpsInfo.GetTps();	// in case the TPS was changed

            strDistCode = tpsInfo.GetDistCode();
            strTemplate = tpsInfo.GetBundleTemplate();
            strLang = tpsInfo.GetLang();
            strCountry = tpsInfo.GetCountry();
    
	    if (strExistingTps == null) {
		strExistingTps = "null_";
	    }
	    
            // Append "_google" to template if GoogleToolbar is requested  [FNH: Obsolete]
            String strGoogle = "";
            String strStubbyVersion = request.getParameter("ver");
            String strArchive = "";
            try {
                if (strStubbyVersion != null) {
	            if (strStubbyVersion.startsWith("1.1.") || strStubbyVersion.startsWith("1.2.")) {
                        // strGoogle = "_google";
                    } else {
                        bundleLogger.logError("BundlePayload: Invalid Stubby Version value: " + strStubbyVersion);
			            // TODO: Give default payload file
                    }
	             }
                else{
                	strArchive = "archive/";
                }
                	
     

		if (strBundle != null && strBundle.startsWith("nooverinstall")) {
		    out.println("<?xml version='1.0' encoding='UTF-8' ?>");
		    out.println("<ArcadeBundle overwrite='true' >");
		    out.println(" <NoOverInstall>");
		    out.println("  <MsgText>This is the message text</MsgText>");
		    out.println("  <MsgTitle>This is the message title</MsgTitle>");
		    out.println(" </NoOverInstall>");
		    out.println("</ArcadeBundle>");

                    bundleLogger.logWarning("BundlePayload: No OverInstall Message");
		    return;
		}
            }
            catch (Exception e) {
                bundleLogger.logError("BundlePayload Exception when setting Google toolbar string [" + e.toString() + "]");
            }

            GameList gameList = new GameList();
            GameInfo gameInfo = gameList.GetGameInfo(strBundle);

            if (strBundle == null) {
                bundleLogger.logWarning("BundlePayload: Invalid game = " + strBundle);
                response.sendError(404);
		return;
            }
            strBundle = gameInfo.GetGameId();
    
            String strPath = getServletContext().getRealPath("/");
            String strStandalone = "";
    	    strTemplate = strTemplate + strStandalone;
            
	    
            File fileTemplate = new File(strPath + "WEB-INF/Templates/BundlePayload/" + strArchive + strTemplate +  strGoogle + ".xml");
            if (fileTemplate == null || fileTemplate.exists() == false || fileTemplate.canRead() == false) {
                // Log the substitution of the default template
                bundleLogger.logWarning("Failed to open Bundle.xml template for " + strPath + 
				        "WEB-INF/Templates/BundlePayload/" +  strArchive + strTemplate + strGoogle + ".xml");
                strTemplate = "None";
                fileTemplate = new File(strPath + "WEB-INF/Templates/BundlePayload/" + strTemplate + strGoogle + ".xml");
                if (fileTemplate == null || fileTemplate.exists() == false || fileTemplate.canRead() == false) {
                    bundleLogger.logError("Failed to open default Bundle.xml template for " + strPath +
				          "WEB-INF/Templates/BundlePayload/" +  strTemplate + strGoogle + ".xml");
                    response.sendError(404);
                    return;
                }
            }
            if (strTps == null || strTps.endsWith("_") == false) {
                strTps = "bundle_";
            }
            if (strDistCode == null || strDistCode.length() != 4) {
                strDistCode = "WZZZ";
            }
            if (strLang == null || strLang.length() != 2) {
                strLang = "EN";
            }
            if (strCountry == null || strCountry.length() < 2) {
                strCountry = "US";
            }
            
 
            String strFullGameName = gameInfo.GetFullGameName();
            String strGameGuid = gameInfo.GetGameGuid();
            String strExitAdName = gameInfo.GetExitAdName();
            String strWrapperVersion = gameInfo.GetWrapperVersion();
 
            // Redirect to a HTML file if load testing
	    String strIsLoadTest = request.getParameter("loadtest");
            if (strIsLoadTest != null && strIsLoadTest.equals("true")) {
                response.setContentType("text/html");
	        response.sendRedirect("http://games-dl.real.com/gameconsole/BundleFiles/Support/StubForTest.html");
		return;
            }
	    
	    boolean boolSkip = false;
            FileInputStream fileStream = new FileInputStream(fileTemplate);
            InputStreamReader inStream = new InputStreamReader(fileStream);
            BufferedReader in = new BufferedReader(inStream);
            String line;

            while ((line = in.readLine()) != null) {
		if (line.indexOf("-- Start of GameData --") != -1) {
		    if (strBundle.equals("realarcade") == true) {
		        boolSkip = true;
			out.println("<!-- Skipping Game Data -->");
		    }
		} else if (line.indexOf("-- End of GameData --") != -1) {
		    boolSkip = false;
		}else if (boolSkip == false) {
                    if (line.indexOf("${") != -1) {
                        line = line.replaceAll("\\$\\{BUNDLE\\}", strBundle);
                        line = line.replaceAll("\\$\\{FULLNAME\\}", strFullGameName.replaceAll("\\$", "\\\\\\$"));
                        line = line.replaceAll("\\$\\{EXITAD\\}", strExitAdName);
                        line = line.replaceAll("\\$\\{WRAPPERVER\\}", strWrapperVersion);
                        line = line.replaceAll("\\$\\{TPS\\}", strTps);
                        line = line.replaceAll("\\$\\{DISTCODE\\}", strDistCode);
                        line = line.replaceAll("\\$\\{LANG\\}", strLang);
                        line = line.replaceAll("\\$\\{TEMPLATE\\}", strTemplate);
                        line = line.replaceAll("\\$\\{COUNTRY\\}", strCountry);
                        line = line.replaceAll("\\$\\{EXISTINGTPS\\}", strExistingTps);
		    }
                    out.println(line);
                }
            }
	    if (boolSkip == true) {
		                bundleLogger.logWarning("(ERROR) BundlePayload Template Syntax [expecting End of GameData]"+ 
                                  ": TPS=" + request.getParameter("tps") +
                                  ", Bundle=" + request.getParameter("bundle"));
	    }
        }
        catch (IOException e) {
            bundleLogger.logWarning("(TRACKING) BundlePayload IOException [" + e.toString() + 
                                  "]: TPS=" + request.getParameter("tps") +
                                  ", Bundle=" + request.getParameter("bundle"));
            response.sendError(404);
        }
        catch (Exception e) {
            bundleLogger.logWarning("(TRACKING) BundlePayload Exception [" + e.toString() + 
                                  "]: TPS=" + request.getParameter("tps") +
                                  ", Bundle=" + request.getParameter("bundle"));
            response.sendError(404);
	}
    }
}

