/*
* Copyright 2004  RealNetworks, Inc.
* Author:  Fletch Holmquist
*/

/* $Id: TpsStatsPage.java,v 1.1.1.1 2005/09/29 00:48:57 mbeasley Exp $
 */

import java.io.*;
import java.util.*;
import java.util.Date;
import java.text.Format;
import java.text.DateFormat;
import java.text.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Read the TpsStatsPage files, substituting tags with data from the query string.
 *
 * @author Fletch Holmquist
 */

public class TpsStatsPage extends HttpServlet {

    public static final long serialVersionUID = 2005052401L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();
    private static String strDate = null;

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        try {
            ResourceBundle rb = ResourceBundle.getBundle("LocalStrings",request.getLocale());
            response.setContentType("text/xml");
            PrintWriter out = response.getWriter();

	    if (strDate == null) {
	        strDate = Calendar.getInstance().getTime().toString();
            }

	    TpsList tpsList = new TpsList();
	    GameList gameList = new GameList();
    
            out.println("<?xml version='1.0' encoding='UTF-8' ?>");
            out.println("<BundleStats starttime='" + strDate + "'>");
            out.println(" <TpsSummary>");
            out.println("  <Total count='" + tpsList.GetStats("total") + "' />");
            out.println("  <InvalidTps count='" + tpsList.GetStats("invalid") + "' />");
            out.println("  <NullTps count='" + tpsList.GetStats("null") + "' />");
            out.println("  <BlankTps count='" + tpsList.GetStats("blank") + "' />");
            out.println("  <TruncatedTps count='" + tpsList.GetStats("truncated") + "' />");
            out.println("  <NoUnderscoreTps count='" + tpsList.GetStats("nounderscore") + "' />");
            out.println("  <Installed count='" + tpsList.GetStats("installed") + "' />");
            out.println("  <OverInstalled count='" + tpsList.GetStats("overinstalled") + "' />");
            out.println(" </TpsSummary>");
	    
	    // Get the stats for each TPS
            out.println(tpsList.GetTpsStatsXml());
	    
	    // Get the stats for each game
            out.println(gameList.GetGameStatsXml());
	    
            out.println("</BundleStats>");
        }
        catch (Exception e) {
            bundleLogger.logError("TpsStatsPage Exception [" + e.toString() + "]");
        }
    }
}

