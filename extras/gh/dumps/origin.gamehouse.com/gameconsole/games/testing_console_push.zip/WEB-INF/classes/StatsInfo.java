/*
 * StatsInfo.java
 *
 * Created on January 11, 2005, 1:29 PM
 */

/**
 *
 * @author  fholmquist
 */


public class StatsInfo {
    private static int  iInfoCount;
    private static int  iWarningCount;
    private static int  iErrorCount;
    private static int  iRequestCount;
    private static int  iCoreInfoCount;
    
    StatsInfo() {
	    iInfoCount = 0;
	    iWarningCount = 0;
	    iErrorCount = 0;
	    iRequestCount = 0;
	    iCoreInfoCount = 0;
    }

    public void AddInfo()
    {
	iInfoCount++;
    }

    public void AddWarning()
    {
	iWarningCount++;
    }

    public void AddError()
    {
	iErrorCount++;
    }

    public void AddRequest()
    {
	iRequestCount++;
    }

    public void AddCoreInfo()
    {
	iCoreInfoCount++;
    }
/***	
    private static int	iNumElements = [24 * 60 * 12];	// Five minute intervals
    private String	strDesc;
    private int 	iCountSuccess[iNumElements];
    private int 	iCountFailure[iNumElements];
    private int 	iCountWarning[iNumElements];

    StatsInfo(String desc) {
	for (int i = 0; i < iNumElements; i++) {
            iCountSuccess[i] = -1;
            iCountFailure[i] = -1;
            iCountWarning[i] = -1;
	}
        strDesc = desc;
    }
***/
}
