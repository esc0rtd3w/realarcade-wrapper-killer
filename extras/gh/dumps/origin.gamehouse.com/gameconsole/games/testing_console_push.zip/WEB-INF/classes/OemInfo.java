/*
 * OemInfo.java
 *
 * Created on January 11, 2005, 1:29 PM
 */

/**
 *
 * @author  mbeasley
 */


public class OemInfo {
    
    private String	strTps;
    private int 	iCount;
    private boolean	boolHasTabImages;
    private boolean	boolHasPngUpdate;
    private String	strOemTag;
    private String	strOemUrl;

    OemInfo(String tps, boolean images, boolean update, String tag, String url) {
        strTps = tps;
        iCount = 1;
        boolHasTabImages = images;
        boolHasPngUpdate = update;
        strOemTag = tag;
       	strOemUrl = url;
    }
}
