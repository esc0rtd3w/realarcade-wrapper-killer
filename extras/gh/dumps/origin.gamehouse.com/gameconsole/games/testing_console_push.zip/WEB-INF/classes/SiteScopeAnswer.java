/*
* Copyright 2005  RealNetworks, Inc.
* Author:  Fletch Holmquist & Matt Beasley
*/

/* $Id: SiteScopeAnswer.java,v 1.0 2005/01/26 16:40:33 mbeasley
 */

import java.io.*;

// Standard includes for a servlet
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Logging support for the RealArcade Bundle download process.
 * Real time error reports to Site Scope.
 *
 * @author Fletch Holmquist & Matt Beasley
 */

/*
 * Uses JDK 1.4 Logging
 */

public class SiteScopeAnswer extends HttpServlet {

    public static final long serialVersionUID = 2005011405L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance(); //calls singeton instance
    
    /** Initializes the servlet.
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }
    
    /** Destroys the servlet.
     */
    public void destroy() {
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	
    	//display the results
    	String answer = bundleLogger.returnErrors();
    	response.setContentType("text/ascii");
        PrintWriter out = response.getWriter();
        out.print(answer);
    }
    
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Returns any logged errors to SiteScope for reporting.";
    }
    
}