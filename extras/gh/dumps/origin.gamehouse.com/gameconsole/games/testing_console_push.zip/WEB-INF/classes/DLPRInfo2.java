/*
* Copyright 2007  RealNetworks, Inc.
* Author:  Vijay Dirisala
*/

/* $Id: DLPRInfo2.java,v 1.3 2007/11/21 09:56:32 vijaydir Exp $
 */

import java.io.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * TODO
 *
 * @author Vijay Dirisala
 */

public class DLPRInfo2 extends HttpServlet {
    public static final long serialVersionUID = 200711191905L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();

	private TpsList tpsList = null;
	private Vector googleTemplates = new Vector();
	private Vector firefoxTemplates = new Vector();
	private String gtbUrl = null;
	private String gdsUrl = null;
	private String ffUrl = null;
	private int numOffers = 3;

	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		System.out.println("\nInitializing DLPRInfo2 class...\n");
		ServletContext context = config.getServletContext();
		String sgoogleTemplates = context.getInitParameter("GOOGLE_TEMPLATES");
		if (null != sgoogleTemplates)
		{
			StringTokenizer st = new StringTokenizer(sgoogleTemplates, ",", false);
			while (st.hasMoreTokens())
			{
				String buffer = st.nextToken();
				buffer = buffer.trim();
				System.err.println("Adding google template = " + buffer);
				googleTemplates.add(buffer);
			}
		}
		String sfirefoxTemplates = context.getInitParameter("FIREFOX_TEMPLATES");
		if (null != sfirefoxTemplates)
		{
			StringTokenizer st = new StringTokenizer(sfirefoxTemplates, ",", false);
			while (st.hasMoreTokens())
			{
				String buffer = st.nextToken();
				buffer = buffer.trim();
				System.err.println("Adding firefox template = " + buffer);
				firefoxTemplates.add(buffer);
			}
		}
		gdsUrl = context.getInitParameter("DLPR_GDS_PAYLOAD_URL");
		System.err.println("GDS Url = " + gdsUrl);
		gtbUrl = context.getInitParameter("DLPR_GTB_PAYLOAD_URL");
		System.err.println("GTB Url = " + gtbUrl);
		ffUrl = context.getInitParameter("DLPR_FF_PAYLOAD_URL");
		System.err.println("FF Url = " + ffUrl);
		try
		{
			numOffers = Integer.parseInt(context.getInitParameter("GOOGLE_NUMOFFERS"));
			System.err.println("NumOffers: " + numOffers);
		}
		catch (Exception ex) {
			bundleLogger.logError("Excepting during DLPRInfo2 initialization: " + ex.toString());
			ex.printStackTrace();
		}

		// Load the lists, since this servlet gets loaded at start-up
		tpsList = new TpsList();
	}

	boolean isGoogleTemplate(String bundleTemplate)
	{
		System.err.println("Testing " + bundleTemplate);
		for (int i = 0; i < googleTemplates.size(); i++)
		{
			String templateName = (String)googleTemplates.get(i);
			//System.err.println("Testing against " + templateName);
			if (bundleTemplate.equals(templateName))
				return true;
		}
		//System.err.println("No match!");
		return false;
	}

	boolean isFirefoxTemplate(String bundleTemplate)
	{
		System.err.println("Testing " + bundleTemplate);
		for (int i = 0; i < firefoxTemplates.size(); i++)
		{
			String templateName = (String)firefoxTemplates.get(i);
			//System.err.println("Testing against " + templateName);
			if (bundleTemplate.equals(templateName))
				return true;
		}
		//System.err.println("No match!");
		return false;
	}

	void sendNoOfferResponse(PrintWriter out)
	{
		out.println("[DLPRInfo2]");
		out.println("Offer=0");
	}

	String getPayloadUrl(TpsInfo tpsInfo, String url)
	{
		String strLang = tpsInfo.GetLang();
		return url.replaceAll("\\$\\{LANG\\}", strLang);
	}

	boolean sendGDSOffer(TpsInfo tpsInfo, PrintWriter out)
	{
		try{
			out.println("[DLPRInfo2]");
			out.println("Offer=gds");
			out.println("Lang=" + tpsInfo.GetLang());
			out.println("Times=" + numOffers);
			out.println("GtbUrl=" + getPayloadUrl(tpsInfo, gtbUrl));
			out.println("GdsUrl=" + getPayloadUrl(tpsInfo, gdsUrl));
			return true;
		}
		catch(Exception ex){
			bundleLogger.logWarning("(TRACKING) DLPRInfo2 exception sending GDS offer: " + ex.toString());
			ex.printStackTrace();
			return false;
		}
	}
	boolean sendGTBOffer(TpsInfo tpsInfo, PrintWriter out)
	{
		try{
			out.println("[DLPRInfo2]");
			out.println("Offer=gtb");
			out.println("Lang=" + tpsInfo.GetLang());
			out.println("Times=" + numOffers);
			out.println("GtbUrl=" + getPayloadUrl(tpsInfo, gtbUrl));
			return true;
		}
		catch (Exception ex)
		{
			bundleLogger.logWarning("(TRACKING) DLPRInfo2 exception sending GTB offer: " + ex.toString());
			ex.printStackTrace();
			return false;
		}
	}
	boolean sendFFOffer(TpsInfo tpsInfo, PrintWriter out)
	{
		try{
			out.println("[DLPRInfo2]");
			out.println("Offer=ff");
			out.println("Lang=" + tpsInfo.GetLang());
			out.println("Times=" + numOffers);
			out.println("FfUrl=" + getPayloadUrl(tpsInfo, ffUrl));
			return true;
		}
		catch(Exception ex){
			bundleLogger.logWarning("(TRACKING) DLPRInfo2 exception sending FF offer: " + ex.toString());
			ex.printStackTrace();
			return false;
		}
	}
	
    int getParameterAsInt(HttpServletRequest request, String param)
    {
		try{
			String paramvalue = request.getParameter(param);
			return Integer.parseInt(paramvalue);
		}
		catch (Exception ex)
		{
			bundleLogger.logWarning("(TRACKING) DLPRInfo2 invalid parameter " + param + "; defaulting to 0");
			return 0;
		}
    }
    
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
		try
		{
			ResourceBundle rb = ResourceBundle.getBundle("LocalStrings", request.getLocale());
			response.setContentType("text/plain");
			PrintWriter out = response.getWriter();

			String strTps = request.getParameter("tps"); // TODO: if no tps
			System.err.println("TPS for request is " + strTps);
			TpsInfo tpsInfo = tpsList.GetTpsInfo(strTps);
			strTps = tpsInfo.GetTps();	// in case the TPS was changed

			String strTemplate = tpsInfo.GetBundleTemplate();
			System.err.println("Template for request is " + strTemplate);
			boolean bGoogleTemplate = isGoogleTemplate(strTemplate);
			boolean bFirefoxTemplate = isFirefoxTemplate(strTemplate) || "dandummy_".equals(strTps);
			if (bGoogleTemplate || bFirefoxTemplate)
			{
				int igtb = getParameterAsInt(request, "gtb");
				int igds = getParameterAsInt(request, "gds");
				int iff = getParameterAsInt(request, "ff");
				if(igtb <= 0 && igds <= 0){
					System.err.println("User gets GDS");
					sendGDSOffer(tpsInfo, out);
				}
				else if(igtb <= 0){
					System.err.println("User gets GTB");
					sendGTBOffer(tpsInfo, out);
				}
				else if(bFirefoxTemplate && iff <= 0){
					System.err.println("User gets FF");
					sendFFOffer(tpsInfo, out);
				}
				else{
					System.err.println("User doesn't get an offer");
					sendNoOfferResponse(out);
				}
				return;
			}
			sendNoOfferResponse(out);
		}
		catch (IOException ex)
		{
			bundleLogger.logWarning("(TRACKING) DLPRInfo2 IOException [" + ex.toString() +
								  "]: TPS=" + request.getParameter("tps") );
			ex.printStackTrace();
			response.sendError(404);
		}
		catch (Exception ex)
		{
			bundleLogger.logWarning("(TRACKING) DLPRInfo2 Exception [" + ex.toString() +
								  "]: TPS=" + request.getParameter("tps") );
			ex.printStackTrace();
			response.sendError(404);
		}
    }
}
