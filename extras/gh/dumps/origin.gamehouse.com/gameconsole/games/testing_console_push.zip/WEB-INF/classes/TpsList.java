/*
 * TpsList.java
 *
 * Created on January 11, 2005, 1:48 PM
 */

/**
 *
 * @author  mbeasley
 */

import java.util.*;


public class TpsList {

    private static HashMap mapTps;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();

    private static int countTps;
    private static int countInstalledTps;
    private static int countOverInstalledTps;
    private static int countDefaultTps;
    private static int countNullTps;
    private static int countBlankTps;
    private static int countNoUnderscoreTps;
    private static int countTruncatedTps;
    private static int countInvalidTps;

    TpsList() {
      if (mapTps == null) {
        mapTps = new HashMap();
        mapTps.put ("default", new TpsInfo("bundle_", "W000", "EN", "US", "prod.rnwk", "Default"));
        // All other TPSs are added below
        mapTps.put ("121media_", new TpsInfo("121media_", "WFG0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("a8-jp_", new TpsInfo("a8-jp_", "IJR1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("aarp_", new TpsInfo("aarp_", "WJA0", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("ab_", new TpsInfo("ab_", "W3G0", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("accelerat_", new TpsInfo("accelerat_", "WA50", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("adelphia_", new TpsInfo("adelphia_", "W4P0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("ad-jp_", new TpsInfo("ad-jp_", "IJP1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("adteracgp_", new TpsInfo("adteracgp_", "WD40", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("adtr-us_", new TpsInfo("adtr-us_", "WEU0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("advert_", new TpsInfo("advert_", "W1Z0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("ag_", new TpsInfo("ag_", "W220", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("alawar_", new TpsInfo("alawar_", "WCJ0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("alc_", new TpsInfo("alc_", "IA21", "JP", "JP", "prod.acquisition", "Standard"));
        mapTps.put ("allgames_", new TpsInfo("allgames_", "WEN0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("alltel_", new TpsInfo("alltel_", "W2D0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("alltel2_", new TpsInfo("alltel2_", "WK90", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("alltelrb_", new TpsInfo("alltelrb_", "WKH0", "EN", "US", "prod.partner", "StandardNG"));
        mapTps.put ("altech-jp_", new TpsInfo("altech-jp_", "IJF1", "JP", "JP", "prod.partner", "Standard_JP"));
        mapTps.put ("amazon_", new TpsInfo("amazon_", "WK20", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("ambient_", new TpsInfo("ambient_", "W7H0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("ambientv2_", new TpsInfo("ambientv2_", "WKA0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("amerbaby_", new TpsInfo("amerbaby_", "W9B0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("amex_", new TpsInfo("amex_", "W6X0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("animal_", new TpsInfo("animal_", "WHP0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("aolsearch_", new TpsInfo("aolsearch_", "WGV0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("aolstvp_", new TpsInfo("aolstvp_", "WG60", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("ap_", new TpsInfo("ap_", "W2W0", "AP", "AP", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("ap-cl_", new TpsInfo("ap-cl_", "WEC0", "AP", "AP", "prod.partner", "Standard"));
        mapTps.put ("ap-fc_", new TpsInfo("ap-fc_", "WF10", "AP", "AP", "prod.rnwk", "Standard"));
        mapTps.put ("aptest_", new TpsInfo("aptest_", "WC60", "AP", "AP", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("asia_", new TpsInfo("asia_", "W5S0", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("asiaengeo_", new TpsInfo("asiaengeo_", "W6C0", "AP", "AP", "prod.rnwk", "Standard"));
        mapTps.put ("atlantic_", new TpsInfo("atlantic_", "WJ30", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("att_", new TpsInfo("att_", "W3R0", "EN", "US", "prod.partner", "ATTWorldNet"));
        mapTps.put ("att2_", new TpsInfo("att2_", "W3RX", "EN", "US", "prod.partner", "ATTWorldNet2"));
        mapTps.put ("attv2_", new TpsInfo("attv2_", "WK10", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("au_", new TpsInfo("au_", "A070", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("au2_", new TpsInfo("au2_", "WBF0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("au2-ap_", new TpsInfo("au2-ap_", "WBG0", "AP", "AP", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-br_", new TpsInfo("au2-br_", "WBH0", "BR", "BR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-de_", new TpsInfo("au2-de_", "IDF2", "DE", "DE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-es_", new TpsInfo("au2-es_", "ISH4", "ES", "ES", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-eu_", new TpsInfo("au2-eu_", "WBI0", "EU", "SE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-fr_", new TpsInfo("au2-fr_", "IFI3", "FR", "FR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-it_", new TpsInfo("au2-it_", "WBJ0", "IT", "IT", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-jp_", new TpsInfo("au2-jp_", "IJH1", "JP", "JP", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-kr_", new TpsInfo("au2-kr_", "WBK0", "EN", "KR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-mx_", new TpsInfo("au2-mx_", "ISM4", "MX", "MX", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-nl_", new TpsInfo("au2-nl_", "WBL0", "NL", "NL", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-se_", new TpsInfo("au2-se_", "WBM0", "EU", "SE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au2-uk_", new TpsInfo("au2-uk_", "WBN0", "UK", "GB", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("au-de_", new TpsInfo("au-de_", "ID22", "DE", "DE", "prod.rnwk", "Standard"));
        mapTps.put ("au-es_", new TpsInfo("au-es_", "IS24", "ES", "ES", "prod.rnwk", "Standard"));
        mapTps.put ("au-fr_", new TpsInfo("au-fr_", "IF23", "FR", "FR", "prod.rnwk", "Standard"));
        mapTps.put ("au-jp_", new TpsInfo("au-jp_", "IJ81", "JP", "JP", "prod.rnwk", "Standard_JP"));
        mapTps.put ("avenuea_", new TpsInfo("avenuea_", "W2U0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("azoog_", new TpsInfo("azoog_", "WCT0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("azoog1_", new TpsInfo("azoog1_", "WCU0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("banana_", new TpsInfo("banana_", "WGP0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("belgac-fr_", new TpsInfo("belgac-fr_", "IFL3", "FR", "FR", "prod.partner", "oem_belgacom-fr"));
        mapTps.put ("belgac-nl_", new TpsInfo("belgac-nl_", "WCE0", "NL", "NL", "prod.partner", "oem_belgacom-nl"));
        mapTps.put ("belief_", new TpsInfo("belief_", "WHT0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("bell2_", new TpsInfo("bell2_", "WHW0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("bells-cl_", new TpsInfo("bells-cl_", "WHH0", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("bellsouth_", new TpsInfo("bellsouth_", "W5D0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("beness-jp_", new TpsInfo("beness-jp_", "IA41", "JP", "JP", "prod.acquisition", "Standard"));
        mapTps.put ("bestbuy_", new TpsInfo("bestbuy_", "WJE0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("bestbuy1_", new TpsInfo("bestbuy1_", "S010", "EN", "US", "prod.partner", "BestBuy2"));
        mapTps.put ("bestbuy2_", new TpsInfo("bestbuy2_", "S020", "EN", "US", "prod.partner", "BestBuy1"));
        mapTps.put ("bestbuy3_", new TpsInfo("bestbuy3_", "S030", "EN", "US", "prod.partner", "BestBuy1"));
        mapTps.put ("beta_", new TpsInfo("beta_", "BETA", "EN", "US", "prod.rnwk", "Beta"));
        mapTps.put ("beta2_", new TpsInfo("beta2_", "B170", "EN", "US", "prod.rnwk", "Beta2"));
        mapTps.put ("betav2_", new TpsInfo("betav2_", "B190", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("bhg_", new TpsInfo("bhg_", "W990", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("bingo_", new TpsInfo("bingo_", "W2A0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("blott-fr_", new TpsInfo("blott-fr_", "IF83", "FR", "FR", "prod.acquisition", "Standard"));
        mapTps.put ("blott-uk_", new TpsInfo("blott-uk_", "W980", "UK", "GB", "prod.acquisition", "Standard"));
        mapTps.put ("blueroom_", new TpsInfo("blueroom_", "WFN0", "EN", "US", "prod.partner", "oem_blueroom"));
        mapTps.put ("bonsai1_", new TpsInfo("bonsai1_", "WA60", "UK", "GB", "prod.acquisition", "Standard"));
        mapTps.put ("bonsai2_", new TpsInfo("bonsai2_", "WA70", "UK", "GB", "prod.acquisition", "Standard"));
        mapTps.put ("bonsai3_", new TpsInfo("bonsai3_", "WA80", "UK", "GB", "prod.acquisition", "Standard"));
        mapTps.put ("bonsai4_", new TpsInfo("bonsai4_", "WA90", "UK", "GB", "prod.acquisition", "Standard"));
        mapTps.put ("boss_", new TpsInfo("boss_", "W0I0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("bps-jp_", new TpsInfo("bps-jp_", "IJS1", "JP", "JP", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("br_", new TpsInfo("br_", "W1B0", "BR", "BR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("br-cl_", new TpsInfo("br-cl_", "WED0", "BR", "BR", "prod.partner", "Standard"));
        mapTps.put ("br-fc_", new TpsInfo("br-fc_", "WF20", "BR", "BR", "prod.rnwk", "Standard"));
        mapTps.put ("brgeo_", new TpsInfo("brgeo_", "W6A0", "BR", "BR", "prod.rnwk", "Standard"));
        mapTps.put ("broder_", new TpsInfo("broder_", "WHX0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("brpromo_", new TpsInfo("brpromo_", "W8D0", "BR", "BR", "prod.rnwk", "Standard"));
        mapTps.put ("brtest_", new TpsInfo("brtest_", "WC70", "BR", "BR", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("bundle_", new TpsInfo("bundle_", "W000", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("burst_", new TpsInfo("burst_", "W4Q0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cable2_", new TpsInfo("cable2_", "WHU0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("cablev-cl_", new TpsInfo("cablev-cl_", "WFU0", "EN", "US", "prod.partner", "StandardTps"));
        mapTps.put ("cablevisi_", new TpsInfo("cablevisi_", "W2JX", "EN", "US", "prod.partner", "Cablevision"));
        mapTps.put ("cablevision_", new TpsInfo("cablevision_", "W2J0", "EN", "US", "prod.partner", "Cablevision"));
        mapTps.put ("cagent_", new TpsInfo("cagent_", "IJC1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("candystan_", new TpsInfo("candystan_", "WCR0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("casale_", new TpsInfo("casale_", "W3S0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("chone_", new TpsInfo("chone_", "WK80", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("churchsch_", new TpsInfo("churchsch_", "W7G0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("cincy_", new TpsInfo("cincy_", "WJP0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("cj_", new TpsInfo("cj_", "W8X0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj1_", new TpsInfo("cj1_", "W8Y0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj2_", new TpsInfo("cj2_", "W910", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj2w_", new TpsInfo("cj2w_", "WDQ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj3_", new TpsInfo("cj3_", "WCM0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj4_", new TpsInfo("cj4_", "WDV0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj-de_", new TpsInfo("cj-de_", "IDR2", "DE", "DE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("cj-es_", new TpsInfo("cj-es_", "ISZ4", "ES", "ES", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("cj-eu_", new TpsInfo("cj-eu_", "WFK0", "EU", "SE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("cjfggp_", new TpsInfo("cjfggp_", "WDJ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cjfggpb_", new TpsInfo("cjfggpb_", "WDR0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj-fr_", new TpsInfo("cj-fr_", "IFQ3", "FR", "FR", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("cjg_", new TpsInfo("cjg_", "WGR0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cjgames_", new TpsInfo("cjgames_", "WGX0", "EN", "US", "prod.acquisition", "StandardMin"));
        mapTps.put ("cjgp_", new TpsInfo("cjgp_", "WGS0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cjint_", new TpsInfo("cjint_", "WDX0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj-mx_", new TpsInfo("cj-mx_", "IM04", "MX", "MX", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("cj-nl_", new TpsInfo("cj-nl_", "WE60", "NL", "NL", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("cjs_", new TpsInfo("cjs_", "WGT0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cjsg_", new TpsInfo("cjsg_", "WGU0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cj-uk_", new TpsInfo("cj-uk_", "WE50", "UK", "GB", "prod.acquisition", "DLPR"));
        mapTps.put ("claria_", new TpsInfo("claria_", "W4W0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("claria2_", new TpsInfo("claria2_", "WAN0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("claria3_", new TpsInfo("claria3_", "WC40", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("clariafr_", new TpsInfo("clariafr_", "IF13", "FR", "FR", "prod.acquisition", "Standard"));
        mapTps.put ("clariagp_", new TpsInfo("clariagp_", "WD50", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("clariauk_", new TpsInfo("clariauk_", "W7F0", "UK", "GB", "prod.acquisition", "GoogleToolbar"));
        mapTps.put ("clear2_", new TpsInfo("clear2_", "WHZ0", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("clear365_", new TpsInfo("clear365_", "WK30", "EN", "US", "prod.partner", "StandardNG"));
        mapTps.put ("clearchan_", new TpsInfo("clearchan_", "W4R0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("cnet_", new TpsInfo("cnet_", "W9N0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("cnet2_", new TpsInfo("cnet2_", "W9V0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("codema-au_", new TpsInfo("codema-au_", "WBY0", "EN", "US", "prod.partner", "oem_codemasters-au"));
        mapTps.put ("codema-de_", new TpsInfo("codema-de_", "IDE2", "DE", "DE", "prod.partner", "oem_codemasters-de"));
        mapTps.put ("codema-es_", new TpsInfo("codema-es_", "ISG4", "ES", "ES", "prod.partner", "oem_codemasters-es"));
        mapTps.put ("codema-fr_", new TpsInfo("codema-fr_", "IFH3", "FR", "FR", "prod.partner", "oem_codemaster-fr"));
        mapTps.put ("codema-it_", new TpsInfo("codema-it_", "WBD0", "IT", "IT", "prod.partner", "oem_codemasters-it"));
        mapTps.put ("codema-nl_", new TpsInfo("codema-nl_", "WBE0", "NL", "NL", "prod.partner", "oem_codemasters-nl"));
        mapTps.put ("codemaste_", new TpsInfo("codemaste_", "WBC0", "EN", "US", "prod.partner", "oem_codemasters-en"));
        mapTps.put ("codema-uk_", new TpsInfo("codema-uk_", "WBX0", "UK", "GB", "prod.partner", "oem_codemasters-uk"));
        mapTps.put ("colonize_", new TpsInfo("colonize_", "W4T0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("columbia_", new TpsInfo("columbia_", "W450", "EN", "US", "prod.partner", "DLPR"));
        mapTps.put ("comcast_", new TpsInfo("comcast_", "W2C0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("comcast2_", new TpsInfo("comcast2_", "WJV0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("comcastcl_", new TpsInfo("comcastcl_", "WEV0", "EN", "US", "prod.partner", "StandardTps"));
        mapTps.put ("cometsys_", new TpsInfo("cometsys_", "W810", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("compusa_", new TpsInfo("compusa_", "W950", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("coregmed_", new TpsInfo("coregmed_", "WD80", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("coxnet_", new TpsInfo("coxnet_", "WJ80", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("ctam_", new TpsInfo("ctam_", "W310", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("customcd_", new TpsInfo("customcd_", "WBZ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("customcd2_", new TpsInfo("customcd2_", "WG80", "EN", "US", "prod.acquisition", "StandardNG"));
        mapTps.put ("dandummy_", new TpsInfo("dandummy_", "WJF0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("de_", new TpsInfo("de_", "ID02", "DE", "DE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("de-cl_", new TpsInfo("de-cl_", "IDS2", "DE", "DE", "prod.partner", "Standard"));
        mapTps.put ("de-fc_", new TpsInfo("de-fc_", "IDU2", "DE", "DE", "prod.rnwk", "Standard"));
        mapTps.put ("defector_", new TpsInfo("defector_", "W350", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("degeo_", new TpsInfo("degeo_", "W620", "DE", "DE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("dell_", new TpsInfo("dell_", "W2H0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("dengeki_", new TpsInfo("dengeki_", "IJ61", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("deoff_", new TpsInfo("deoff_", "ID12", "DE", "DE", "prod.rnwk", "Standard"));
        mapTps.put ("depromo_", new TpsInfo("depromo_", "ID52", "DE", "DE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("detest_", new TpsInfo("detest_", "IDH2", "DE", "DE", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("de-v2_", new TpsInfo("de-v2_", "IDV2", "DE", "DE", "prod.rnwk", "Standard"));
        mapTps.put ("disney_", new TpsInfo("disney_", "W6G0", "EN", "US", "prod.partner", "oem_disney"));
        mapTps.put ("dm01_", new TpsInfo("dm01_", "WG20", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("dm02_", new TpsInfo("dm02_", "WG30", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("dm03_", new TpsInfo("dm03_", "WG40", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("dm04_", new TpsInfo("dm04_", "WG50", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("drive_", new TpsInfo("drive_", "WCX0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("drivegp_", new TpsInfo("drivegp_", "WD30", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("drtv1_", new TpsInfo("drtv1_", "WFD0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("drtv2_", new TpsInfo("drtv2_", "WFE0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("drtv3_", new TpsInfo("drtv3_", "WFF0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("ea_", new TpsInfo("ea_", "W2L0", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("earthlin2_", new TpsInfo("earthlin2_", "W5L0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("earthlink_", new TpsInfo("earthlink_", "W320", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("ecomm_", new TpsInfo("ecomm_", "W8Z0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("ekeuze-nl_", new TpsInfo("ekeuze-nl_", "WA20", "NL", "NL", "prod.acquisition", "Standard"));
        mapTps.put ("elmun2-es_", new TpsInfo("elmun2-es_", "ISW4", "ES", "ES", "prod.partner", "oem_elmundo"));
        mapTps.put ("elmund-es_", new TpsInfo("elmund-es_", "ISQ4", "ES", "ES", "prod.partner", "oem_elmundo"));
        mapTps.put ("emarket_", new TpsInfo("emarket_", "W5U0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("emarketv_", new TpsInfo("emarketv_", "W820", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("embarq_", new TpsInfo("embarq_", "WJT0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("en-cl_", new TpsInfo("en-cl_", "WEM0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("en-fc_", new TpsInfo("en-fc_", "WF90", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("entest_", new TpsInfo("entest_", "WC50", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("entpub_", new TpsInfo("entpub_", "WKL0", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("entspire_", new TpsInfo("entspire_", "W490", "EN", "US", "prod.partner", "DLPR"));
        mapTps.put ("eonline_", new TpsInfo("eonline_", "W580", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("eons_", new TpsInfo("eons_", "WFM0", "EN", "US", "prod.partner", "StandardTps"));
        mapTps.put ("epic_", new TpsInfo("epic_", "WJU0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("epilot_", new TpsInfo("epilot_", "W5W0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("es_", new TpsInfo("es_", "IS04", "ES", "ES", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("es-cl_", new TpsInfo("es-cl_", "IM14", "ES", "ES", "prod.partner", "Standard"));
        mapTps.put ("es-fc_", new TpsInfo("es-fc_", "IM44", "ES", "ES", "prod.rnwk", "Standard"));
        mapTps.put ("esgeo_", new TpsInfo("esgeo_", "W650", "ES", "ES", "prod.rnwk", "Standard"));
        mapTps.put ("espromo_", new TpsInfo("espromo_", "IS54", "ES", "ES", "prod.rnwk", "Standard"));
        mapTps.put ("estest_", new TpsInfo("estest_", "ISR4", "ES", "ES", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("estreet_", new TpsInfo("estreet_", "W7B0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("etype-de_", new TpsInfo("etype-de_", "IDP2", "DE", "DE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("etype-uk_", new TpsInfo("etype-uk_", "WE10", "UK", "GB", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("eu_", new TpsInfo("eu_", "W5T0", "EU", "SE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("eu-cl_", new TpsInfo("eu-cl_", "WEE0", "EU", "SE", "prod.partner", "Standard"));
        mapTps.put ("eu-fc_", new TpsInfo("eu-fc_", "WF30", "EU", "SE", "prod.rnwk", "Standard"));
        mapTps.put ("eupromo_", new TpsInfo("eupromo_", "WCS0", "EU", "SE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("eurengeo_", new TpsInfo("eurengeo_", "W7D0", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("eutest_", new TpsInfo("eutest_", "WC80", "EU", "SE", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("eval_", new TpsInfo("eval_", "WH40", "EN", "US", "prod.rnwk", "Evaluation"));
        mapTps.put ("expedia_", new TpsInfo("expedia_", "W930", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("expedia2_", new TpsInfo("expedia2_", "W940", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("ezone_", new TpsInfo("ezone_", "W5A0", "EN", "US", "prod.partner", "oem_ezone"));
        mapTps.put ("ezone2_", new TpsInfo("ezone2_", "WKK0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("family_", new TpsInfo("family_", "WKD0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("famitsu_", new TpsInfo("famitsu_", "IJ51", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("fastclick_", new TpsInfo("fastclick_", "W870", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("fastcpa_", new TpsInfo("fastcpa_", "W6S0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("fastuk_", new TpsInfo("fastuk_", "W6R0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("feed-de_", new TpsInfo("feed-de_", "WGF0", "DE", "DE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("feed-es_", new TpsInfo("feed-es_", "WGG0", "ES", "ES", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("feed-fr_", new TpsInfo("feed-fr_", "WGH0", "FR", "FR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("feed-it_", new TpsInfo("feed-it_", "WGJ0", "IT", "IT", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("feed-jp_", new TpsInfo("feed-jp_", "WGK0", "JP", "JP", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("feed-nl_", new TpsInfo("feed-nl_", "WGL0", "NL", "NL", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("feed-uk_", new TpsInfo("feed-uk_", "WGM0", "UK", "GB", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("ffoxtest_", new TpsInfo("ffoxtest_", "WJS0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("findwhat_", new TpsInfo("findwhat_", "W520", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("flipside_", new TpsInfo("flipside_", "W0P0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("forme_", new TpsInfo("forme_", "WCQ0", "EN", "US", "prod.partner", "oem_forme"));
        mapTps.put ("fortune_", new TpsInfo("fortune_", "W4U0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("fox_", new TpsInfo("fox_", "WJQ0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("fr_", new TpsInfo("fr_", "IF03", "FR", "FR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("fraper_", new TpsInfo("fraper_", "IA11", "JP", "JP", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("fr-cl_", new TpsInfo("fr-cl_", "IFR3", "FR", "FR", "prod.partner", "Standard"));
        mapTps.put ("freearc_", new TpsInfo("freearc_", "W7U0", "EN", "US", "prod.partner", "DLPR"));
        mapTps.put ("freefi_", new TpsInfo("freefi_", "W830", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("free-fr_", new TpsInfo("free-fr_", "IF43", "FR", "FR", "prod.partner", "oem_freefr"));
        mapTps.put ("freesite_", new TpsInfo("freesite_", "WJ20", "EN", "US", "prod.acquisition", "StandardTpsNG"));
        mapTps.put ("freesite2_", new TpsInfo("freesite2_", "WHM0", "EN", "US", "prod.acquisition", "StandardTpsNG"));
        mapTps.put ("freez3int_", new TpsInfo("freez3int_", "WFS0", "EN", "US", "prod.partner", "HouseAds"));
        mapTps.put ("freeze_", new TpsInfo("freeze_", "W8L0", "EN", "US", "prod.partner", "HouseAds"));
        mapTps.put ("freeze2_", new TpsInfo("freeze2_", "WAY0", "EN", "US", "prod.partner", "HouseAds"));
        mapTps.put ("freeze3_", new TpsInfo("freeze3_", "WFR0", "EN", "US", "prod.partner", "HouseAds"));
        mapTps.put ("fr-fc_", new TpsInfo("fr-fc_", "IFT3", "FR", "FR", "prod.rnwk", "Standard"));
        mapTps.put ("frgeo_", new TpsInfo("frgeo_", "W630", "FR", "FR", "prod.rnwk", "Standard"));
        mapTps.put ("froogle_", new TpsInfo("froogle_", "W8T0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("froog-uk_", new TpsInfo("froog-uk_", "WAT0", "UK", "GB", "prod.acquisition", "GoogleToolbar"));
        mapTps.put ("frpromo_", new TpsInfo("frpromo_", "IF63", "FR", "FR", "prod.rnwk", "Standard"));
        mapTps.put ("frtest_", new TpsInfo("frtest_", "IFK3", "FR", "FR", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("future-uk_", new TpsInfo("future-uk_", "WD10", "UK", "GB", "prod.partner", "Standard"));
        mapTps.put ("gamehouse_", new TpsInfo("gamehouse_", "W4Z0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("gamepass_", new TpsInfo("gamepass_", "W0X0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("gamershel_", new TpsInfo("gamershel_", "W9G0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gamescasi_", new TpsInfo("gamescasi_", "W6T0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("gamezebo_", new TpsInfo("gamezebo_", "WGN0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("gamezone_", new TpsInfo("gamezone_", "W2M0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("geointl_", new TpsInfo("geointl_", "W5R0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("giftsub3_", new TpsInfo("giftsub3_", "W460", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("gmo-jp_", new TpsInfo("gmo-jp_", "IJY1", "JP", "JP", "prod.partner", "Standard"));
        mapTps.put ("goo_", new TpsInfo("goo_", "IA71", "JP", "JP", "prod.partner", "Standard_JP"));
        mapTps.put ("goog_", new TpsInfo("goog_", "GOOG", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("google_", new TpsInfo("google_", "WAP0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("google1_", new TpsInfo("google1_", "WDA0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("google2_", new TpsInfo("google2_", "WDB0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("google3_", new TpsInfo("google3_", "WDC0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("googlecon_", new TpsInfo("googlecon_", "WAJ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("google-de_", new TpsInfo("google-de_", "IDA2", "DE", "DE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("google-es_", new TpsInfo("google-es_", "IST4", "ES", "ES", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("google-eu_", new TpsInfo("google-eu_", "WCK0", "EU", "SE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("googlefnl_", new TpsInfo("googlefnl_", "WGZ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("google-fr_", new TpsInfo("google-fr_", "IFF3", "FR", "FR", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("google-intl_", new TpsInfo("google-intl_", "W340", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("google-jp_", new TpsInfo("google-jp_", "IJ11", "JP", "JP", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("googlesp_", new TpsInfo("googlesp_", "IM74", "ES", "ES", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("google-uk_", new TpsInfo("google-uk_", "W920", "UK", "GB", "prod.acquisition", "DLPR"));
        mapTps.put ("googlew_", new TpsInfo("googlew_", "WCV0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("googlew2_", new TpsInfo("googlew2_", "WCW0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("googsj_", new TpsInfo("googsj_", "GOGG", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("googv1a_", new TpsInfo("googv1a_", "WH70", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("googv1b_", new TpsInfo("googv1b_", "WH80", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("googv2a_", new TpsInfo("googv2a_", "WHB0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("googv2aft_", new TpsInfo("googv2aft_", "WGB0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("googv2b_", new TpsInfo("googv2b_", "WHC0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("googv2pre_", new TpsInfo("googv2pre_", "WG90", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gorilla_", new TpsInfo("gorilla_", "W7A0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gossip_", new TpsInfo("gossip_", "WJ90", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("gp05_", new TpsInfo("gp05_", "WFZ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gp06_", new TpsInfo("gp06_", "WDW0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gp07_", new TpsInfo("gp07_", "WE30", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gp08_", new TpsInfo("gp08_", "WE40", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gp09_", new TpsInfo("gp09_", "WFY0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gpdom_", new TpsInfo("gpdom_", "WFC0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gpmedia_", new TpsInfo("gpmedia_", "WD60", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("greetings_", new TpsInfo("greetings_", "W550", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("gtbt-de_", new TpsInfo("gtbt-de_", "IDW2", "DE", "DE", "prod.rnwk", "GoogleToolbarTestv4"));
        mapTps.put ("gtbt-en_", new TpsInfo("gtbt-en_", "WHF0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("gtbt-es_", new TpsInfo("gtbt-es_", "IM84", "ES", "ES", "prod.rnwk", "GoogleToolbarTestv4"));
        mapTps.put ("gtbt-fr_", new TpsInfo("gtbt-fr_", "IFU3", "FR", "FR", "prod.rnwk", "GoogleToolbarTestv4"));
        mapTps.put ("gtbt-it_", new TpsInfo("gtbt-it_", "WHG0", "EN", "IT", "prod.rnwk", "GoogleToolbarTestv4"));
        mapTps.put ("gtbt-jp_", new TpsInfo("gtbt-jp_", "IA52", "JP", "JP", "prod.rnwk", "GoogleToolbarTestv4"));
        mapTps.put ("guide_", new TpsInfo("guide_", "W850", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("guide-ap_", new TpsInfo("guide-ap_", "WB50", "AP", "AP", "prod.acquisition", "Standard"));
        mapTps.put ("guide-br_", new TpsInfo("guide-br_", "WB10", "BR", "BR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("guide-br2_", new TpsInfo("guide-br2_", "WDM0", "BR", "BR", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("guide-de_", new TpsInfo("guide-de_", "ID92", "DE", "DE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("guide-de2_", new TpsInfo("guide-de2_", "IDL2", "DE", "DE", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("guide-es_", new TpsInfo("guide-es_", "ISE4", "ES", "ES", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("guide-es2_", new TpsInfo("guide-es2_", "ISY4", "ES", "ES", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("guide-eu_", new TpsInfo("guide-eu_", "WB60", "EU", "SE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("guide-eu2_", new TpsInfo("guide-eu2_", "WDT0", "EU", "SE", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("guide-fr_", new TpsInfo("guide-fr_", "IFE3", "FR", "FR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("guide-fr2_", new TpsInfo("guide-fr2_", "IFP3", "FR", "FR", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("guide-it_", new TpsInfo("guide-it_", "WB20", "IT", "IT", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("guide-it2_", new TpsInfo("guide-it2_", "WDN0", "IT", "IT", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("guide-jp_", new TpsInfo("guide-jp_", "IJE1", "JP", "JP", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("guide-kr_", new TpsInfo("guide-kr_", "WB70", "EN", "KR", "prod.acquisition", "Standard"));
        mapTps.put ("guide-mx_", new TpsInfo("guide-mx_", "ISF4", "MX", "MX", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("guide-mx2_", new TpsInfo("guide-mx2_", "ISX4", "MX", "MX", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("guide-nl_", new TpsInfo("guide-nl_", "WB40", "NL", "NL", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("guide-nl2_", new TpsInfo("guide-nl2_", "WDP0", "NL", "NL", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("guide-uk_", new TpsInfo("guide-uk_", "WB30", "UK", "GB", "prod.acquisition", "DLPR"));
        mapTps.put ("guide-uk2_", new TpsInfo("guide-uk2_", "WD90", "UK", "GB", "prod.partner", "DLPR"));
        mapTps.put ("hasbro_", new TpsInfo("hasbro_", "WFQ0", "EN", "US", "prod.partner", "oem_hasbro"));
        mapTps.put ("hawaiiant_", new TpsInfo("hawaiiant_", "WJK0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("hbo1_", new TpsInfo("hbo1_", "W420", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("hbo2_", new TpsInfo("hbo2_", "W430", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("hbo3_", new TpsInfo("hbo3_", "W440", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("hipsoft_", new TpsInfo("hipsoft_", "W880", "EN", "US", "prod.partner", "oem_hipsoft"));
        mapTps.put ("hollywood_", new TpsInfo("hollywood_", "W8G0", "EN", "US", "prod.partner", "oem_hollywood"));
        mapTps.put ("home-uk_", new TpsInfo("home-uk_", "WAE0", "UK", "GB", "prod.acquisition", "Standard"));
        mapTps.put ("horoscope_", new TpsInfo("horoscope_", "WGQ0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("hotbar_", new TpsInfo("hotbar_", "WA30", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("hotbar-de_", new TpsInfo("hotbar-de_", "ID82", "DE", "DE", "prod.partner", "Standard"));
        mapTps.put ("hotbar-es_", new TpsInfo("hotbar-es_", "IS84", "ES", "ES", "prod.partner", "Standard"));
        mapTps.put ("hotbar-fr_", new TpsInfo("hotbar-fr_", "IFA3", "FR", "FR", "prod.partner", "Standard"));
        mapTps.put ("hotbar-uk_", new TpsInfo("hotbar-uk_", "WA40", "UK", "GB", "prod.partner", "Standard"));
        mapTps.put ("hsm_", new TpsInfo("hsm_", "W2Y0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("hsn_", new TpsInfo("hsn_", "W840", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("htmail-uk_", new TpsInfo("htmail-uk_", "WE20", "UK", "GB", "prod.acquisition", "DLPR"));
        mapTps.put ("ienpromo_", new TpsInfo("ienpromo_", "W7C0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("ign_", new TpsInfo("ign_", "W5Y0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("ilse-nl_", new TpsInfo("ilse-nl_", "WB90", "NL", "NL", "prod.partner", "Standard"));
        mapTps.put ("impres-jp_", new TpsInfo("impres-jp_", "IJG1", "JP", "JP", "prod.acquisition", "GoogleToolbar"));
        mapTps.put ("insight_", new TpsInfo("insight_", "WAW0", "EN", "US", "prod.partner", "oem_insight"));
        mapTps.put ("insight2_", new TpsInfo("insight2_", "WK40", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("intclick_", new TpsInfo("intclick_", "WCL0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("intipm01_", new TpsInfo("intipm01_", "P1C0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("intl_", new TpsInfo("intl_", "W2T2", "DE", "DE", "prod.rnwk", "Standard"));
        mapTps.put ("intl-ab_", new TpsInfo("intl-ab_", "W3T2", "DE", "DE", "prod.rnwk", "Standard"));
        mapTps.put ("investor_", new TpsInfo("investor_", "W0O0", "EN", "US", "prod.partner", "DLPR"));
        mapTps.put ("ipm021304_", new TpsInfo("ipm021304_", "P160", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("ipm051603_", new TpsInfo("ipm051603_", "W2F0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("ipm111403_", new TpsInfo("ipm111403_", "P110", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("ipm-de_", new TpsInfo("ipm-de_", "ID72", "DE", "DE", "prod.acquisition", "IPM"));
        mapTps.put ("ipm-es_", new TpsInfo("ipm-es_", "IS74", "ES", "ES", "prod.acquisition", "IPM"));
        mapTps.put ("ipm-fr_", new TpsInfo("ipm-fr_", "IF93", "FR", "FR", "prod.acquisition", "IPM"));
        mapTps.put ("ipm-jp_", new TpsInfo("ipm-jp_", "IJA1", "JP", "JP", "prod.acquisition", "IPM"));
        mapTps.put ("it_", new TpsInfo("it_", "W1F0", "IT", "IT", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("it-cl_", new TpsInfo("it-cl_", "WEF0", "IT", "IT", "prod.partner", "Standard"));
        mapTps.put ("it-fc_", new TpsInfo("it-fc_", "WF40", "IT", "IT", "prod.rnwk", "Standard"));
        mapTps.put ("itgeo_", new TpsInfo("itgeo_", "W640", "IT", "IT", "prod.rnwk", "Standard"));
        mapTps.put ("itpromo_", new TpsInfo("itpromo_", "W8A0", "IT", "IT", "prod.rnwk", "Standard"));
        mapTps.put ("ittest_", new TpsInfo("ittest_", "WC90", "IT", "IT", "prod.acquisition", "GoogleToolbarTestv3"));
        mapTps.put ("japan_", new TpsInfo("japan_", "W4C0", "JP", "JP", "prod.rnwk", "Standard_JP"));
        mapTps.put ("jeeves_", new TpsInfo("jeeves_", "W260", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("jigzone_", new TpsInfo("jigzone_", "W6E0", "EN", "US", "prod.jigzone", "Standard"));
        mapTps.put ("jp_", new TpsInfo("jp_", "IJ01", "JP", "JP", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("jp-cl_", new TpsInfo("jp-cl_", "IJW1", "JP", "JP", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("jp-en_", new TpsInfo("jp-en_", "W2Z0", "JP", "JP", "prod.acquisition", "International"));
        mapTps.put ("jp-fc_", new TpsInfo("jp-fc_", "IJX1", "JP", "JP", "prod.rnwk", "Standard"));
        mapTps.put ("jpgeo_", new TpsInfo("jpgeo_", "W6F0", "JP", "JP", "prod.rnwk", "Standard_JP"));
        mapTps.put ("jp-local_", new TpsInfo("jp-local_", "W4M1", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("jptest_", new TpsInfo("jptest_", "IJQ1", "JP", "JP", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("jp-v2_", new TpsInfo("jp-v2_", "IA51", "JP", "JP", "prod.rnwk", "Standard_JP"));
        mapTps.put ("jrdx_", new TpsInfo("jrdx_", "IJ41", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("jrpass_", new TpsInfo("jrpass_", "IJ91", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("jspad_", new TpsInfo("jspad_", "IA81", "JP", "JP", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("kanoodle_", new TpsInfo("kanoodle_", "W5X0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("king_", new TpsInfo("king_", "WJ70", "EN", "US", "prod.partner", "StandardTps"));
        mapTps.put ("kr_", new TpsInfo("kr_", "W1C0", "EN", "KR", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("kr-cl_", new TpsInfo("kr-cl_", "WEG0", "EN", "KR", "prod.partner", "Standard"));
        mapTps.put ("kr-fc_", new TpsInfo("kr-fc_", "WF50", "EN", "KR", "prod.rnwk", "Standard"));
        mapTps.put ("krgeo_", new TpsInfo("krgeo_", "W6D0", "EN", "KR", "prod.rnwk", "Standard"));
        mapTps.put ("kr-local_", new TpsInfo("kr-local_", "IK05", "EN", "KR", "prod.acquisition", "Standard"));
        mapTps.put ("krpromo_", new TpsInfo("krpromo_", "W8F0", "EN", "KR", "prod.rnwk", "Standard"));
        mapTps.put ("krtest_", new TpsInfo("krtest_", "WCA0", "EN", "KR", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("latimes_", new TpsInfo("latimes_", "WC20", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("leejeans_", new TpsInfo("leejeans_", "WAX0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("lexico_", new TpsInfo("lexico_", "WAM0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("lexico2_", new TpsInfo("lexico2_", "WJR0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("lhj_", new TpsInfo("lhj_", "W9A0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("life2_", new TpsInfo("life2_", "WJG0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("lifetime_", new TpsInfo("lifetime_", "W5F0", "EN", "US", "prod.partner", "DLPR"));
        mapTps.put ("lifetpink_", new TpsInfo("lifetpink_", "WJC0", "EN", "US", "prod.partner", "oem_lifetimepink"));
        mapTps.put ("listop-jp_", new TpsInfo("listop-jp_", "IA01", "JP", "JP", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("logitech_", new TpsInfo("logitech_", "C0S0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("looksmart_", new TpsInfo("looksmart_", "W290", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("lycos_", new TpsInfo("lycos_", "W470", "EN", "US", "prod.partner", "oem_lycos"));
        mapTps.put ("lycos2_", new TpsInfo("lycos2_", "WFP0", "EN", "US", "prod.partner", "CustomGameWithUI"));
        mapTps.put ("maxonline_", new TpsInfo("maxonline_", "W5B0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("mb_", new TpsInfo("mb_", "WFA0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("mcdonalds_", new TpsInfo("mcdonalds_", "WHN0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("mcdonalds1_", new TpsInfo("mcdonalds1_", "WJ10", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("mcenter_", new TpsInfo("mcenter_", "W960", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("mcr_", new TpsInfo("mcr_", "WKB0", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("mcr0_", new TpsInfo("mcr0_", "WKF0", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("mediawhiz_", new TpsInfo("mediawhiz_", "W590", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("metarew_", new TpsInfo("metarew_", "W5C0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("metric-de_", new TpsInfo("metric-de_", "IDJ2", "DE", "DE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("metricsd_", new TpsInfo("metricsd_", "W5Z0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("metricsdi_", new TpsInfo("metricsdi_", "WAF0", "UK", "GB", "prod.partner", "Standard"));
        mapTps.put ("metricsgp_", new TpsInfo("metricsgp_", "WD70", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("migratev1_", new TpsInfo("migratev1_", "WH20", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("migtest1_", new TpsInfo("migtest1_", "WKN0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("migtest2_", new TpsInfo("migtest2_", "WKP0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("miva_", new TpsInfo("miva_", "WFJ0", "EN", "US", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("mixcat_", new TpsInfo("mixcat_", "WJ40", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("mixi-jp_", new TpsInfo("mixi-jp_", "IA31", "JP", "JP", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("monkey_", new TpsInfo("monkey_", "WJ50", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("mpg_", new TpsInfo("mpg_", "WDK0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("mpi_", new TpsInfo("mpi_", "WFW0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("mrgood-eu_", new TpsInfo("mrgood-eu_", "WBS0", "EU", "SE", "prod.partner", "Standard"));
        mapTps.put ("msite_", new TpsInfo("msite_", "WFB0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("msncpa_", new TpsInfo("msncpa_", "WFH0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("msnsearch_", new TpsInfo("msnsearch_", "WDI0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("mumjum_", new TpsInfo("mumjum_", "W5H0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("mx_", new TpsInfo("mx_", "IS64", "MX", "MX", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("mx-cl_", new TpsInfo("mx-cl_", "IM24", "MX", "MX", "prod.partner", "Standard"));
        mapTps.put ("mx-fc_", new TpsInfo("mx-fc_", "IM54", "MX", "MX", "prod.rnwk", "Standard"));
        mapTps.put ("mxgeo_", new TpsInfo("mxgeo_", "W6B0", "MX", "MX", "prod.rnwk", "Standard"));
        mapTps.put ("mxpromo_", new TpsInfo("mxpromo_", "W8E0", "MX", "MX", "prod.rnwk", "Standard"));
        mapTps.put ("mxtest_", new TpsInfo("mxtest_", "ISS4", "MX", "MX", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("myfreeze_", new TpsInfo("myfreeze_", "WKJ0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("natgeo_", new TpsInfo("natgeo_", "WJL0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("netaol_", new TpsInfo("netaol_", "W9D0", "EN", "US", "prod.acquisition", "NetscapeAOL"));
        mapTps.put ("netscape_", new TpsInfo("netscape_", "W4X0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("netste-cl_", new TpsInfo("netste-cl_", "WFT0", "EN", "US", "prod.partner", "StandardTps"));
        mapTps.put ("netster_", new TpsInfo("netster_", "WH50", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("netzero_", new TpsInfo("netzero_", "WAV0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("nightl-de_", new TpsInfo("nightl-de_", "IDN2", "DE", "DE", "prod.rnwk", "Nightly"));
        mapTps.put ("nightl-es_", new TpsInfo("nightl-es_", "ISN4", "ES", "ES", "prod.rnwk", "Nightly"));
        mapTps.put ("nightl-fr_", new TpsInfo("nightl-fr_", "IFN3", "FR", "FR", "prod.rnwk", "Nightly"));
        mapTps.put ("nightl-jp_", new TpsInfo("nightl-jp_", "IJNN", "JP", "JP", "prod.rnwk", "Nightly"));
        mapTps.put ("nightly_", new TpsInfo("nightly_", "N0EN", "EN", "US", "prod.rnwk", "Nightly"));
        mapTps.put ("nl_", new TpsInfo("nl_", "W1H0", "NL", "NL", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("nl-cl_", new TpsInfo("nl-cl_", "WEH0", "NL", "NL", "prod.partner", "Standard"));
        mapTps.put ("nl-fc_", new TpsInfo("nl-fc_", "WF60", "NL", "NL", "prod.rnwk", "Standard"));
        mapTps.put ("nlgeo_", new TpsInfo("nlgeo_", "W680", "NL", "NL", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("nlpromo_", new TpsInfo("nlpromo_", "W8C0", "NL", "NL", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("nltest_", new TpsInfo("nltest_", "WCB0", "NL", "NL", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("nobar_", new TpsInfo("nobar_", "W7J0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("noexpress_", new TpsInfo("noexpress_", "W0E0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("none_", new TpsInfo("none_", "W4B0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("nwsource_", new TpsInfo("nwsource_", "W7N0", "EN", "US", "prod.partner", "oem_nwsource"));
        mapTps.put ("nwsource2_", new TpsInfo("nwsource2_", "WJX0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("nytimes_", new TpsInfo("nytimes_", "WHS0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("oberon_", new TpsInfo("oberon_", "W5G0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("ocn_", new TpsInfo("ocn_", "IA61", "JP", "JP", "prod.partner", "Standard_JP"));
        mapTps.put ("over1-jp_", new TpsInfo("over1-jp_", "IJJ1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("over2-jp_", new TpsInfo("over2-jp_", "IJK1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("over3-jp_", new TpsInfo("over3-jp_", "IJL1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("over4-jp_", new TpsInfo("over4-jp_", "IJM1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("over5-jp_", new TpsInfo("over5-jp_", "IJN1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("over-de_", new TpsInfo("over-de_", "IDM2", "DE", "DE", "prod.acquisition", "Standard"));
        mapTps.put ("over-fr_", new TpsInfo("over-fr_", "IF73", "FR", "FR", "prod.acquisition", "Standard"));
        mapTps.put ("over-jp_", new TpsInfo("over-jp_", "IJ31", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("oversee_", new TpsInfo("oversee_", "WAZ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overtfnl_", new TpsInfo("overtfnl_", "WH10", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overtf-uk_", new TpsInfo("overtf-uk_", "WBR0", "UK", "GB", "prod.acquisition", "Overture"));
        mapTps.put ("overture_", new TpsInfo("overture_", "WAQ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overture1_", new TpsInfo("overture1_", "WCF0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overture2_", new TpsInfo("overture2_", "WCG0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overture3_", new TpsInfo("overture3_", "WCH0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overture4_", new TpsInfo("overture4_", "WCI0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overtures_", new TpsInfo("overtures_", "IM64", "MX", "MX", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("overturet_", new TpsInfo("overturet_", "W7P0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overtv1a_", new TpsInfo("overtv1a_", "WH90", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overtv1b_", new TpsInfo("overtv1b_", "WHA0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overtv2a_", new TpsInfo("overtv2a_", "WHD0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("overtv2b_", new TpsInfo("overtv2b_", "WHE0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("over-uk_", new TpsInfo("over-uk_", "W8R0", "UK", "GB", "prod.acquisition", "DLPR"));
        mapTps.put ("overv2aft_", new TpsInfo("overv2aft_", "WGC0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("overv2pre_", new TpsInfo("overv2pre_", "WGA0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("overz-nl_", new TpsInfo("overz-nl_", "WE90", "NL", "NL", "prod.partner", "Standard"));
        mapTps.put ("palm_", new TpsInfo("palm_", "C0H0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("parade_", new TpsInfo("parade_", "WHL0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("parade-cl_", new TpsInfo("parade-cl_", "WKC0", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("patsajack_", new TpsInfo("patsajack_", "WCZ0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("pb030130_", new TpsInfo("pb030130_", "P090", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb10_", new TpsInfo("pb10_", "P130", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb11_", new TpsInfo("pb11_", "P140", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb12_", new TpsInfo("pb12_", "P170", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb13_", new TpsInfo("pb13_", "P1A0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb14_", new TpsInfo("pb14_", "P180", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb15_", new TpsInfo("pb15_", "P2V2", "DE", "DE", "prod.rnwk", "GoogleToolbar"));
        mapTps.put ("pb16_", new TpsInfo("pb16_", "P1D0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb17_", new TpsInfo("pb17_", "P1B0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb18_", new TpsInfo("pb18_", "Q011", "JP", "JP", "prod.rnwk", "Standard_JP"));
        mapTps.put ("pb19_", new TpsInfo("pb19_", "P190", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb1-de_", new TpsInfo("pb1-de_", "P2U2", "DE", "DE", "prod.rnwk", "GoogleToolbar"));
        mapTps.put ("pb1-intl_", new TpsInfo("pb1-intl_", "P0P0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb2_", new TpsInfo("pb2_", "P0C0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb2-intl_", new TpsInfo("pb2-intl_", "P0X0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb4_", new TpsInfo("pb4_", "P0M0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb6_", new TpsInfo("pb6_", "P0Q0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb7_", new TpsInfo("pb7_", "P0W0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb8-a_", new TpsInfo("pb8-a_", "P0Y0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb8-b_", new TpsInfo("pb8-b_", "P0Z0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pb9_", new TpsInfo("pb9_", "P150", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pdv_", new TpsInfo("pdv_", "WA10", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("pennyweb_", new TpsInfo("pennyweb_", "W7R0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("peoplepc_", new TpsInfo("peoplepc_", "W2K0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("plasticca_", new TpsInfo("plasticca_", "WBB0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("playsite_", new TpsInfo("playsite_", "W2B0", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("portmag_", new TpsInfo("portmag_", "WG70", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("powwa_", new TpsInfo("powwa_", "W4Y0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("prebuilt_", new TpsInfo("prebuilt_", "W5J0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("pre-euro_", new TpsInfo("pre-euro_", "W0T0", "EN", "US", "prod.rnwk", "Standard"));
        mapTps.put ("prize-jp_", new TpsInfo("prize-jp_", "IJZ1", "JP", "JP", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("qsp_", new TpsInfo("qsp_", "W9H0", "EN", "US", "prod.partner", "oem_qsp"));
        mapTps.put ("qsp2_", new TpsInfo("qsp2_", "WH30", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("qwest_", new TpsInfo("qwest_", "WDS0", "EN", "US", "prod.partner", "oem_qwest"));
        mapTps.put ("qwest2_", new TpsInfo("qwest2_", "WKG0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("r1home_", new TpsInfo("r1home_", "WAD0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("r1home-de_", new TpsInfo("r1home-de_", "IDD2", "DE", "DE", "prod.rnwk", "Standard"));
        mapTps.put ("r1home-es_", new TpsInfo("r1home-es_", "ISD4", "ES", "ES", "prod.rnwk", "Standard"));
        mapTps.put ("r1home-fr_", new TpsInfo("r1home-fr_", "IFD3", "FR", "FR", "prod.rnwk", "Standard"));
        mapTps.put ("r1home-jp_", new TpsInfo("r1home-jp_", "IJD1", "JP", "JP", "prod.rnwk", "Standard_JP"));
        mapTps.put ("r1promo_", new TpsInfo("r1promo_", "W7Q0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("ratings_", new TpsInfo("ratings_", "WJW0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("rbs_", new TpsInfo("rbs_", "W0G0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("readersd2_", new TpsInfo("readersd2_", "WH60", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("readersdi_", new TpsInfo("readersdi_", "W9J0", "EN", "US", "prod.partner", "oem_readersdigest"));
        mapTps.put ("ride_", new TpsInfo("ride_", "W3F0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("ride2_", new TpsInfo("ride2_", "W540", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("ridecpa1_", new TpsInfo("ridecpa1_", "W6J0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("ridecpa2_", new TpsInfo("ridecpa2_", "W6K0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("ridecpa3_", new TpsInfo("ridecpa3_", "W6L0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("rm247_", new TpsInfo("rm247_", "W560", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("rnhouse_", new TpsInfo("rnhouse_", "WC10", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("road2_", new TpsInfo("road2_", "WHQ0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("roadrun_", new TpsInfo("roadrun_", "W510", "EN", "US", "prod.partner", "oem_roadrunner"));
        mapTps.put ("rp11_", new TpsInfo("rp11_", "WHK0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("rpass-de_", new TpsInfo("rpass-de_", "ID32", "DE", "DE", "prod.rnwk", "Standard"));
        mapTps.put ("rpass-es_", new TpsInfo("rpass-es_", "IS34", "ES", "ES", "prod.rnwk", "Standard"));
        mapTps.put ("rpass-fr_", new TpsInfo("rpass-fr_", "IF33", "FR", "FR", "prod.rnwk", "Standard"));
        mapTps.put ("rpass-it_", new TpsInfo("rpass-it_", "W7V0", "IT", "IT", "prod.rnwk", "Standard"));
        mapTps.put ("rpass-nl_", new TpsInfo("rpass-nl_", "W7Z0", "NL", "NL", "prod.rnwk", "Standard"));
        mapTps.put ("rpass-se_", new TpsInfo("rpass-se_", "W7Y0", "EU", "SE", "prod.rnwk", "Standard"));
        mapTps.put ("rpass-uk_", new TpsInfo("rpass-uk_", "W7W0", "UK", "GB", "prod.rnwk", "Standard"));
        mapTps.put ("rpwelc-br_", new TpsInfo("rpwelc-br_", "WBU0", "BR", "BR", "prod.acquisition", "Standard"));
        mapTps.put ("rpwelc-de_", new TpsInfo("rpwelc-de_", "IDG2", "DE", "DE", "prod.acquisition", "Standard"));
        mapTps.put ("rpwelc-es_", new TpsInfo("rpwelc-es_", "ISP4", "ES", "ES", "prod.acquisition", "Standard"));
        mapTps.put ("rpwelc-fr_", new TpsInfo("rpwelc-fr_", "IFJ3", "FR", "FR", "prod.acquisition", "Standard"));
        mapTps.put ("rpwelc-it_", new TpsInfo("rpwelc-it_", "WBT0", "IT", "IT", "prod.acquisition", "Standard"));
        mapTps.put ("rray_", new TpsInfo("rray_", "WK70", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("rss_", new TpsInfo("rss_", "RSS0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("rtl-de_", new TpsInfo("rtl-de_", "ID42", "DE", "DE", "prod.partner", "oem_rtlde"));
        mapTps.put ("rtl-de2_", new TpsInfo("rtl-de2_", "ID62", "DE", "DE", "prod.partner", "oem_rtlde"));
        mapTps.put ("rtl-fr_", new TpsInfo("rtl-fr_", "IFG3", "FR", "FR", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("rydium-a_", new TpsInfo("rydium-a_", "W3Z0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("rydium-b_", new TpsInfo("rydium-b_", "W410", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("salon_", new TpsInfo("salon_", "WJY0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("scd_", new TpsInfo("scd_", "WFX0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("screens1_", new TpsInfo("screens1_", "WG10", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("screensav_", new TpsInfo("screensav_", "WAL0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("screensv2_", new TpsInfo("screensv2_", "WKE0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("se_", new TpsInfo("se_", "W1J0", "EU", "SE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("searchama_", new TpsInfo("searchama_", "W6U0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("se-cl_", new TpsInfo("se-cl_", "WEJ0", "EU", "SE", "prod.partner", "Standard"));
        mapTps.put ("seedcorn_", new TpsInfo("seedcorn_", "WDL0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("se-fc_", new TpsInfo("se-fc_", "WF70", "EU", "SE", "prod.rnwk", "Standard"));
        mapTps.put ("sega_", new TpsInfo("sega_", "W1K0", "EN", "US", "prod.partner", "oem_sega"));
        mapTps.put ("segeo_", new TpsInfo("segeo_", "W690", "EU", "SE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("sendtec_", new TpsInfo("sendtec_", "WCY0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("sepromo_", new TpsInfo("sepromo_", "W8B0", "EU", "SE", "prod.rnwk", "GoogleToolbarTest"));
        mapTps.put ("setest_", new TpsInfo("setest_", "WCC0", "EU", "SE", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("shizmoo_", new TpsInfo("shizmoo_", "W9E0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("shiznet_", new TpsInfo("shiznet_", "WAR0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("skilljam_", new TpsInfo("skilljam_", "W5K0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("skunk_", new TpsInfo("skunk_", "W4F0", "EN", "US", "prod.partner", "Skunk"));
        mapTps.put ("skunk2_", new TpsInfo("skunk2_", "WJJ0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("skunktst_", new TpsInfo("skunktst_", "WJM0", "EN", "US", "prod.partner", "Skunk"));
        mapTps.put ("slingo_", new TpsInfo("slingo_", "W1Y0", "EN", "US", "prod.partner", "Slingo"));
        mapTps.put ("slingo2_", new TpsInfo("slingo2_", "W2R0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("slingo3_", new TpsInfo("slingo3_", "WK50", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("sm-search_", new TpsInfo("sm-search_", "W3W0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("sohodig_", new TpsInfo("sohodig_", "W8S0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("sony-jp_", new TpsInfo("sony-jp_", "IJT1", "JP", "JP", "prod.partner", "Standard"));
        mapTps.put ("spbenefit_", new TpsInfo("spbenefit_", "W6M0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("speedb-de_", new TpsInfo("speedb-de_", "IDI2", "DE", "DE", "prod.partner", "Standard"));
        mapTps.put ("speedbit_", new TpsInfo("speedbit_", "WC30", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("spi_", new TpsInfo("spi_", "WFV0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("sprout_", new TpsInfo("sprout_", "W4S0", "EN", "US", "prod.partner", "oem_sprout"));
        mapTps.put ("startf-nl_", new TpsInfo("startf-nl_", "WEB0", "NL", "NL", "prod.partner", "Standard"));
        mapTps.put ("startg-nl_", new TpsInfo("startg-nl_", "WEA0", "NL", "NL", "prod.partner", "Standard"));
        mapTps.put ("sudokucom_", new TpsInfo("sudokucom_", "WHI0", "EN", "US", "prod.acquisition", "StandardTps"));
        mapTps.put ("superch_", new TpsInfo("superch_", "W6Y0", "EN", "US", "prod.partner", "oem_supercheats"));
        mapTps.put ("superpasx_", new TpsInfo("superpasx_", "P0T0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("superpos_", new TpsInfo("superpos_", "W4G0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("syntest_", new TpsInfo("syntest_", "WKQ0", "EN", "US", "prod.partner", "SyndicationTpsNG"));
        mapTps.put ("syntestgt_", new TpsInfo("syntestgt_", "WKR0", "EN", "US", "prod.partner", "SyndicationTps"));
        mapTps.put ("target_", new TpsInfo("target_", "WJH0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("telewest_", new TpsInfo("telewest_", "W330", "UK", "GB", "prod.partner", "GoogleToolbarTest"));
        mapTps.put ("test_", new TpsInfo("test_", "TEST", "EN", "US", "prod.rnwk", "Test"));
        mapTps.put ("test0202_", new TpsInfo("test0202_", "WGY0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("test-cl_", new TpsInfo("test-cl_", "WDU0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("test-de_", new TpsInfo("test-de_", "TSTD", "DE", "DE", "prod.rnwk", "Test"));
        mapTps.put ("test-es_", new TpsInfo("test-es_", "TSTE", "ES", "ES", "prod.rnwk", "Test"));
        mapTps.put ("test-fr_", new TpsInfo("test-fr_", "TSTF", "FR", "FR", "prod.rnwk", "Test"));
        mapTps.put ("test-jp_", new TpsInfo("test-jp_", "TSTN", "JP", "JP", "prod.rnwk", "Standard_JP"));
        mapTps.put ("test-jp2_", new TpsInfo("test-jp2_", "TSTJ", "JP", "JP", "prod.rnwk", "Test_JP"));
        mapTps.put ("testpromo_", new TpsInfo("testpromo_", "WJ60", "EN", "US", "prod.partner", "StandardMin"));
        mapTps.put ("test-sj_", new TpsInfo("test-sj_", "TSTS", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("tlyssp_", new TpsInfo("tlyssp_", "WGW0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("tmp_", new TpsInfo("tmp_", "W210", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("tradedoub_", new TpsInfo("tradedoub_", "W9C0", "UK", "GB", "prod.acquisition", "DLPR"));
        mapTps.put ("tradeduk_", new TpsInfo("tradeduk_", "W8H0", "UK", "GB", "prod.acquisition", "GoogleToolbar"));
        mapTps.put ("transmeta_", new TpsInfo("transmeta_", "IJ71", "JP", "JP", "prod.partner", "OEM_JP"));
        mapTps.put ("tribal_", new TpsInfo("tribal_", "W4N0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("tribalgp_", new TpsInfo("tribalgp_", "WD20", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("turn_", new TpsInfo("turn_", "WJD0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("tvcom_", new TpsInfo("tvcom_", "WB80", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("tvguide_", new TpsInfo("tvguide_", "W7M0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("twalker_", new TpsInfo("twalker_", "IJB1", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("uclick_", new TpsInfo("uclick_", "WAU0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("uk_", new TpsInfo("uk_", "W6Z0", "UK", "GB", "prod.rnwk", "DLPR"));
        mapTps.put ("uk-cl_", new TpsInfo("uk-cl_", "WEL0", "UK", "GB", "prod.partner", "Standard"));
        mapTps.put ("uk-fc_", new TpsInfo("uk-fc_", "WF80", "UK", "GB", "prod.rnwk", "Standard"));
        mapTps.put ("ukgeo_", new TpsInfo("ukgeo_", "W610", "UK", "GB", "prod.rnwk", "DLPR"));
        mapTps.put ("ukpromo_", new TpsInfo("ukpromo_", "W710", "UK", "GB", "prod.rnwk", "DLPR"));
        mapTps.put ("uktest_", new TpsInfo("uktest_", "WCD0", "UK", "GB", "prod.rnwk", "GoogleToolbarTestv3"));
        mapTps.put ("undertone_", new TpsInfo("undertone_", "W360", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("upgrade_", new TpsInfo("upgrade_", "WGD0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("upgrade2_", new TpsInfo("upgrade2_", "WKM0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("upgradet_", new TpsInfo("upgradet_", "WGE0", "EN", "US", "prod.acquisition", "Standard"));
        mapTps.put ("upload_", new TpsInfo("upload_", "W8K0", "EN", "US", "prod.partner", "DLPR"));
        mapTps.put ("us_", new TpsInfo("us_", "W8J0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("valclk-de_", new TpsInfo("valclk-de_", "IDQ2", "DE", "DE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("valclk-uk_", new TpsInfo("valclk-uk_", "WDZ0", "UK", "GB", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("valpak_", new TpsInfo("valpak_", "WBP0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("valpak2_", new TpsInfo("valpak2_", "WBQ0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("vector_", new TpsInfo("vector_", "IJ21", "JP", "JP", "prod.acquisition", "Standard_JP"));
        mapTps.put ("vendare_", new TpsInfo("vendare_", "W7S0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("verizon_", new TpsInfo("verizon_", "W4V0", "EN", "US", "prod.rnwk", "DLPR"));
        mapTps.put ("verizon2_", new TpsInfo("verizon2_", "WJZ0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("vertest_", new TpsInfo("vertest_", "WBV0", "EN", "US", "prod.acquisition", "stubtest"));
        mapTps.put ("vmundo_", new TpsInfo("vmundo_", "W530", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("volumem_", new TpsInfo("volumem_", "W9F0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("w3data_", new TpsInfo("w3data_", "W970", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("walmart_", new TpsInfo("walmart_", "WHV0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("wchannel_", new TpsInfo("wchannel_", "WJB0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("weathch_", new TpsInfo("weathch_", "WHJ0", "EN", "US", "prod.partner", "Standard"));
        mapTps.put ("weather_", new TpsInfo("weather_", "W2E0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("welico-ap_", new TpsInfo("welico-ap_", "WE80", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("welico-br_", new TpsInfo("welico-br_", "WDE0", "BR", "BR", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welico-cn_", new TpsInfo("welico-cn_", "WDG0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("welico-de_", new TpsInfo("welico-de_", "IDK2", "DE", "DE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welico-es_", new TpsInfo("welico-es_", "ISV4", "ES", "ES", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welico-eu_", new TpsInfo("welico-eu_", "WEK0", "EU", "SE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welico-fr_", new TpsInfo("welico-fr_", "IFM3", "FR", "FR", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welico-it_", new TpsInfo("welico-it_", "WDD0", "IT", "IT", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welico-jp_", new TpsInfo("welico-jp_", "IJU1", "JP", "JP", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welico-kr_", new TpsInfo("welico-kr_", "WDH0", "EN", "KR", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welico-mx_", new TpsInfo("welico-mx_", "ISU4", "MX", "MX", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("welicon_", new TpsInfo("welicon_", "W6H0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("welicon2_", new TpsInfo("welicon2_", "WBA0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("welicona_", new TpsInfo("welicona_", "WAG0", "EN", "US", "prod.acquisition", "WelcomeIconTest"));
        mapTps.put ("weliconb_", new TpsInfo("weliconb_", "WAH0", "EN", "US", "prod.acquisition", "Online"));
        mapTps.put ("welico-tw_", new TpsInfo("welico-tw_", "WDF0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("welico-uk_", new TpsInfo("welico-uk_", "WE70", "UK", "GB", "prod.acquisition", "DLPR"));
        mapTps.put ("whenu_", new TpsInfo("whenu_", "W3B0", "EN", "US", "prod.acquisition", "DLPR"));
        mapTps.put ("wind_", new TpsInfo("wind_", "W480", "IT", "IT", "prod.rnwk", "Standard"));
        mapTps.put ("woman2_", new TpsInfo("woman2_", "WHR0", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("womansday_", new TpsInfo("womansday_", "WCP0", "EN", "US", "prod.partner", "oem_womansday"));
        mapTps.put ("world2_", new TpsInfo("world2_", "WHY0", "EN", "US", "prod.partner", "StandardTps"));
        mapTps.put ("worldnow_", new TpsInfo("worldnow_", "WFL0", "EN", "US", "prod.partner", "StandardTps"));
        mapTps.put ("yahoo_", new TpsInfo("yahoo_", "WK60", "EN", "US", "prod.partner", "StandardTpsNG"));
        mapTps.put ("yhmail-uk_", new TpsInfo("yhmail-uk_", "WDY0", "UK", "GB", "prod.acquisition", "DLPR"));
        mapTps.put ("zylom-de_", new TpsInfo("zylom-de_", "IDT2", "DE", "DE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("zylom-en_", new TpsInfo("zylom-en_", "WEQ0", "EU", "SE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("zylom-es_", new TpsInfo("zylom-es_", "IM34", "ES", "ES", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("zylom-fr_", new TpsInfo("zylom-fr_", "IFS3", "FR", "FR", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("zylom-it_", new TpsInfo("zylom-it_", "WET0", "IT", "IT", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("zylom-nl_", new TpsInfo("zylom-nl_", "WES0", "NL", "NL", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("zylom-se_", new TpsInfo("zylom-se_", "WER0", "EU", "SE", "prod.acquisition", "GoogleToolbarTest"));
        mapTps.put ("zylom-uk_", new TpsInfo("zylom-uk_", "WEP0", "UK", "GB", "prod.acquisition", "DLPR"));
        // All other TPSs are added above
      }
    }

    public int GetCount() {
        return (mapTps.size());
    }

    public int IncInstalledTps() {
	return countInstalledTps++;
    }

    public int IncOverInstalledTps() {
	return countOverInstalledTps++;
    }

    public int GetStats (String field) {
        if (field.equals("invalid")) {
            return countInvalidTps;
        } else if (field.equals("null")) {
            return countNullTps;
        } else if (field.equals("blank")) {
            return countBlankTps;
        } else if (field.equals("truncated")) {
            return countTruncatedTps;
        } else if (field.equals("nounderscore")) {
            return countNoUnderscoreTps;
        } else if (field.equals("default")) {
            return countDefaultTps;
        } else if (field.equals("installed")) {
            return countInstalledTps;
        } else if (field.equals("overinstalled")) {
            return countOverInstalledTps;
        } else if (field.equals("total")) {
            return countTps;
        } else {
            return -1;
        }
    }

    public String GetTpsStatsXml() {
        String strTpsStatsXml = " <TpsStats>\n";
        try {
            Set entries = mapTps.entrySet();
            Iterator it = entries.iterator();
            while(it.hasNext()) {
                Map.Entry entry = (Map.Entry) it.next();
                TpsInfo tpsInfo = (TpsInfo) entry.getValue();
                strTpsStatsXml = strTpsStatsXml
                               + "  <TPS entry='" + tpsInfo.GetTps() + "'"
                               + " start='" + tpsInfo.GetStartCount() + "'"
                               + " complete='" + tpsInfo.GetCompleteCount() + "'"
                               + " installed='" + tpsInfo.GetInstalledCount() + "'"
                               + " overinstalled='" + tpsInfo.GetOverInstalledCount() + "'"
                               + " coreinfo='" + tpsInfo.GetCoreInfoCount() + "'"
                               + " warning='" + tpsInfo.GetWarningCount() + "'"
                               + " error='" + tpsInfo.GetErrorCount() + "'"
                               + " />\n";
            }
        }
        catch (Exception e) {
            bundleLogger.logWarning("(TRACKING) TpsList Stats error in hashmap [" + e.toString() + "]");
        }

        strTpsStatsXml = strTpsStatsXml + " </TpsStats>\n";

        return strTpsStatsXml;
    }

    public TpsInfo GetTpsInfo(String strTps) {
        countTps = countTps + 1;
        if (strTps == null) {
            countNullTps = countNullTps + 1;
            strTps = "null-tps_";
        }
        else if (strTps.length() < 2) {
            countBlankTps = countBlankTps + 1;
            strTps = "blank-tps_";
        }
        else if (strTps.indexOf('_') == -1) {
            countNoUnderscoreTps = countNoUnderscoreTps + 1;
            strTps = "nounderscore-" + strTps + "_";
        }
        else if (strTps.endsWith("_") == false) {
            countTruncatedTps = countTruncatedTps + 1;
            if (countTruncatedTps % 2 == 1) {
                bundleLogger.logWarning("(TRACKING) Truncating TPS: " + strTps + ",  Count = " + countTruncatedTps);
            }
            strTps = strTps.replaceFirst("_.*$", "_");	// remove anything after the first underscore
        }

        TpsInfo info = (TpsInfo)mapTps.get(strTps);
        if (info == null) {
            countInvalidTps = countInvalidTps + 1;
            countDefaultTps = countDefaultTps + 1;
            info = (TpsInfo)mapTps.get("default");

            if (countInvalidTps % 2 == 1) {
                bundleLogger.logWarning("(TRACKING) Invalid TPS: " + strTps +
                                        "   All = " + countTps +
                                        ", Installed = " + countInstalledTps +
                                        ", OverInstalled = " + countOverInstalledTps +
                                        ", Invalid = " + countInvalidTps +
                                        ", Default = " + countDefaultTps +
                                        ";  Null = " + countNullTps +
                                        ", Blank = " + countBlankTps +
                                        ", NoUnderscore = " + countNoUnderscoreTps +
                                        ", Truncated = " + countTruncatedTps +
                                        ")");
            }
        }
        if (info == null) {
            bundleLogger.logError("Cannot look up requested TPS or default TPS: " + strTps);
        }
        return (info);
    }
}
