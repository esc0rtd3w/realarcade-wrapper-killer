/*
* Copyright 2004  RealNetworks, Inc.
* Author:  Fletch Holmquist
*/

/* $Id: BundleIni.java,v 1.1.1.1 2005/09/29 00:48:57 mbeasley Exp $
 */

import java.io.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Read the CoreInfo files, substituting tags with data from the query string.
 *
 * @author Fletch Holmquist
 */

public class BundleIni extends HttpServlet {

    public static final long serialVersionUID = 2005011404L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();
           
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        try {
            ResourceBundle rb = ResourceBundle.getBundle("LocalStrings",request.getLocale());
            response.setContentType("text/ascii");
            PrintWriter out = response.getWriter();
    
            String strTps = request.getParameter("tps");
            String strBundle = request.getParameter("bundle");
	    
            TpsList tpsList = new TpsList();
            TpsInfo tpsInfo = tpsList.GetTpsInfo(strTps);
	    if (tpsInfo == null) {
                // Log the failure to look up the TPS
                bundleLogger.logInfo("BundleIni: Failed to look up TPS: " + strTps);
                response.sendError(404);
	        return;
	    }
            strTps = tpsInfo.GetTps();	// in case the TPS was changed
    
            String strDistCode = tpsInfo.GetDistCode();
            String strTemplate = tpsInfo.GetBundleTemplate();
            String strLang = tpsInfo.GetLang();
            String strCountry = tpsInfo.GetCountry();
            String strVendor = tpsInfo.GetVendor();
    
 	    // Append "_google" to template if GoogleToolbar is requested  [FNH: Obsolete]
            String strGoogle = "";
            String strGoogleToolbar = request.getParameter("gtb");
	    try {
	        if (strGoogleToolbar != null) {
	            if (strGoogleToolbar.equals("tb") || strGoogleToolbar.equals("dt") || strGoogleToolbar.equals("tb,dt")) {
		        // strGoogle = "_google";
	            } else if (strGoogleToolbar.equals("") == false) {
                        bundleLogger.logWarning("BundleIni: Invalid GTB value: " + strGoogleToolbar);
		    }
	        }
	    }
            catch (Exception e) {
                bundleLogger.logError("BundleIni Exception when setting Google toolbar string [" + e.toString() + "]"); 
	    }
	    
	    // Get the list of Games available
            GameList gameList = new GameList();
            GameInfo gameInfo = gameList.GetGameInfo(strBundle);
	    if (gameInfo == null) {
                // Log the failure to look up the game info
                bundleLogger.logInfo("BundleIni: Failed to look up GameID: " + strBundle);
                response.sendError(404);
	        return;
	    }
            strBundle = gameInfo.GetGameId();
    
            if (strBundle == null || strBundle.length() < 2) {
                strBundle = "realarcade";
                bundleLogger.logWarning("Invalid game name in BundleIni");
            }
    
            String strFullGameName = gameInfo.GetFullGameName();
            String strGameGuid = gameInfo.GetGameGuid();
            String strExitAdName = gameInfo.GetExitAdName();
    
            String strPath = getServletContext().getRealPath("/");
            String strStandalone = "";
            if (strBundle.equals("realarcade")) {
                strStandalone = "_NoGame";	// Use gameless bundle version of the template
            }

	    strTemplate = strTemplate + strStandalone;
	    
            File fileTemplate = new File(strPath + "WEB-INF/Templates/BundleIni/" + strTemplate + strGoogle + ".ini");
            if (fileTemplate == null || fileTemplate.exists() == false || fileTemplate.canRead() == false) {
                // Log the substitution of the default template
                bundleLogger.logWarning("Failed to open Bundle.ini template for " + strTemplate + strGoogle);
                // Try to open a default template
                strTemplate = "None";
                fileTemplate = new File(strPath + "WEB-INF/Templates/BundleIni/" + strTemplate + strGoogle + ".ini");
                if (fileTemplate == null || fileTemplate.exists() == false || fileTemplate.canRead() == false) {
                    // Log the failure of the substitution of the default template
                    bundleLogger.logError("Failed to open default Bundle.ini file template: " + strTemplate + strGoogle);
                    response.sendError(404);
		    return;
                }
            }
            if (strTps == null || strTps.endsWith("_") == false) {
                strTps = "bundle_";
            }
            if (strDistCode == null || strDistCode.length() != 4) {
                strDistCode = "WZZZ";
            }
            if (strLang == null || strLang.length() != 2) {
                strLang = "EN";
            }
            if (strCountry == null || strCountry.length() < 2) {
                strCountry = "US";
            }
	    
            String strIsLoadTest = request.getParameter("loadtest");
            if (strIsLoadTest != null && strIsLoadTest.equals("true")) {
                response.setContentType("text/html");
	        response.sendRedirect("http://games-dl.real.com/gameconsole/BundleFiles/Support/StubForTest.html");
		return;
            }
    
            FileInputStream fileStream = new FileInputStream(fileTemplate);
            InputStreamReader inStream = new InputStreamReader(fileStream);
            BufferedReader in = new BufferedReader(inStream);
            String line;
    
	    out.println("# Support file for RealArcade installer    Template=" + strTemplate + strGoogle);

            while ((line = in.readLine()) != null) {
		line.trim();
		if (line.startsWith("[")) {
		    out.println("");
		}
		if ((line.length() > 0) && (line.startsWith("#") == false)) {
                    line = line.replaceAll("\\$\\{BUNDLE\\}", strBundle);
                    line = line.replaceAll("\\$\\{FULLNAME\\}", strFullGameName.replaceAll("\\$", "\\\\\\$"));
                    line = line.replaceAll("\\$\\{GUID\\}", strGameGuid);
                    line = line.replaceAll("\\$\\{EXITAD\\}", strExitAdName);
                    line = line.replaceAll("\\$\\{TPS\\}", strTps);
                    line = line.replaceAll("\\$\\{DISTCODE\\}", strDistCode);
                    line = line.replaceAll("\\$\\{VENDOR\\}", strVendor);
                    line = line.replaceAll("\\$\\{LANG\\}", strLang);
                    line = line.replaceAll("\\$\\{COUNTRY\\}", strCountry);
                    line = line.replaceAll("\\$\\{TEMPLATE\\}", strTemplate);

		    // Handle optional Google Toolbar payloads
		    if (strGoogleToolbar == null || strGoogleToolbar.indexOf("tb") == -1) {  // Toolbar
                    	line = line.replaceAll("GoogleInstApp.exe", "myaccount.ini");
                    	line = line.replaceAll("GoogleToolbar.dll", "myaccount.ini");
                    	line = line.replaceAll("GDSSetup.exe", "myaccount.ini");
                    	line = line.replaceAll("^DESCRIPTION.*=Google Toolbar.*$", "# Google Toolbar not offered");
                    	line = line.replaceAll("^DESCRIPTION.*=Google Desktop Search.*$", "# Google Desktop Search not offered");
		    }
		    else if (strGoogleToolbar.indexOf("dt") == -1) {				  // Desktop Search
                    	line = line.replaceAll("GDSSetup.exe", "myaccount.ini");
                    	line = line.replaceAll("^DESCRIPTION.*=Google Desktop Search.*$", "# Google Desktop Search not offered");
		    }
                    out.println(line);

		    if (line.startsWith("# Google ")) {
			line = in.readLine();	// Skip the line following [OPTIONAL]/DESCRIPTION
		    }
		}
            }
	    out.println("");
        }
        catch (IOException e) {
            bundleLogger.logError("BundleIni IOException [" + e.toString() + 
                                  "]: TPS=" + request.getParameter("tps") +
                                  ", Bundle=" + request.getParameter("bundle"));
            response.sendError(404);
        }
        catch (Exception e) {
            bundleLogger.logError("BundleIni Exception [" + e.toString() + 
                                  "]: TPS=" + request.getParameter("tps") +
                                  ", Bundle=" + request.getParameter("bundle"));
            response.sendError(404);
        }
    }
}

