/*
* Copyright 2005  RealNetworks, Inc.
* Author:  Fletch Holmquist
*/

/* $Id: Stubby.java,v 1.1.1.1 2005/09/29 00:48:57 mbeasley Exp $
 */

import java.io.*;
import java.text.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.RequestDispatcher;

/**
 * Servlet to return the Stubby executable
 *
 * @author Fletch Holmquist
 */

/*
 * Return the Stubby with the proper language
 */

public class Stubby extends HttpServlet {
        
    public static final long serialVersionUID = 2005071801L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();
    private static DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss");
        
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        ResourceBundle rb = ResourceBundle.getBundle("LocalStrings", request.getLocale());
        response.setContentType("application/octet-string");
        ServletOutputStream bout = response.getOutputStream();	// Binary content returned

        // Instantiate these guys early
        TpsList tpsList = new TpsList();
        TpsInfo tpsInfo = null;

	try {
			String uri = request.getRequestURI();
			int start = uri.indexOf( '_' );
			int end = uri.indexOf( "stub.exe");       
			String strTps = uri.substring( start + 1, end ); 
            //String strTps = request.getRequestURI().replaceFirst("^.*_", "").replaceFirst(".exe", "");
	    
            bundleLogger.init();
    
            // Use TPS to look up bundle data
            tpsInfo = tpsList.GetTpsInfo(strTps);
    
            if (tpsInfo == null) {
                // Log severe error
                bundleLogger.logWarning("(TRACKING) Could not locate TPS: " + strTps);
                // Go to RealArcade.com
                response.sendRedirect("http://realarcade.com/?badTpsInBundleRequest=1");
                return;
            }
            strTps = tpsInfo.GetTps();	// In case the TPS was changed
            
            String strLang = tpsInfo.GetLang();
    
            if (strLang == null || strLang.length() != 2) 
            {
				if (strLang == null) 
				{
				    strLang = "null";
				}
                bundleLogger.logWarning("Stubby [Info]: Overwriting Lang with EN, was " + strLang);
                strLang = "EN";
            }
     
            // Redirect to a language specific file 
            response.setContentType("application/octet-string");
            
            String actualURL = "/WEB-INF/Stubs/Stubby_" + strLang + ".exe"; 
            RequestDispatcher dispatcher = request.getRequestDispatcher(actualURL);
                   
            dispatcher.forward(request, response);

            /*
             * cluo: do not serve bits directly from servlet. instead, try forward
		    try 
			{	
		        // Return the proper content
			// XXXFNH: ToDo  This should be chunked into net-sized pieces
	                FileInputStream fileStream = new FileInputStream(strPath + "WEB-INF/Stubs/Stubby_" + strLang + ".exe");
	                int bytesAvailable = fileStream.available();
	                bundleLogger.logWarning("Stubby [Info]: " + strPath + "WEB-INF/Stubs/Stubby_" + strLang + ".exe  Bytes=" + bytesAvailable);
	                if (bytesAvailable > 0) 
	                {
					    response.setIntHeader("Content-Length", bytesAvailable);
					    response.setStatus(200);
					    byte[] data = new byte[bytesAvailable];
					    fileStream.read(data);
			
					    try 
						{
					        bout.write(data);
					    }
			            catch (Exception e) 
						{
			                // Log the substitution of the default template
			                bundleLogger.logWarning("STUBBY *** Write error when sending file: " + strPath + "WEB-INF/Stubs/Stubby_" + strLang + ".exe  [" + e.toString()  + "]");
			                response.sendError(404, e.toString());
			                return;
			            }
					    
					    bout.close();
					    fileStream.close();
					}
			        return;
		    }
	        catch (Exception e) 
			{
	            // Log the substitution of the default template
	            bundleLogger.logError("STUBBY *** Failed to send Stubby file: " + strPath + "WEB-INF/Stubs/Stubby_" + strLang + ".exe  [" + e.toString()  + "]");
	            response.sendError(404, e.toString());
	            return;
	        }
	        */
            
        }
        catch (IOException e) {
            bundleLogger.logError("STUBBY *** BundleRequest IOException [" + e.toString() + "]: TPS=" + request.getParameter("tps") +
			          ", Bundle=" + request.getParameter("bundle"));
	    if (tpsInfo != null) {
	        tpsInfo.IncErrorCount();
	    }
            response.sendError(404, e.toString());
        }
        catch (Exception e) {
	    if (tpsInfo != null) {
	        tpsInfo.IncErrorCount();
                bundleLogger.logError("STUBBY *** BundleRequest Exception [" + e.toString() + "]: TPS=" + request.getParameter("tps") +
			              ", Bundle=" + request.getParameter("bundle"));
	    }
            response.sendError(404, e.toString());
        }
    }
}

