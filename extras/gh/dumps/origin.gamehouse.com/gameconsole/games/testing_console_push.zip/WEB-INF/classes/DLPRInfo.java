/*
* Copyright 2007  RealNetworks, Inc.
* Author:  Vijay Dirisala
*/

/* $Id: DLPRInfo.java,v 1.3 2007/05/15 21:20:22 vijaydir Exp $
 */

import java.io.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * TODO
 *
 * @author Vijay Dirisala
 */

public class DLPRInfo extends HttpServlet {
    public static final long serialVersionUID = 2005011403L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();

	private TpsList tpsList = null;
	private Vector googleTemplates = new Vector();
	private int gtbVersion = 3;
	private int gdsVersion = 3;
	private String gtbUrl = null;
	private String gdsUrl = null;
	private int numOffers = 3;

	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		System.out.println("\nInitializing DLPRInfo class...\n");
		ServletContext context = config.getServletContext();
		String sgoogleTemplates = context.getInitParameter("GOOGLE_TEMPLATES");
		if (null != sgoogleTemplates)
		{
			StringTokenizer st = new StringTokenizer(sgoogleTemplates, ",", false);
			while (st.hasMoreTokens())
			{
				String buffer = st.nextToken();
				buffer = buffer.trim();
				System.err.println("Adding template = " + buffer);
				googleTemplates.add(buffer);
			}
		}
		gdsUrl = context.getInitParameter("GDS_PAYLOAD_URL");
		System.err.println("GDS Url = " + gdsUrl);
		gtbUrl = context.getInitParameter("GTB_PAYLOAD_URL");
		System.err.println("GTB Url = " + gtbUrl);
		try
		{
			gdsVersion = Integer.parseInt(context.getInitParameter("GDS_VERSION"));
		}
		catch (Exception ex){}
		try
		{
			gtbVersion = Integer.parseInt(context.getInitParameter("GTB_VERSION"));
		}
		catch (Exception ex) { }
		try
		{
			numOffers = Integer.parseInt(context.getInitParameter("GOOGLE_NUMOFFERS"));
		}
		catch (Exception ex) { }

		// Load the lists, since this servlet gets loaded at start-up
		tpsList = new TpsList();
	}

	boolean isGoogleTemplate(String bundleTemplate)
	{
		System.err.println("Testing " + bundleTemplate);
		for (int i = 0; i < googleTemplates.size(); i++)
		{
			String templateName = (String)googleTemplates.get(i);
			//System.err.println("Testing against " + templateName);
			if (bundleTemplate.equals(templateName))
				return true;
		}
		//System.err.println("No match!");
		return false;
	}
	void sendNoOfferResponse(PrintWriter out)
	{
		System.err.println("User doesn't get an offer");
		out.println("[DLPRInfo]");
		out.println("Offer=0");
	}

	String getPayloadUrl(TpsInfo tpsInfo, String url)
	{
		String strLang = tpsInfo.GetLang();
		return url.replaceAll("\\$\\{LANG\\}", strLang);
	}

	boolean sendGDSOffer(TpsInfo tpsInfo, HttpServletRequest request, PrintWriter out)
	{
		try{
			String sgdsVersion = request.getParameter("gds");
			int igdsVersion = Integer.parseInt(sgdsVersion);
			if (igdsVersion > 0)	// any version exists
				return false;
			System.err.println("User gets GDS");
			out.println("[DLPRInfo]");
			out.println("Offer=1");
			out.println("Times=" + numOffers);
			out.println("Url=" + getPayloadUrl(tpsInfo, gdsUrl));
			return true;
		}
		catch(Exception ex){
			bundleLogger.logWarning("(TRACKING) DLPRInfo invalid gds parameter");
			return false;
		}
	}
	boolean sendGTBOffer(TpsInfo tpsInfo, HttpServletRequest request, PrintWriter out)
	{
		try{
			String sgtbVersion = request.getParameter("gtb");
			int igtbVersion = Integer.parseInt(sgtbVersion);
			if (igtbVersion > 0)
				return false;
			System.err.println("User gets GTB");
			out.println("[DLPRInfo]");
			out.println("Offer=1");
			out.println("Times=" + numOffers);
			out.println("Url=" + getPayloadUrl(tpsInfo, gtbUrl));
			return true;
		}
		catch (Exception ex)
		{
			bundleLogger.logWarning("(TRACKING) DLPRInfo invalid gtb parameter");
			return false;
		}
	}
      
    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws IOException, ServletException
    {
		try
		{
			ResourceBundle rb = ResourceBundle.getBundle("LocalStrings", request.getLocale());
			response.setContentType("text/plain");
			PrintWriter out = response.getWriter();

			String strTps = request.getParameter("tps"); // TODO: if no tps
			System.err.println("TPS for request is " + strTps);
			TpsInfo tpsInfo = tpsList.GetTpsInfo(strTps);
			strTps = tpsInfo.GetTps();	// in case the TPS was changed

			/*
			String strDistCode = tpsInfo.GetDistCode();
			String strTemplate = tpsInfo.GetBundleTemplate();
			String strLang = tpsInfo.GetLang();
			String strCountry = tpsInfo.GetCountry();
			out.println("Distcode = " + strDistCode);
			out.println("Template = " + strTemplate);
			out.println("Language = " + strLang);
			out.println("Country = " + strCountry);
			*/
			String strTemplate = tpsInfo.GetBundleTemplate();
			String strLang = tpsInfo.GetLang();
			System.err.println("Template for request is " + strTemplate);
			if (!isGoogleTemplate(strTemplate))
			{
				System.err.println(strTemplate + " not a google template");
				sendNoOfferResponse(out);
				return;
			}
			String sgtbVersion = request.getParameter("gtb");
			int igtbVersion = Integer.parseInt(sgtbVersion);
			if (igtbVersion > 0)
			{
				sendNoOfferResponse(out);
				return;
			}
			if (sendGDSOffer(tpsInfo, request, out))
				return;
			if (sendGTBOffer(tpsInfo, request, out))
				return;
			sendNoOfferResponse(out);
		}
		catch (IOException e)
		{
			bundleLogger.logWarning("(TRACKING) DLPRInfo IOException [" + e.toString() +
								  "]: TPS=" + request.getParameter("tps") );
			response.sendError(404);
		}
		catch (Exception e)
		{
			bundleLogger.logWarning("(TRACKING) BundlePayload Exception [" + e.toString() +
								  "]: TPS=" + request.getParameter("tps") );
			response.sendError(404);
		}
    }
}
