/*
 * TpsInfo.java
 *
 * Created on January 11, 2005, 1:28 PM
 */

/**
 *
 * @author  mbeasley
 */

public class TpsInfo {
    
    private String	strTps;
    private String	strDistCode;
    private String	strLang;
    private String	strCountry;
    private String	strVendor;
    private String	strChannelTemplate;
    private String	strBundleTemplate;
    // Counters for monitoring service
    private int    	cntStart;
    private int    	cntCoreInfo;
    private int    	cntInstalled;
    private int    	cntOverInstalled;
    private int    	cntWarning;
    private int    	cntError;

    public TpsInfo(String tps, String dc, String lang, String country, String chan, String btemplate) {
        strTps = tps;
        strDistCode = dc;
        strLang = lang;
        strCountry = country;
	strVendor = "RealArcade";
        strChannelTemplate = chan;
        strBundleTemplate = btemplate;

    	cntStart = 0;
    	cntCoreInfo = 0;
    	cntInstalled = 0;
    	cntOverInstalled = 0;
    	cntWarning = 0;
    	cntError = 0;
    }

    public String	GetTps()		{ return strTps; }
    public String	GetDistCode()		{ return strDistCode; }
    public String	GetLang()		{ return strLang; }
    public String	GetCountry()		{ return strCountry; }
    public String	GetVendor()		{ return strVendor; }
    public String	GetChannelTemplate()	{ return strChannelTemplate; }
    public String	GetBundleTemplate()	{ return strBundleTemplate; }

    public int		GetStartCount()		{ return cntStart; }
    public int		GetCoreInfoCount()	{ return cntCoreInfo; }
    public int		GetCompleteCount()	{ return cntInstalled + cntOverInstalled; }
    public int		GetInstalledCount()	{ return cntInstalled; }
    public int		GetOverInstalledCount()	{ return cntOverInstalled; }
    public int		GetWarningCount()	{ return cntWarning; }
    public int		GetErrorCount()		{ return cntError; }
    
    public int		IncStartCount()		{ return ++cntStart; }
    public int		IncCoreInfoCount()	{ return ++cntCoreInfo; }
    public int		IncInstalledCount()	{ return ++cntInstalled; }
    public int		IncOverInstalledCount()	{ return ++cntOverInstalled; }
    public int		IncWarningCount()	{ return ++cntWarning; }
    public int		IncErrorCount()		{ return ++cntError; }
}
