/*
* Copyright 2005  RealNetworks, Inc.
* Author:  Fletch Holmquist & Matt Beasley
*/

/* $Id: BundleLogger.java,v 1.1.1.1 2005/09/29 00:48:57 mbeasley Exp $
 */

import java.io.*;
import java.util.*;
import java.util.logging.*;

// Standard includes for a servlet
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Logging support for the RealArcade Bundle download process.
 * Real time error reports to Site Scope.
 * 
 * The BundleLogger class should only be instantiated by calling 
 * the getInstance method. This will insure only one instance is
 * running at a time. The class could not be made a true singleton
 * because the tomcat container needs a public constructor to 
 * instantiate the class on startup. 
 *
 * @author Fletch Holmquist & Matt Beasley
 */

/*
 * Uses JDK 1.4 Logging
 */

public class BundleLogger extends HttpServlet {

    public static final long serialVersionUID = 2005011405L;
    private static BundleLogger theBundleLogger; //singleton pattern
    private static Logger logger = Logger.getLogger("realarcadebundles");
    private static ConsoleHandler logConsole = null;
    private static FileHandler logFile = null;
    private static int MAX_RECORDS = 100; // Max number of records allowed to prevent excessive mem usage
    private static Vector records = new Vector(); 
    private static String log_level = null;
    private static String bundleLogPath = ""; // Path to realbundler log file
    
    /** Public constructor
     */
    public BundleLogger() {
    }
    
    
    /** Initializes the servlet.
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);  
        
        // Read the uploadDir from the servlet parameters
        ServletContext context = config.getServletContext();
        bundleLogPath = context.getInitParameter("BUNDLE_LOG_PATH");
    	log_level = context.getInitParameter("LOG_LEVEL");
    	System.out.println("\nInitializing BundleLogger class...");
    	System.out.println("realarcadetools.log is at " + bundleLogPath);
       
    	if (bundleLogPath == null)
    		System.out.println("Please supply BUNDLE_LOG_PATH parameter");
       
    	if(log_level.equals("INFO")) {
    		logger.setLevel(Level.INFO);
    		System.out.println("Log Level set to INFO\n");
    	}
    	else if(log_level.equals("WARNING")) {
    		logger.setLevel(Level.WARNING);
    		System.out.println("Log Level set to WARNING\n");
    	}
    	else if(log_level.equals("SEVERE")) {
    		logger.setLevel(Level.SEVERE);
    		System.out.println("Log Level set to SEVERE\n");
    	}
    	else {
    		log_level = "WARNING";
    	}

		if (logFile == null) {
		    logFileCreate(bundleLogPath);
		}
    }
    
    
    /** Destroys the servlet.
     */
    public void destroy() {
        
    }
    
    /** Gets an instance of the class if not already instantiated
     *  This is part of the singleton pattern
     */
    public static BundleLogger getInstance() {
        if (theBundleLogger == null)
        	theBundleLogger = new BundleLogger();

        return theBundleLogger;
    }
    
    
    /** Returns the formatted errors to the caller (should be SiteScopeAnswer class
     *  in this case).
     */
    public String returnErrors() throws ServletException, IOException {
    	
    	String responseStr = "";
    	
        // If no records to log then respond with OK
       if(records.size() <= 0) {
            responseStr = "Okay";
        }
        // Otherwise respond with the list of error messages
        if(records.size() > 0) {
        	
            // Build the response string from the records vector
            for (int element = 0; element < records.size(); element++) {
                LogRecord thisRecord = (LogRecord)records.get(element);
                responseStr = responseStr + thisRecord.getMessage() + "\n";
            }
            
            // Clear all the error records for the next pass
            records.clear();
        }
        
        return responseStr;
    }
    

    /** Creates the local web app specific log on the filesystem in the
     *  realarcadebundles directory.
     */
    private static void logFileCreate(String file) {
           
        try {
		    if (logger == null) {
		    	logger = Logger.getLogger("realarcadebundles");
		    }
		    if (logFile != null) {
		        logFile.flush();
		        logFile.close();
			logFile = null;
		    }
	        logFile = new FileHandler(file, 64 * 1024, 8);
		    if (logFile == null) {
		        logger.warning("Log FileHander is null");
		    } else {
		        logger.addHandler(logFile);
		        logger.info("Added FileHandler");
		    }
        } 
        catch(IOException ioe) {
            logger.warning("Could not create and use Bundle log file " + file);
        }
    }

    public void logInfo(String strMsg) {
        logger.info(strMsg);
        LogRecord record = new LogRecord(Level.INFO, strMsg);
        if (records.size() < MAX_RECORDS) {
        	if(log_level.equals("INFO") == true) {
        		records.add(record);
        	}
        }
    }
    
    public void logWarning(String strMsg) {
        logger.warning(strMsg);
        LogRecord record = new LogRecord(Level.WARNING, strMsg);
        if (records.size() < MAX_RECORDS) {
        	if(log_level.equals("INFO") == true ||
			   log_level.equals("WARNING") == true) {
        		records.add(record);
        	}
        }
    }

    public void logError(String strMsg) {
	logger.severe(strMsg);
        LogRecord record = new LogRecord(Level.SEVERE, strMsg);
        if (records.size() < MAX_RECORDS) {
        	if(log_level.equals("INFO") == true ||
        	   log_level.equals("WARNING") == true ||
			   log_level.equals("SEVERE") == true) {
        			records.add(record);
        	}
        }
    }

    public void logClear(String file) {
	logFileCreate(file);
    }
}
