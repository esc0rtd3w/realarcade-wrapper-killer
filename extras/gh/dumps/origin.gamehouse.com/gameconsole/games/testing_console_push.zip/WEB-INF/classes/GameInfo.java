/*
 * GameInfo.java
 *
 * Created on January 11, 2005, 12:08 PM
 */

/**
 *
 * @author  mbeasley
 */


public class GameInfo {
    
    private String 	strGameId;
    private String 	strFullGameName;
    private String 	strGameType;
    private String 	strGameGuid;
    private String 	strExitAdName;
    private String 	strWrapperVersion;
    private boolean	intFreeAsFull;

    private int		cntStart;
    private int		cntCoreInfo;
    private int		cntInstalled;
    private int		cntOverInstalled;

    public GameInfo (String id, String full, String gtype, String guid, String advert, String wver, boolean sponsored) {
    	strGameId = id;
    	strFullGameName = full;
    	strGameType = gtype;
    	strGameGuid = guid;
    	strExitAdName = advert;
    	strWrapperVersion = wver;
    	intFreeAsFull = sponsored;

	// Use exit advert filename based on GameID if not specified
	if (strExitAdName.equals("")) {
	    if (strWrapperVersion.equals("1.0.0.0")) {
	        strExitAdName = strGameId + ".png";
	    } else {
		strExitAdName = strGameId + ".cab";
	    }
	}
	if (strExitAdName.indexOf('.') == -1) {
	    if (strWrapperVersion.equals("1.0.0.0")) {
	        strExitAdName = strExitAdName.concat(".png");
	    } else {
		strExitAdName = strExitAdName.concat(".cab");
	    }
	}
    }

    public String 	GetGameId () 		{ return strGameId; }
    public String 	GetFullGameName ()	{ return strFullGameName; }
    public String 	GetGameType ()		{ return strGameType; }
    public String 	GetGameGuid ()		{ return strGameGuid; }
    public String 	GetExitAdName ()	{ return strExitAdName; }
    public String 	GetWrapperVersion ()	{ return strWrapperVersion; }
    public boolean	IsFreeAsFull ()		{ return intFreeAsFull; }

    public int		GetStartCount()		{ return cntStart; }
    public int		GetCoreInfoCount()	{ return cntCoreInfo; }
    public int		GetInstalledCount()	{ return cntInstalled; }
    public int		GetOverInstalledCount()	{ return cntOverInstalled; }
    public int		GetCompleteCount()	{ return cntInstalled + cntOverInstalled; }
    public int		IncStartCount()		{ return ++cntStart; }
    public int		IncCoreInfoCount()	{ return ++cntCoreInfo; }
    public int		IncInstalledCount()	{ return ++cntInstalled; }
    public int		IncOverInstalledCount()	{ return ++cntOverInstalled; }
}
