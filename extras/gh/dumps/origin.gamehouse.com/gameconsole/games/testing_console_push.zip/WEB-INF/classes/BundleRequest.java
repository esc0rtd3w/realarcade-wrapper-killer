/*
* Copyright 2004  RealNetworks, Inc.
* Author:  Fletch Holmquist
*/

/* $Id: BundleRequest.java,v 1.1.1.1 2005/09/29 00:48:57 mbeasley Exp $
 */

import java.io.*;
import java.text.*;
import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * Servlet to start the RealArcade Bundle download process.
 *
 * @author Fletch Holmquist
 */

/*
 * These are things done by the Roxen RDX scripts.  Most are handled
 * by the XSL Transforms, but I list them here just to make sure nothing
 * gets dropped.
 *
 * 1) Map blank GameID values to "realarcade", log as exception
 * 2) Map GameID values based on Exceptions.Renamings XML data
 * 3) Remove trailing characters from TPS value (overture_advert3)
 * 4) Handle Comcast URLs - Map DistCode COMC to TPS comcast_
 * 5) Handle Comcast URLs - Remove _W2C0 from GameIDs
 * 6) Set value of Lang from Country value, if present
 * 7) Set DistCode from TPS, if present
 * 8) Set TPS, Lang, Bundle Template, Channel Template, Vendor, OEM from TpsList
 * 9) Set OEM Tab labels from OemList
 * A) Verify values of TPS, Lang, Bundle Template; Use defaults if needed
 * B) Verify GameID, log exception and forward to "realarcade.com" if invalid
 * C) Set Full Game Name, Game GUID, ExitAdName, Free as Full flag, Wrapper Version from GameId
 * D) Validate Bundle Template, set to "Standard" and log exception if invalid
 * E) Output payload XML file
 */

public class BundleRequest extends HttpServlet {
        
    public static final long serialVersionUID = 2005011401L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance();
    private static DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd'T'HHmmss");
        
    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
        throws IOException, ServletException
    {
        ResourceBundle rb = ResourceBundle.getBundle("LocalStrings", request.getLocale());
        response.setContentType("application/octet-string");
        ServletOutputStream bout = response.getOutputStream();	// Binary content returned

        // Instantiate these guys early
        TpsList tpsList = new TpsList();
        GameList gameList = new GameList();
	TpsInfo tpsInfo = null;
	GameInfo gameInfo = null;

	try {
     	    String strBundle = request.getParameter("bundle");
            String strTps = request.getParameter("tps");
            String strSrc = request.getParameter("src");
	    
	    // Set the "arcadeistalled" flag if it is present and arcade is installed
            String strArcadeInstalled = request.getParameter("arcadeinstalled");
	    if (strArcadeInstalled == null || strArcadeInstalled.equals("1") == false) {
	        strArcadeInstalled = "&arcadeinstalled=0";
	    } else {
	        strArcadeInstalled = "&arcadeinstalled=1";
	    }

	    if (strSrc == null) {
	        strSrc = "none";
	    }
    
            bundleLogger.init();
    
            // Use TPS to look up bundle data
            tpsInfo = tpsList.GetTpsInfo(strTps);
    
            if (tpsInfo == null) {
                // Log severe error
                bundleLogger.logWarning("(TRACKING) Could not locate TPS: " + strTps);
                // Go to RealArcade.com
                response.sendRedirect("http://realarcade.com/?badTpsInBundleRequest=1");
                return;
            }
            strTps = tpsInfo.GetTps();	// In case the TPS was changed
	    tpsInfo.IncStartCount();	// Show that a bundle request was started
            
            if (strBundle == null || strBundle.length() < 1) {
                bundleLogger.logError("(TRACKING) No game name specified to BundleRequest.exe");
		tpsInfo.IncErrorCount();
                // Go to RealArcade.com
                response.sendRedirect("http://realarcade.com/?badgameid=none");
                return;
            }
    
            String strDistCode = tpsInfo.GetDistCode();
            String strTemplate = tpsInfo.GetBundleTemplate();
            String strLang = tpsInfo.GetLang();
            String strCountry = tpsInfo.GetCountry();
    
            // Use gameid to look up game name
            gameInfo = gameList.GetGameInfo(strBundle);
            
            if (gameInfo == null) {
                bundleLogger.logWarning("(TRACKING) Bad game: " + strBundle);
		tpsInfo.IncErrorCount();
                // Go to RealArcade.com
                response.sendRedirect("http://realarcade.com/?badgameid=" + strBundle);
                return;
            }
            strBundle = gameInfo.GetGameId();

	    gameInfo.IncStartCount();	// Show that the game was requested
    
            if (strTps == null || strTps.endsWith("_") == false) {
                strTps = "bundle_";
                // Log use of default value
		tpsInfo.IncErrorCount();
                bundleLogger.logWarning("(TRACKING) Invalid TPS mapped to 'bundle_': " + strTps);
            }
            if (strDistCode == null || strDistCode.length() != 4) {
                strDistCode = "WZZZ";
                // Log use of default value
		tpsInfo.IncWarningCount();
                bundleLogger.logWarning("(TRACKING) Invalid DistCode mapped to WZZZ: " + strDistCode);
            }
            if (strLang == null || strLang.length() != 2) {
                strLang = "EN";
            }
            if (strCountry == null || strCountry.length() != 2) {
                strCountry = "US";
            }
    
            // Cookie
            String strCookieName = "RealArcadeInstall";
            String strCookieValue = "";
            String strQueryString = "";
            String strNewCookieValue;
            Cookie cookie =null;
            int count = 1;
            Cookie[] cookies = request.getCookies();
            if ((cookies != null) && (cookies.length > 0)) {
                for (int i = 0; i < cookies.length; i++) {
                    cookie = cookies[i];
                    if (strCookieName.equals(cookie.getName())) {
            	        strCookieValue = cookie.getValue();
            	        strQueryString = strCookieValue;
            	    }
                }
            }
            cookie =  new Cookie(strCookieName, strCookieValue);
            if (strCookieValue.equals("") || strCookieValue.indexOf("count=") == -1) {
                Date now = new Date();
                strNewCookieValue = "&origTPS=" + strTps + "&origBundle=" + strBundle + 
			            "&when=" + dateFormat.format(now) + "&count=1" + "&src=" + strSrc + strArcadeInstalled;
		strNewCookieValue = strNewCookieValue.replace(',', '~');
		strNewCookieValue = strNewCookieValue.replace(';', '~');
		strNewCookieValue = strNewCookieValue.replace(' ', '~');
                cookie = new Cookie(strCookieName, strNewCookieValue);
            } else {
                String strCount = strCookieValue.replaceFirst("^.*count=", "");
		strCount = strCount.replaceFirst("&.*$", "");
                try {
                    count = Integer.parseInt(strCount);
                } catch (NumberFormatException nfe) {
                    count = 1000;
                }
                strNewCookieValue = strCookieValue.replaceFirst("count=[0-9]*", "count=" + String.valueOf(count + 1));
                strNewCookieValue = strCookieValue.replaceFirst("arcadeinstalled=[01]", "");
		strNewCookieValue = strNewCookieValue + strArcadeInstalled;
                cookie.setValue(strNewCookieValue);
            }
	    try {
                cookie.setMaxAge(30 * 24 * 60 * 60);
                response.addCookie(cookie);
	    }
            catch (Exception e) {
                bundleLogger.logWarning("(TRACKING) BundleRequest Cookie Exception [" + e.toString() + "]: TPS=" + 
				        request.getParameter("tps") + ", Bundle=" + request.getParameter("bundle"));
            }
     
            // Redirect to a known HTML file if load testing
            String strIsLoadTest = request.getParameter("loadtest");
            if (strIsLoadTest != null && strIsLoadTest.equals("true")) {
            	response.setContentType("text/html");
               	response.sendRedirect("http://games-dl.real.com/gameconsole/BundleFiles/Support/StubForTest.html");
            	return;
            }
	    
            // Send them to the stub
            response.sendRedirect("http://realarcadebundles.real.com/servlet/Stubby/" + strBundle + "_" + strTps + "stub.exe");

            // Send them to the stub
            // bundleLogger.logInfo("(TRACKING) Served up " + strTps + "/" + strBundle);
            // response.sendRedirect("http://games-dl.real.com/gameconsole/stubs/" + strTps + "/" + strBundle + ".exe"
            // 		    + "?ref=dl" + strQueryString + "&ext=.exe");
        }
        catch (IOException e) {
            bundleLogger.logWarning("(TRACKING) BundleRequest IOException [" + e.toString() + "]: TPS=" + request.getParameter("tps") +
			          ", Bundle=" + request.getParameter("bundle"));
	    if (tpsInfo != null) {
	        tpsInfo.IncErrorCount();
	    }
            response.sendError(404);
        }

        catch (Exception e) {
	    if (tpsInfo != null) {
	        tpsInfo.IncErrorCount();
	    }
            response.sendError(404);
        }
    }
}

