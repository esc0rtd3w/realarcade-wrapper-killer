/*
 * fullfiletest.java
 *
 * Created on January 10, 2005, 12:33 PM
 */


import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;


/**
 *
 * @author  mbeasley
 * @version
 */
public class LogTest extends HttpServlet {
    
    public static final long serialVersionUID = 2005011407L;
    private static BundleLogger bundleLogger = BundleLogger.getInstance(); //calls singeton instance

    /** Initializes the servlet.
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);        
    }
    
    /** Destroys the servlet.
     */
    public void destroy() {
    }
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	
    	bundleLogger.logInfo("Starting log level tests...");
    	
    	//display the results
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Full File Test Error Report</title>");
        out.println("<body bgcolor=#330099>");
        out.println("<table align=center cellspacing=8 cellpadding=2 border=3 bgcolor=#ffffff bordercolor=#000000>");
        out.println("<caption><font face=arial size=6 color=#ffffff>Testing BundleLogger Class</font></caption>");
        
        for(int test = 0; test < 3; test++) {
	        out.println("<tr>");
	        if(test == 0) {
	        	out.println("<td width=600><font face=arial size=3 color=#000000><b>Testing INFO Level</b></font></td>");
	        	bundleLogger.logInfo("Testing INFO Level");
	        }
	        if(test == 1) {
	        	out.println("<td width=600><font face=arial size=3 color=#000000><b>Testing WARNING Level</b></font></td>");
	        	bundleLogger.logWarning("Testing WARNING Level");
	        }
	        if(test == 2) {
	        	out.println("<td width=600><font face=arial size=3 color=#000000><b>Testing SEVERE Level</b></font></td>");
	        	bundleLogger.logError("Testing SEVERE Level");
	        }
	        out.println("</tr>");
        }
        
        out.println("<tr>");
        out.println("<td width=600><font face=arial size=3 color=#000000><b>Test Complete</b></font></td>");
        bundleLogger.logInfo("Testing Complete");
        out.println("</tr>");
        out.println("</body>");
        out.println("</html>");
        out.close();
    }
    
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Does file system check of all bundle files";
    }
}
