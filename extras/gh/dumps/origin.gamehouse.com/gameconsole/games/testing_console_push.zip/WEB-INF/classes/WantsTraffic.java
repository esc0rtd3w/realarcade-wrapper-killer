/*
 * Created on Feb 23, 2005
 */

/**
 * @author mbeasley
 *
 * Replaces the EbiWantsTraffic functionality, 
 * allowing interaction with the load balancers.
 */

//Standard includes for a servlet
import java.io.PrintWriter;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class WantsTraffic extends HttpServlet {
	
    public static final long serialVersionUID = 2005022805L;
    private static WantsTraffic wantsTraffic; //singleton pattern
    private static BundleLogger bundleLogger = BundleLogger.getInstance(); //calls singeton instance
    private static String WANTS_TRAFFIC_PROPERTY = "yes";
    private String COMMANDABLE_IPS = "";
    private Vector IPList = new Vector();
    
    public WantsTraffic() {
    	
    }
    
    /** Initializes the servlet.
     */
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        System.out.println("\nInitializing wantsTraffic class...\n");
        ServletContext context = config.getServletContext();
        COMMANDABLE_IPS = context.getInitParameter("COMMANDABLE_IPS");

        // Load the lists, since this servlet gets loaded at start-up
        TpsList tpsList = new TpsList();
        GameList gameList = new GameList();
    }
    
    /** Destroys the servlet.
     */
    public void destroy() {
    }

    public void doGet (HttpServletRequest request,
		       HttpServletResponse response) {

		try {
			response.setContentType("text/ascii");
	        PrintWriter out = response.getWriter();
	        boolean safe = false;
	        
	        // Establish request is from a safe IP
	        String requestIP = request.getRemoteAddr(); 
	        // Get the list of safe IP prefixes
	        IPList = getSafeIPs(COMMANDABLE_IPS);
	        // Test the getSafeIPs method 
	        for(int ip = 0; ip < IPList.size(); ip++) {
	        	String IPElement = (String)IPList.elementAt(ip);
	        	if(requestIP.indexOf(IPElement) > -1) {
	        		safe = true;
	        		ip = IPList.size();
	        	}
	        }
	        if(safe == true) {
		        // Read the command
		        if(request.getParameter("rn_command").indexOf("get-wants-traffic") > -1) {
	
		        	if(WANTS_TRAFFIC_PROPERTY.equals("no")) {
		        		//set response status to 503, return expected string
		        		response.sendError(503, "no");
		        	}
		        	if(WANTS_TRAFFIC_PROPERTY.equals("yes")) {
		        		//set response status to 200, return expected string
		        		response.setStatus(200);
		        		out.println("yes");
		        	}
		        }
		        if(request.getParameter("rn_command").indexOf("set-wants-traffic") > -1) {
		        	
		        	if(request.getParameter("rn_command").indexOf("param name=\"wants-traffic\" value=\"true\"") > -1){
		        		WANTS_TRAFFIC_PROPERTY = "yes";
		        		out.println("WantsTraffic property was set to yes");
		        	}
		        	
		        	if(request.getParameter("rn_command").indexOf("param name=\"wants-traffic\" value=\"false\"") > -1){
		        		WANTS_TRAFFIC_PROPERTY = "no";
		        		out.println("WantsTraffic property was set to no");
		        	}
		        }
		    }
	        else if(safe == false) {
	        	//If this is a hacker or the wrong address, make the response
	        	//hide what is really going on. Don't make it easy for hackers.
	        	response.sendError(404, "The requested page is not available.");
	        }
		} catch (Exception e) {
		    e.printStackTrace ();
		}
    }
    
    public String getWantsTraffic() {    	
    	bundleLogger.logInfo("WantsTraffic returned " + WANTS_TRAFFIC_PROPERTY);
    	return WANTS_TRAFFIC_PROPERTY;
    }
    
    public void setWantsTraffic(String state) {
    	WANTS_TRAFFIC_PROPERTY = state;
    }
    
    // Makes sure only one instance is running
    public static WantsTraffic getInstance() {
        if (wantsTraffic == null)
        	wantsTraffic = new WantsTraffic();

        return wantsTraffic;
    }
    
    // Reads context variable from web.xml, returns an array of strings
    // containing the "safe" ip prefixes
    private Vector getSafeIPs(String IPList) {
    	Vector retVal = new Vector();
    	StringTokenizer st = new StringTokenizer(IPList, ",", false);
    	
        while (st.hasMoreTokens()) {
            String buffer = st.nextToken();
            retVal.add(buffer);
        }
    	
    	return retVal;
    }

}
