/* cryptx.h - Troels K. 2003 */

#ifndef _cryptx_H
#define _cryptx_H

#ifdef __cplusplus
   extern "C" {
#endif

extern void crypt_encode(void* buffer, size_t cb, const char* password);
extern void crypt_decode(void* buffer, size_t cb, const char* password);

#ifdef __cplusplus
   }
#endif

#endif /* _cryptx_H */
