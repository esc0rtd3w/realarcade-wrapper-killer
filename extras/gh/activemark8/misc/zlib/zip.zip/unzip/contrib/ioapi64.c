/* ioapi64.c - Troels K 2004
*/

#include <stdio.h> /* fpos_t */

#define fill_fopen_filefunc fill_fopen_filefunc_notused
#include "../ioapi.c"
#undef fill_fopen_filefunc

#include <io.h> /* _filelengthi64 */

local ZPOS_T ZCALLBACK ftell_file_func64 OF((
   voidpf opaque,
   voidpf stream));

local long ZCALLBACK fseek_file_func64 OF((
   voidpf opaque,
   voidpf stream,
   ZOFF_T offset,
   int origin));

local ZPOS_T ZCALLBACK ftell_file_func64 (opaque, stream)
   voidpf opaque;
   voidpf stream;
{
    ZPOS_T ret;
    fgetpos((FILE *)stream, &ret);
    return ret;
}

local long ZCALLBACK fseek_file_func64 (opaque, stream, offset, origin)
   voidpf opaque;
   voidpf stream;
   ZOFF_T offset;
   int origin;
{
    ZPOS_T pos;
    FILE* file = (FILE*)stream;
    switch (origin)
    {
    case ZLIB_FILEFUNC_SEEK_CUR :
        fgetpos(file, &pos);
        pos+=offset;
        break;
    case ZLIB_FILEFUNC_SEEK_END :
        pos = _filelengthi64(_fileno(file));
        pos+=offset;
        break;
    case ZLIB_FILEFUNC_SEEK_SET :
        pos = offset;
        break;
    default: return -1;
    }
    return fsetpos(file, &pos) ? -1 : 0;
}

void fill_fopen_filefunc (pzlib_filefunc_def)
  zlib_filefunc_def* pzlib_filefunc_def;
{
    pzlib_filefunc_def->zopen_file = fopen_file_func;
    pzlib_filefunc_def->zread_file = fread_file_func;
    pzlib_filefunc_def->zwrite_file = fwrite_file_func;
    pzlib_filefunc_def->ztell_file = ftell_file_func64; /* ! */
    pzlib_filefunc_def->zseek_file = fseek_file_func64; /* ! */
    pzlib_filefunc_def->zclose_file = fclose_file_func;
    pzlib_filefunc_def->zerror_file = ferror_file_func;
    pzlib_filefunc_def->opaque = NULL;
}
