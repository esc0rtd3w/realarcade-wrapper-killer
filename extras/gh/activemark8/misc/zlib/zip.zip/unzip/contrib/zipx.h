/* zipx.h - Troels K. 2003-2004 */

#ifndef _zipx_H
#define _zipx_H

#ifndef _zip_H
   #include "../zip.h"
#endif

#ifdef __cplusplus
   extern "C" {
#endif

extern void zip_fill_filefunc OF((zipFile, zlib_filefunc_def*));

#ifdef __cplusplus
   }
#endif

#endif /* _zipx_H */
