/* iomem.h */
/* Copyright (c) 2003-2004 by Troels K. */

#ifndef __IOMEM_H__
#define __IOMEM_H__

#ifndef EXTERN_C
   #ifdef __cplusplus
      #define EXTERN_C    extern "C"
   #else
      #define EXTERN_C    extern
   #endif
#endif

struct zlib_filefunc_def_s;
struct zlib_filefunc_defW_s;

#include "bool.h"

struct _MEMFILEDATA;
struct _MEMFILEIMPL;

typedef struct _MEMFILEDATA* MEMDATAHANDLE;
typedef struct _MEMFILEIMPL* MEMFILEHANDLE;

EXTERN_C MEMDATAHANDLE mem_create_file(const TCHAR* name, void* buffer, size_t buflen);
EXTERN_C MEMFILEHANDLE mem_open_file  (struct zlib_filefunc_def_s*, MEMDATAHANDLE);
EXTERN_C void*         mem_detach(MEMDATAHANDLE*);
EXTERN_C void          mem_delete_file(MEMDATAHANDLE*);

EXTERN_C ZPOS_T mem_filelength(MEMFILEHANDLE);
EXTERN_C BOOL   mem_feof      (MEMFILEHANDLE);
#ifdef _TIME_T_DEFINED
EXTERN_C int    mem_touch     (MEMFILEHANDLE, time_t utc);
#endif

#ifndef _MSDOS
   EXTERN_C MEMFILEHANDLE mem_open_filew  (struct zlib_filefunc_defW_s*, struct _MEMFILEDATA*);
#endif

#ifdef _UNICODE
   #define tmem_open_file mem_open_filew
#else
   #define tmem_open_file mem_open_file
#endif

#endif /* __IOMEM_H__ */
