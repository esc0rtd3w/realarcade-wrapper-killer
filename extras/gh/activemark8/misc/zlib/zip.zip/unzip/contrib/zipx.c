/* zipx.c - Troels K. 2003-2004 */

#include <stdio.h>
#include "zipx.h"

#ifndef local
#  define local static
#endif

local uLong ZCALLBACK zip_write(voidpf opaque, voidpf stream, const void* src, uLong cb)
{
   zipFile file = (zipFile)opaque;
   uLong dwWritten = 0;
   const int result = zipWriteInFileInZip(file, src, cb);
   if (result > 0) dwWritten = (uLong)cb;
   return dwWritten;
}

local int ZCALLBACK zip_close(voidpf opaque, voidpf stream)
{
   zipFile file = (zipFile)opaque;
   zipCloseFileInZip(file);
   return 0;
}

void zip_fill_filefunc(zipFile file, zlib_filefunc_def* api)
{
   api->zopen_file  = NULL;
   api->zread_file  = NULL;
   api->zwrite_file = zip_write;
   api->ztell_file  = NULL;
   api->zseek_file  = NULL;
   api->zclose_file = zip_close;
   api->zerror_file = NULL;
   api->opaque      = file;
}
