/* iomem.c */
/* Copyright (c) 2003-2004 by Troels K. */
/*
   Dynamically allocated memory version. Troels K 2004
      mem_close does not delete the actual data: file is multi-session. Have filenames.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <tchar.h>
#include <time.h>

#include "zlib.h"
#ifndef _ZLIBIOAPI_H
   #include "../ioapi.h"
#endif
#include "iomem.h"
#include "fseek.h"
#include "bool.h"

#ifndef local
#  define local static
#endif

typedef struct _MEMFILEDATA
{
   BOOL bModified;
   time_t utc;
   ZPOS_T length;
   unsigned char* p;
   TCHAR* szFileName;
   struct _MEMFILEDATA* next;
} MEMFILEDATA; 

typedef struct _MEMFILEIMPL
{
   MEMFILEDATA* file;
   ZPOS_T position;
} MEMFILE;

typedef struct _FILESYSTEMIMPL
{
   struct _MEMFILEDATA* file_list;
} MEMFS;

local uLong ZCALLBACK mem_read (voidpf opaque, voidpf stream, void* dst, uLong cb)
{
   MEMFILEHANDLE handle = (MEMFILE*)stream;
   size_t dwRead = 0;
   if (handle->position < handle->file->length)
   {
      dwRead = min(cb, (handle->file->length - handle->position));
      memcpy(dst, handle->file->p + handle->position, dwRead);   
      handle->position+=dwRead;
   }
   return dwRead;
}

local uLong ZCALLBACK mem_write (voidpf opaque, voidpf stream, const void* src, uLong cb)
{
   MEMFILEHANDLE handle = (MEMFILE*)stream;
   ZPOS_T oldlength = handle->file->length;
   handle->file->length = max(handle->position + cb, handle->file->length);
   handle->file->p      = (unsigned char*)realloc(handle->file->p, handle->file->length);
   if (handle->position > oldlength)
   {
      memset(handle->file->p + oldlength, 0, handle->position - oldlength);
   }
   memcpy(handle->file->p + handle->position, src, cb);
   handle->position+=cb;
   handle->file->bModified = TRUE;
   handle->file->utc = time(NULL);
   return cb;
}

local ZPOS_T ZCALLBACK mem_tell (voidpf opaque, voidpf stream)
{
   MEMFILEHANDLE handle = (MEMFILE*)stream;
   return handle->position;
}

local long ZCALLBACK mem_seek (voidpf opaque, voidpf stream, ZOFF_T offset, int origin)
{
   MEMFILEHANDLE handle = (MEMFILE*)stream;
   return fseek_calc(offset, origin, &handle->position, handle->file->length);
}

local int ZCALLBACK mem_close (voidpf opaque, voidpf stream)
{
   MEMFILEHANDLE handle = (MEMFILE*)stream;
   free(handle);
   return 0;
}

local int ZCALLBACK mem_error (voidpf opaque, voidpf stream)
{
   MEMFILEHANDLE handle = (MEMFILE*)stream;
   return 0;
}

ZPOS_T mem_filelength(MEMFILEHANDLE handle)
{
   return handle->file->length;
}

int mem_feof(MEMFILEHANDLE handle)
{
   return (handle->position >= handle->file->length);
}

int mem_touch(MEMFILEHANDLE handle, time_t utc)
{
   handle->file->utc = utc;
   return 0;
}

void* mem_detach(MEMDATAHANDLE* handle)
{
   void* p = (*handle)->p;
   free((*handle)->szFileName);
   free(*handle);
   *handle = NULL;
   return p;
}

void mem_delete_file(MEMDATAHANDLE* handle)
{
   free(mem_detach(handle));
}

void iomem_fill_filefunc(struct zlib_filefunc_def_s* api, MEMFILEHANDLE handle)
{
   api->zopen_file  = NULL;
   api->zread_file  = mem_read;
   api->zwrite_file = mem_write;
   api->ztell_file  = mem_tell;
   api->zseek_file  = mem_seek;
   api->zclose_file = mem_close;
   api->zerror_file = mem_error;
   api->opaque      = handle;
}

MEMDATAHANDLE mem_create_file(const TCHAR* name, void* buffer, size_t buf_len)
{
   MEMFILEDATA* handle = (MEMFILEDATA*)malloc(sizeof(MEMFILEDATA));
 
   handle->p          = (unsigned char*)buffer;
   handle->length     = buf_len;
   handle->utc        = time(NULL);
   handle->szFileName = _tcsdup(name);
   handle->next       = NULL;
   handle->bModified  = FALSE;
   return handle;
}

MEMFILEHANDLE mem_open_file(struct zlib_filefunc_def_s* api, MEMFILEDATA* filedata)
{
   MEMFILEHANDLE handle = malloc(sizeof(*handle));
   handle->position = 0;
   handle->file     = filedata;
   iomem_fill_filefunc(api, handle);
   return handle;
}

#ifndef _MSDOS
MEMFILEHANDLE mem_open_filew(struct zlib_filefunc_defW_s* api, struct _MEMFILEDATA* data)
{
   /* just cast away zlib_filefunc_defW_s - we're not using api.zopen_func(char) */
   return mem_open_file((struct zlib_filefunc_def_s*)api, data);
}
#endif
