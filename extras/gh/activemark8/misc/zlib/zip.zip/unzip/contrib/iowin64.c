/* iowin64.c - Troels K 2004
*/

#include <stdio.h> /* fpos_t */

#define fill_win32_filefunc fill_win32_filefunc_notused
#include "../iowin32.c"
#undef fill_win32_filefunc

#ifndef local
#  define local static
#endif

local ZPOS_T ZCALLBACK win32_tell_file_func64 OF((
   voidpf opaque,
   voidpf stream));

local long ZCALLBACK win32_seek_file_func64 OF((
   voidpf opaque,
   voidpf stream,
   ZPOS_T offset,
   int origin));

local ZPOS_T ZCALLBACK win32_tell_file_func64 (opaque, stream)
   voidpf opaque;
   voidpf stream;
{
    ZPOS_T ret=-1;
    HANDLE hFile = NULL;
    if (stream!=NULL)
        hFile = ((WIN32FILE_IOWIN*)stream) -> hf;
    if (hFile)
    {
        LARGE_INTEGER li;
        li.QuadPart = 0;
        li.u.LowPart = SetFilePointer(hFile, li.u.LowPart, &li.u.HighPart, FILE_CURRENT);
        if ( (li.LowPart == 0xFFFFFFFF) && (GetLastError() != NO_ERROR))
        {
            DWORD dwErr = GetLastError();
            ((WIN32FILE_IOWIN*)stream) -> error=(int)dwErr;
            ret = -1;
        }
        else
            ret=li.QuadPart;
    }
    return ret;
}

local long ZCALLBACK win32_seek_file_func64 (opaque, stream, offset, origin)
   voidpf opaque;
   voidpf stream;
   ZPOS_T offset;
   int origin;
{
    DWORD dwMoveMethod=0xFFFFFFFF;
    HANDLE hFile = NULL;

    long ret=-1;
    if (stream!=NULL)
        hFile = ((WIN32FILE_IOWIN*)stream) -> hf;
    switch (origin)
    {
    case ZLIB_FILEFUNC_SEEK_CUR :
        dwMoveMethod = FILE_CURRENT;
        break;
    case ZLIB_FILEFUNC_SEEK_END :
        dwMoveMethod = FILE_END;
        break;
    case ZLIB_FILEFUNC_SEEK_SET :
        dwMoveMethod = FILE_BEGIN;
        break;
    default: return -1;
    }

    if (hFile)
    {
        LARGE_INTEGER* li = (LARGE_INTEGER*)&offset;
        DWORD dwSet = SetFilePointer(hFile, li->u.LowPart, &li->u.HighPart, dwMoveMethod);
        if (dwSet == INVALID_SET_FILE_POINTER)
        {
            DWORD dwErr = GetLastError();
            ((WIN32FILE_IOWIN*)stream) -> error=(int)dwErr;
            ret = -1;
        }
        else
            ret=0;
    }
    return ret;
}

void fill_win32_filefunc (pzlib_filefunc_def)
  zlib_filefunc_def* pzlib_filefunc_def;
{
    pzlib_filefunc_def->zopen_file = win32_open_file_func;
    pzlib_filefunc_def->zread_file = win32_read_file_func;
    pzlib_filefunc_def->zwrite_file = win32_write_file_func;
    pzlib_filefunc_def->ztell_file = win32_tell_file_func64; /* ! */
    pzlib_filefunc_def->zseek_file = win32_seek_file_func64; /* ! */
    pzlib_filefunc_def->zclose_file = win32_close_file_func;
    pzlib_filefunc_def->zerror_file = win32_error_file_func;
    pzlib_filefunc_def->opaque=NULL;
}
