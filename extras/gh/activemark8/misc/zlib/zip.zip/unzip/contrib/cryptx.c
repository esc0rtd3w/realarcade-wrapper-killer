/* cryptx.c - Troels K. 2003 */

#include <stdlib.h> /* srand */
#include <time.h> /* time */
#include "cryptx.h"

#define INCLUDECRYPTINGCODE_IFCRYPTALLOWED /* for ZCR_SEED2 */
#include "..\crypt.h"
#include "..\..\zlib\zlib.h"

void crypt_encode(void* buffer, size_t cb, const char* password)
{
   unsigned long keys[3];
   const unsigned long* table = get_crc_table();
   unsigned char* bytebuffer = (unsigned char*)buffer;
   int i;
   int t;
   
   srand((unsigned)(time(NULL) ^ ZCR_SEED2));
   init_keys(password,keys,table);

   for (i = 0; i < cb; i++)
      bytebuffer[i] = zencode(keys, table, bytebuffer[i], t);
}

void crypt_decode(void* buffer, size_t cb, const char* password)
{
   unsigned long keys[3];
   const unsigned long* table = get_crc_table();
   unsigned char* bytebuffer = (unsigned char*)buffer;
   int i;
   
   init_keys(password,keys,table);
   for (i = 0; i < cb; i++)
      zdecode(keys, table, bytebuffer[i]);
}
