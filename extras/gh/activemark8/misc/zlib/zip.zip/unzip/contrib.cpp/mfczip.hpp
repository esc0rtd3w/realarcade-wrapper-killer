// mfczip.hpp

#ifndef __MFCZIP_HPP__
#define __MFCZIP_HPP__

#ifndef __ZIP_HPP__
#include "zip.hpp"
#endif

#ifndef __UNZIP_HPP__
#include "unzip.hpp"
#endif

#ifdef __AFX_H__

/////////////////////////////////////////////////////////////////////////////
// CMFCZipBase - Copyright (c) Troels K. 2002-2004

class CMFCZipBase
{
// Attributes
public:
   enum
   {
      LIT_default_buf_size = 16*1024
   };
#if _MFC_VER > 0x0253
   CByteArray m_buffer;
#else
   class CMyByteArray : public CByteArray
   { 
   public:
      LPVOID GetData() { return m_pData; }
   } m_buffer;
#endif
   BOOL m_bContinue;
   int  m_error_count;
   zlib_filefunc_def m_filefunc;

// Construction
public:
   CMFCZipBase(size_t buf_size);

// Operations
public:
   void SetFileFunc(CFile*);

           int WriteStatus (LPCTSTR fmt, ...);
   virtual int WriteStatusV(LPCTSTR fmt, va_list argptr);
   virtual void OnError(LPCTSTR lpszFilePath);
};

/////////////////////////////////////////////////////////////////////////////
// CMFCZip - Copyright (c) Troels K. 2002

class CMFCZip : public CZip, public CMFCZipBase
{
// Operations
public:
   CMFCZip(size_t buf_size = LIT_default_buf_size);

   BOOL AddNew(LPCTSTR lpszFilter, BOOL bRecursive, LPCTSTR lpszPrefix = NULL); // returns errors

   BOOL Open(LPCTSTR lpszFilePath, BOOL bAppend = FALSE, const char** globalcomment = NULL);
   BOOL Open(CFile*, BOOL bAppend = FALSE, const char** globalcomment = NULL);

   BOOL AddNew(FILE* file,
               LPCTSTR filenameinzip,
               LPCTSTR comment = NULL,
               int level = Z_BEST_COMPRESSION,
               int method = Z_DEFLATED,               
               const void* extrafield_local = NULL,
               uInt size_extrafield_local = 0,
               const void* extrafield_global = NULL,
               uInt size_extrafield_global = 0
               );

   BOOL OpenNew(LPCTSTR filename,
               const zip_fileinfo* zipfi,
               LPCTSTR comment = NULL,
               int level = Z_BEST_COMPRESSION,
               int method = Z_DEFLATED,               
               const void* extrafield_local = NULL,
               uInt size_extrafield_local = 0,
               const void* extrafield_global = NULL,
               uInt size_extrafield_global = 0
               );

// Implementation
public:
   virtual ~CMFCZip();
   virtual BOOL AddNewAccept(LPCTSTR lpszFilePath) const;
};

/////////////////////////////////////////////////////////////////////////////
// CMFCUnzip - Copyright (c) Troels K. 2002-2003

class CMFCUnzip : public CUnzip, public CMFCZipBase
{
// Attributes
public:

// Operations
public:
   CMFCUnzip(size_t buf_size = LIT_default_buf_size);

   BOOL Open(LPCTSTR lpszFilePath);
   BOOL Open(CFile*);
   BOOL GetGlobalComment(CString*);

   BOOL Extract(BOOL bFullPath, BOOL bOverwrite, LPCTSTR lpszDst = NULL);
   BOOL GetCurrentFileInfo(unz_file_info *pfile_info,
                    CString*szFileName = NULL,
                    void *extraField = NULL,
                    uLong extraFieldBufferSize = 0,
                    CString*szComment = NULL) const;
   BOOL ExtractCurrentFile(FILE* file);
   BOOL ExtractCurrentFile(CFile*);

// Implementation
public:
   virtual ~CMFCUnzip();
   virtual BOOL ExtractAccept(LPCTSTR write_filename, BOOL bOverwrite);
};

/////////////////////////////////////////////////////////////////////////////
// CZipFileFind - Copyright (c) Troels K. 2002

class CZipFileFind : public CFileFind
{
// Attributes
public:
protected:
   int m_index;
#ifdef _WIN32
   struct FILEINFO : public WIN32_FIND_DATA, public unz_file_info_s 
   {
   };
#else
   struct FILEINFO : public _find_t, public unz_file_info_s 
   {
   };
#endif

// Construction
public:
   CZipFileFind(CMFCUnzip* pArchive);

// Operations
public:
   BOOL GetCurrentFileInfo(unz_file_info*) const;

// Implementation
public:
   virtual ~CZipFileFind();
   virtual BOOL FindFile(LPCTSTR pstrName = NULL, DWORD dwFlags = 0);
   virtual BOOL FindNextFile();
   virtual CString GetFilePath() const;
protected:
   virtual void CloseContext();
   inline       CMFCUnzip* GetArchive()       { return (      CMFCUnzip*)m_hContext; }
   inline const CMFCUnzip* GetArchive() const { return (const CMFCUnzip*)m_hContext; }
   BOOL FillFindData(FILEINFO*);
};
#endif // __AFX_H__

#include "mfczip.inl"

#endif // __MFCZIP_HPP__
