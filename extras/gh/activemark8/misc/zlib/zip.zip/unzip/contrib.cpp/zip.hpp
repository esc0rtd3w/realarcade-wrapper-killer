// zip.hpp

#ifndef __ZIP_HPP__
#define __ZIP_HPP__

#ifndef __BOOL_H__
   #include "bool.h"
#endif

#ifndef _zip_H
   #include <zip.h>
#endif

/////////////////////////////////////////////////////////////////////////////
// CZip - Copyright (c) Troels K. 2002-2004

class CZip
{
// Attributes
public:
   zipFile m_handle;

// Construction
public:
   CZip();

// Operations
public:
   BOOL Open(const char* lpszFilePath, BOOL bAppend = FALSE, const char** globalcomment = NULL, zlib_filefunc_def* pzlib_filefunc_def = NULL);
   BOOL IsOpen(void) const;

   BOOL AddNew(FILE* file,
               const char* filenameinzip,
               void* buf,
               size_t buf_size,
               const char* comment = NULL,
               int level = Z_BEST_COMPRESSION,
               int method = Z_DEFLATED,               
               const void* extrafield_local = NULL,
               uInt size_extrafield_local = 0,
               const void* extrafield_global = NULL,
               uInt size_extrafield_global = 0
               );

   BOOL OpenNew(const char* filename,
               const zip_fileinfo* zipfi,
               const char* comment = NULL,
               int level = Z_BEST_COMPRESSION,
               int method = Z_DEFLATED,               
               const void* extrafield_local = NULL,
               uInt size_extrafield_local = 0,
               const void* extrafield_global = NULL,
               uInt size_extrafield_global = 0
               );
   BOOL WriteNew(const voidp, size_t len);
   BOOL CloseNew();

// Implementation
public:
   virtual ~CZip();
   virtual void Close();
   static BOOL filetime(LPCTSTR, tm_zip*, DWORD* dt);
   static BOOL filetime(FILE*  , tm_zip*, DWORD* dt);
};

#include "zip.inl"

#endif // __ZIP_HPP__
