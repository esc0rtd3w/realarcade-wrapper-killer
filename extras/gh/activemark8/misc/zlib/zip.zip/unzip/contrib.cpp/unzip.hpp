// unzip.hpp

#ifndef __UNZIP_HPP__
#define __UNZIP_HPP__

#ifndef __BOOL_H__
   #include "bool.h"
#endif

#ifndef _unz_H
   #include "../unzip.h"
#endif

/////////////////////////////////////////////////////////////////////////////
// CUnzip - Copyright (c) Troels K. 2002-2004

class CUnzip
{
// Attributes
public:
   unzFile m_handle;

// Construction
public:
   CUnzip();

// Operations
public:
   BOOL Open(const char* lpszFilePath, zlib_filefunc_def* p = NULL);
   BOOL IsOpen(void) const;

   BOOL GetGlobalInfo(unz_global_info *) const;
   int GetGlobalCount(void) const;
   BOOL GetGlobalComment(char *szComment, uLong uSizeBuf) const;

   BOOL GoToFirstFile(void);
   BOOL GoToNextFile(void);
   BOOL GetCurrentFileInfo(unz_file_info *pfile_info,
                    char *szFileName = NULL,
                    uLong fileNameBufferSize = 0,
                    void *extraField = NULL,
                    uLong extraFieldBufferSize = 0,
                    char *szComment = NULL,
                    uLong commentBufferSize = 0) const;

   BOOL OpenCurrentFile(const char* password = NULL);
   int ReadCurrentFile(voidp buf, size_t len);   
   BOOL ExtractCurrentFile(FILE* file, void* buf, size_t buf_size);
   BOOL CloseCurrentFile();

   BOOL    Attach(unzFile);
   unzFile Detach(void);

#ifdef _unzx_H
   BOOL Attach(voidp stream, zlib_filefunc_def*);
   BOOL Validate(const char* password = NULL, void* buffer = NULL, size_t buf_size = 0);
#endif
   
   operator unzFile(void);

   static BOOL change_file_date(LPCTSTR filename,uLong dosdate,tm_unz tmu_date);

// Implementation
public:
   virtual ~CUnzip();
   virtual void Close();
};

#include "unzip.inl"

#endif // __UNZIP_HPP__
