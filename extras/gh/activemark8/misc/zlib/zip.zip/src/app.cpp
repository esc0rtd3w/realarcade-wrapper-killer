/* Troels K. 2001-2004 */

#include "stdafx.h"

#ifdef _WIN32
#include <afxconv.h>
#else
#define USES_CONVERSION
#define A2CT(x) x
#define T2CA(x) x
#endif
#include <tchar.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <conio.h>
#include <string.h>
#include <dos.h>
//#include <windows.h>
#include <direct.h>
#include <errno.h> /* EEXIST */
#ifdef _WIN32
#include <crtdbg.h>
#else
#define _ASSERTE(x)
#endif

#ifndef _countof
   #define _countof(array) (sizeof(array)/sizeof((array)[0]))
#endif
#ifndef _WINNT_
   #ifdef UNICODE
      typedef const wchar_t* LPCTSTR;
   #else
      typedef const char* LPCTSTR;
   #endif                 
   #define WINAPI PASCAL
#endif
#ifndef _INC_WINDOWS
   #ifdef _MSDOS 
   #else
      #define  FAR
   #endif
   typedef unsigned char       BYTE;
   typedef BYTE FAR* LPBYTE;
   typedef void FAR* LPVOID;
#endif

#define _strinc(_pc)    ((_pc)+1)

LPTSTR WINAPI _tcsrpbrk( LPCTSTR string, LPCTSTR strCharSet )
{
   TCHAR* result;
   for(result = NULL; 
      (NULL == result) && (*strCharSet != '\0'); 
      strCharSet = _tcsinc(strCharSet))
   {
      result = _tcsrchr(string, *strCharSet);
   }
   return result;
}

static BOOL mkdir_helper(LPTSTR lpsz)
{
   int result = _tmkdir(lpsz); /* actual work */
   BOOL bOK = (0 == result) || ( (result == -1) && (EEXIST == errno));
   if (!bOK)
   {
      LPTSTR p = _tcsrpbrk( lpsz, _T("\\/"));
      if (p != NULL)
      {
         /* recursive call, one less directory */
         *p = '\0';
         mkdir_helper(lpsz); 
         *p = '\\';
      }
      result = _tmkdir(lpsz); /* actual work */
      bOK = (0 == result) || ( (result == -1) && (EEXIST == errno));
   }
   return bOK;
}

BOOL WINAPI xx_tmkdir(LPCTSTR dirname)
{
   const size_t len = _tcslen(dirname);
   BOOL bOK = (len > 0);
   if (bOK)
   {
      LPTSTR lpsz = _tcsdup(dirname);
      /* remove tailing backslash if any */
      switch (lpsz[len - 1])
      {
         case '\\':
         case '/':
            lpsz[len - 1] = '\0';
            break;
      }
      bOK = mkdir_helper(lpsz);
      free(lpsz);
   }
   return bOK;
}


#include "..\unzip\contrib\unzipx.h"
#include "..\unzip\contrib.cpp\mfczip.hpp"
#include "..\unzip\contrib.cpp\ioapi.hpp"

class CMyUnzip : public CMFCUnzip
{
public:
   BOOL m_bPrompt;
   BOOL m_bAll;
   CFile    m_diskfile;
#if _MFC_VER <= 0x0253
   class CMyMemFile : public CMemFile
   {
   public:  
      void Attach(LPVOID lpBuffer, size_t size) {  m_nBufferSize = m_nFileSize = size, m_lpBuffer = (LPBYTE)lpBuffer;}
      virtual ~CMyMemFile() {m_lpBuffer = NULL; }
   } m_memfile;
#else
   CMemFile m_memfile;
#endif
   CMyUnzip(BOOL bPrompt);
   BOOL Extract(BOOL bFullPath, BOOL bOverwrite, LPCTSTR lpszDst = NULL);
   BOOL Open(LPCTSTR lpszFilePath);
   BOOL Open(const void* src, size_t src_len);
   virtual BOOL ExtractAccept(LPCTSTR write_filename, BOOL bOverwrite);
   virtual ~CMyUnzip();
};

inline CMyUnzip::CMyUnzip(BOOL bPrompt) : CMFCUnzip(CMFCUnzip::LIT_default_buf_size), m_bAll(FALSE), m_bPrompt(bPrompt)
{
}

inline CMyUnzip::~CMyUnzip()
{
   if (IsOpen()) Close();
}

inline BOOL CMyUnzip::Open(LPCTSTR lpszFilePath)
{ 
   SetFileFunc(&m_diskfile);
   return CMFCUnzip::Open(lpszFilePath); 
}

inline BOOL CMyUnzip::Open(const void* src, size_t src_len)
{
   m_memfile.Attach((LPBYTE)src, src_len);
   SetFileFunc(&m_memfile);
   return CMFCUnzip::Open(_T("MEMFILE")); 
}

inline BOOL CMyUnzip::Extract(BOOL bFullPath, BOOL bOverwrite, LPCTSTR lpszDst)
{
   m_bAll = FALSE;
   return CMFCUnzip::Extract(bFullPath, bOverwrite, lpszDst);
}

inline BOOL CMyUnzip::ExtractAccept(LPCTSTR write_filename, BOOL bOverwrite)
{
   BOOL bOK = bOverwrite || m_bAll;
   if (!bOK)
   {
      FILE* file = _tfopen(write_filename, _T("rb"));
      BOOL bExisting = (file != NULL);
      if (file != NULL) fclose(file);
      bOK = !bExisting;
      if ((!bOK) && (m_bPrompt))
      {
         for (TCHAR rep = '\0'; (rep!='Y') && (rep!='N') && (rep!='A'); )
         {
            _tprintf(_T(" Overwrite existing? [y]es, [n]o, [A]ll: "));
            rep = (TCHAR)_totupper(getch());
         }
         putch(rep);
         switch (rep)
         {
            case 'A':
               m_bAll = TRUE;
               break;
            case 'Y':
               bOverwrite = TRUE;
               break;
            case 'N':
            default:
               bOverwrite = FALSE;
               break;
         }
         bOK = bOverwrite || m_bAll;
      }
   }
   return bOK;
}

BOOL ListZipFile(unzFile handle)
{
   CMFCUnzip uf;
   BOOL bOK = uf.Attach(handle);
   if (bOK)
   {
      _tprintf(_T(" Length  Method   Size  Ratio   Date      Time   CRC-32     Name\n")
               _T(" ------  ------   ----  -----   ----      ----   ------     ----\n"));
      CZipFileFind ff(&uf);
      for (BOOL bContinue = ff.FindFile(); bContinue; )
      {
         bContinue = ff.FindNextFile();

         unz_file_info info;
         if (!ff.GetCurrentFileInfo(&info))
         {
            _tprintf(_T("error with zipfile in unzGetCurrentFileInfo\n"));
            break;
         }
         LPCTSTR string_method;
         switch (info.compression_method)
         {
            case 0:
               string_method = _T("Stored");
               break;
            case Z_DEFLATED:
               switch (((info.flag & 0x6)/2))
               {
                  case 0:
                     string_method = _T("Defl:N");
                     break;
                  case 1:
                     string_method = _T("Defl:X");
                     break;
                  case 2: // fast 
                  case 3: // extra fast
                     string_method = _T("Defl:F");
                     break;
                  default:
                     string_method = _T("?");
                     break;
               }
               break;
            default:
               string_method = _T("?");
               break;
         }
         const uLong ratio = (info.uncompressed_size > 0) 
            ? (info.compressed_size*100)/info.uncompressed_size 
            : 0;
         _tprintf(_T("%7lu  %6s %7lu %3lu%%  %2.2lu-%2.2lu-%2.2lu  %2.2lu:%2.2lu:%2.2lu  %8.8lx   %s\n"),
               info.uncompressed_size,string_method,info.compressed_size,
               ratio,
               (uLong)(info.tmu_date.tm_mon + 1),
               (uLong)info.tmu_date.tm_mday,
               (uLong)info.tmu_date.tm_year,
               (uLong)info.tmu_date.tm_hour,
               (uLong)info.tmu_date.tm_min,
               (uLong)info.tmu_date.tm_sec,
               (uLong)info.crc,ff.GetFilePath().operator LPCTSTR());
      }
      uf.Detach();
   }
   return bOK;
}

BOOL ListZipFile(LPCTSTR lpszZipFile)
{
   CMFCUnzip uf;
   BOOL bOK = uf.Open(lpszZipFile);
   if (bOK)
   {
      bOK = ListZipFile(uf);
   }
   return bOK;
}

static const LPCTSTR lpszZipFile = _T("test.zip");

int zip_main(int argc, TCHAR* argv[], TCHAR* envp[])
{
   static const LPCTSTR lpszSrcPath = _T("..\\src");
   static const LPCTSTR lpszDstPath = _T("dst");
   
   _tprintf(_T("Creating %s..."),lpszZipFile);

   CMFCZip zf;
   if (zf.Open(lpszZipFile))
   {
      /* If asserting: set Working Directory to .../zip/BIN */
      VERIFY(zf.AddNew(CString(lpszSrcPath) + _T("\\*.*"), TRUE));
      zf.Close();
   }
   else 
   {
      _tprintf(_T("\nerror opening %s"), lpszZipFile);
   }
   
   _tprintf(_T("\nContents of %s:\n"),lpszZipFile);
   if (!ListZipFile(lpszZipFile))
   {
      _tprintf(_T("error opening %s"), lpszZipFile);
   }
   
   _tprintf(_T("\nExtracting %s to %s ...\n"),lpszZipFile, lpszDstPath);

   xx_tmkdir(lpszDstPath);

   BOOL bFullPath = TRUE, bOverwrite = FALSE, bPrompt = TRUE;
   CMyUnzip uf(bPrompt);
   if (uf.Open(lpszZipFile))
   {
      uf.Extract(bFullPath, bOverwrite, lpszDstPath);
      uf.Close();
   }

   _tprintf(_T("Done\n"));
   return EXIT_SUCCESS;
}

#include "..\unzip\contrib\cryptx.h"

void encrypt_test(void)
{
   static const char* password = "plaster";
   static const char* source   = "Mary had a little lamb";
   const int len = strlen(source);
   char encoded[80];
   char decoded[80];

   memcpy(encoded, source, len);
   crypt_encode(encoded, len, password);

   memcpy(decoded, encoded, len);
   crypt_decode(decoded, len, password);

   printf("Encoded: %.*s\n"
          "Decoded: %.*s\n",
      len, encoded,
      len, decoded
      );
}

#include "iomem_simple.h"

void mem_simple_minimal()
{
   zlib_filefunc_def api;
   voidpf stream = mem_simple_create_file(&api, NULL, 0);
   if (stream)
   {
      static const char* text_in = "Mary had a little lamb";
      char text_out[80];
      ZWRITE(api, stream, text_in, strlen(text_in));
      ZSEEK(api, stream, 0, ZLIB_FILEFUNC_SEEK_SET);
      int len = ZREAD(api, stream, text_out, _countof(text_out));
      ZCLOSE(api, stream);
      printf("Contents of memoryfile:\n%.*s\n", len, text_out);
   }
}

#include "..\unzip\contrib\unzipx.h"

void mem_simple_main()
{
   FILE* stream = _tfopen(lpszZipFile, _T("rb"));
   if (stream)
   {
      const TCHAR szMemFileName[] = _T("memfile (simple)");
      const size_t len = _filelength(_fileno(stream));
      void* buffer = malloc(len);
      fread(buffer, len, 1, stream);
      fclose(stream); stream = NULL;

      zlib_filefunc_def mem_api;
      voidpf mem_stream = mem_simple_create_file(&mem_api, buffer, len);
      if (mem_stream)
      {
         unzFile unz = unzAttach(mem_stream, &mem_api);
         if (unz)
         {
            void* temp = malloc(1024);
            if (UNZ_OK != unzValidate(unz, NULL, temp, 1024))
            {
               _tprintf(_T("\nBad zip file %s:\n"), lpszZipFile);
            }
            free(temp);
            _tprintf(_T("\nContents of %s:\n"), szMemFileName);
            ListZipFile(unz);
            unzDetach(&unz);
         }
         ZCLOSE(mem_api, mem_stream);
      }
   }
}

#include "..\unzip\contrib\iomem.h"

void dump_zip_file_using_ioapi(unzFile file, LPCTSTR lpszFileName)
{
   USES_CONVERSION;
   zlib_filefunc_def api;
   voidpf stream = unzLocateFileAndOpen(file, T2CA(lpszFileName), 0, &api, NULL);
   if (stream)
   {
      const int buflen = 80;
      int read;
      do
      {
         char sz[buflen];
         read = ZREAD(api, stream, sz, sizeof(sz));
         if (read)
         {
            printf("%.*s", read, sz);
         }
      } while (read == buflen);
      ZCLOSE(api, stream);
   }
}

void mem_advanced_main()
{
   FILE* stream = _tfopen(lpszZipFile, _T("rb"));
   if (stream)
   {
      const TCHAR szMemFileName[] = _T("memfile (advanced)");
      const size_t len = _filelength(_fileno(stream));
      void* buffer = malloc(len);
      fread(buffer, len, 1, stream);
      fclose(stream); stream = NULL;

      MEMDATAHANDLE handle = mem_create_file(szMemFileName, buffer, len);
      if (handle)
      {
         zlib_filefunc_def mem_api;
         MEMFILEHANDLE mem_stream = mem_open_file(&mem_api, handle);
         if (mem_stream)
         {
            unzFile unz = unzAttach(mem_stream, &mem_api);
            if (unz)
            {
               _tprintf(_T("\nContents of %s:\n"), szMemFileName);
               ListZipFile(unz);
               
               if (0) dump_zip_file_using_ioapi(unz, _T("stdafx.h"));

               unzDetach(&unz);
            }
            ZCLOSE(mem_api, mem_stream); // close this session
         }
         mem_delete_file(&handle); // remove actual data
      }
   }
}

int _tmain(int argc, TCHAR* argv[], TCHAR* envp[])
{
   if(0)encrypt_test();
   if(0)mem_simple_minimal();
   if(1)zip_main(argc, argv, envp);
   if(1)mem_simple_main();
   if(1)mem_advanced_main();
   _tprintf(_T("Press any key to exit..."));
   _getch();
   return EXIT_SUCCESS;
}
