#ifdef __cplusplus
   extern "C" {
#endif

extern void* mem_simple_create_file(zlib_filefunc_def* pzlib_filefunc_def, void* buffer, size_t buflen);

#ifdef __cplusplus
   }
#endif
